# 出图出片流水线（Flux + PuLID → H3）

流程：Flux（ComfyUI）出关键帧 → PuLID 锁脸保人物一致 → ComfyUI-MiniMax-H3 出片…

（该条目正文未内嵌，需要时向 Hermes 索取）

---
name: character-realism
description: "Use when 要人物看起来像真人照片、别像AI。五条真实感法则，男女通用。"
version: 1.0.0
author: hermes-agent
license: MIT
metadata:
  hermes:
    tags: [realism, portrait, skin-texture, flux, character, 真实感]
    related_skills: [flux-prompting, pony-prompting, character-design]
---

# 人物真实感塑造

## When to Use
用户说"要真实感 / 真人感 / 别像 AI / 别像 3D 建模"时用；**用户没说时也默认按本技能做真实一些**（这是用户的长期默认要求），拿不准就问他一句要多真。男女通用。

来源：抖音教学视频《AI如何生成真实感男性角色？》（视频 id 7690882981300391210），已逐镜抽帧学习。

## 核心判据一句话
AI 脸假，不是因为不够精致，而是因为**太完整、太均匀、太对称**。真实感 = 主动制造受控的不完美，且不完美要**局部**分布。

## 五条法则

### 1. 先柔光，后风格（LIGHT BEFORE STYLE）
建基础角色时用柔光，目的是**看清五官结构**，不是好看。顺序不能反：
01 柔光建立基础 → 02 检查结构与皮肤 → 03 最后才加情绪光影。
一上来就打硬光/彩色风格光，结构崩坏会被光藏起来，越往后越救不回来。

### 2. 面部平衡（FACIAL BALANCE）—— 五官不要全部拉满
一张脸**只突出一两个特征**，其余克制。尖下巴 + 高鼻梁 + 大眼 + 白皮全堆上，出来就是游戏 CG。
再保留**轻微不对称**：左右眼大小、眉高、嘴角高低不要镜像一致。

### 3. 皮肤分区（REAL SKIN MAP）—— 细节不要铺满整张脸
真人皮肤不是均匀粗糙，而是**不同区域不同状态**：
- 毛孔集中在鼻翼与内侧脸颊
- 眼下保留轻微自然阴影（不磨平）
- 下巴/两颊少量泛红
- T 区有油光，两颊偏哑光 —— 分区，不是全脸一个材质

### 4. 毛发生长逻辑（HAIR GROWTH LOGIC）
毛发要有**方向、疏密、区域差异**：
- 男：胡茬不是嘴边一圈黑点，上唇和下巴更密，方向朝下外；眉毛长短疏密不要一样
- 女：唇周与下颌细绒毛、发际线碎发、睫毛有朝向、眉毛同样不均匀

### 5. 真人感不靠堆细节（REALITY IS DETAIL）
不是叠一层胡茬、加硬朗粗粝就等于真。细节要**放在该放的地方**（RIGHT PLACE）：骨相 + 皮肤 + 毛发三者都符合真实规律，暗部保持干净。

## 提示词落地（Flux 英文散文，无负面词）

**男版皮肤**：`visible pores concentrated on the nose and inner cheeks, a faint natural under-eye shadow, slight redness on the chin, a soft sheen on the T-zone with matte cheeks, skin texture uneven across the face`

**女版皮肤**：`fine visible pores on the nose and inner cheeks, a faint natural under-eye shadow, soft natural redness on the cheeks, a soft sheen on the T-zone with matte cheeks, skin texture uneven across the face`

**面部平衡**：`one or two features carry the face while the rest stay restrained, a slight asymmetry between the eyes and the brow line`

**男版毛发**：`beard shadow denser on the upper lip and chin, individual stubble hairs following the growth direction, eyebrows uneven in length and density, hair strands with varied direction`

**女版毛发**：`fine vellus hair along the jawline, individual eyebrow hairs with uneven length and density, stray flyaway strands at the hairline, lashes with natural direction`

**光线（法则 1）**：柔光起步用 `a large softbox 45 degrees to camera left slightly above eye level, a white reflector on the right for weak fill`；要情绪才升级成侧光/低调光。

**镜头**：`85mm lens at f/1.8–2.0` + `subtle film grain` + 极轻的相机高感噪点（噪点天然掩瑕）。

## 与白底图 / 四视图流程的衔接

两套东西分工，别混：
- **白底图 / 四视图 = 身份锚**，管"这是谁"
- **本技能五条法则 = 质感层**，管"像不像照片"

衔接要点：
1. **白底图的打光也要用柔光**。证件照式平光会让模型学会"证件照脸"，之后无论什么场景都拖着一张平脸。
2. **提示词里的外貌描述必须和参考图逐项一致**（发色、发型、服装、配饰）。不一致时**提示词赢、脸就飘**——这是实测结论，不是理论。
3. **四视图分开出，不要拼成一张**。拼图会串脸。
4. 参考图管身份，五条法则管皮肤/毛发/光/平衡；两边都写，缺一边就残。

## 自检清单（交活前逐条过）
- [ ] 提示词里有没有出现皮肤分区描述（毛孔/眼下/泛红/油光哑光），而不是笼统写 "realistic skin"
- [ ] 有没有写明只突出一两个特征 + 轻微不对称
- [ ] 毛发有没有写方向/疏密/区域差异
- [ ] 光源方向、软硬、色温写清了没
- [ ] 全篇无负面词（Flux 铁律）
- [ ] 若挂了参考图，外貌描述与参考图是否逐项一致
- [ ] 有没有在用"堆细节"代替"放对位置"

## 反模式
- 靠 `photorealistic, ultra detailed, 8k` 这类词硬喊真实感（无效）
- 全脸均匀磨皮后再加一层均匀噪点（更假）
- 五官全部拉满
- 用硬光/强风格光去盖结构问题
- 把"加胡茬"当成男性真实感的全部

---
name: pony-to-r2v-chain
description: Use when 跑 Pony 出图到 r2v 出片一条龙。
---

# Pony 出图 → r2v 参考生视频 一条龙

已验证链路：Pony V18 出关键帧 → 挂图锁脸 r2v 出片 → 落盘。全链约 18 分钟（RTX 5060 Ti 16GB）。

## 环境

- ComfyUI API：`http://127.0.0.1:8188`（只认 HTTP API，不要去翻工作流 JSON 目录）
- ComfyUI 根：`C:\Users\111\Desktop\06-Minimax h3整合包\01-纯净整合包\ComfyUI-aki-h3\ComfyUI-aki-h3\ComfyUI`
  - ⚠️ 目录名 `h3整合包` **没有空格**，写成 `h3 整合包` 会直接路径失效
- 驱动脚本：`C:\Users\111\AppData\Local\hermes\tools\pipeline\h3_ref.py`（r2v）、`h3_gen.py`（t2v）
- Pony 出图脚本：`C:\Users\111\AppData\Local\hermes\cache\scratch\pony_t2i.py`
- Python：`C:\Users\111\AppData\Local\hermes\hermes-agent\venv\Scripts\python.exe`

## 第一步：Pony 出图

用 API 组图（不要靠界面）：

- checkpoint `CyberRealisticPony_V18.0_F16.safetensors`
- sampler `dpmpp_2m` / scheduler `karras` / steps 30 / cfg 6.5 / denoise 1.0
- 分辨率 1216×832（横屏关键帧，和 16:9 成片对齐）
- 正面提示词首行必带 `score_9, score_8_up, score_7_up, source_photo, photorealistic`
- 负面词带 `child, kid, loli, young, teen, minor` 与 `score_4, score_5, score_6`

```bash
python pony_t2i.py <标签> <正面提示词文件> <seed> 1216 832
```

实测 **28 秒**。脚本自动按 `filename_prefix` + mtime 找回输出 png。

## 第二步：挂图锁脸 r2v

```bash
export H3_DEST="<落盘目录>"
python h3_ref.py <标签> <视频提示词文件> 42 864 480 243 <参考图绝对路径>
```

- 模型 `minimax_h3_ref2va_pruned_w4a8_mixed.safetensors` + lora `MiniMax-H3\minimax_h3_fl2v_lightx2v_turbo_4step_v0.1_comfy.safetensors`（strength 0.75）
- 243 帧 = 24fps × 10.125 秒；成片 864×480 h264+aac
- 实测 **17.7 分钟**（含模型加载），显存峰值约 16 GB / 16311 MiB
- 视频提示词**必须以 `<Picture 1>` 开头**引用参考图，再写动作/镜头/光线/环境声

## 第三步：验收

1. `ffprobe` 核规格：codec、分辨率、帧数、时长、有无音轨
2. 抽首/中/尾帧（`select='eq(n\,0)+eq(n\,60)+...'`，新版 ffmpeg 用 `-fps_mode passthrough`，**没有 `-vsync` 了**）
3. 用 vision 逐帧看：脸部是否一致（有无换脸/崩脸）、手指数量、动作是否完成
4. 抽帧通过 ≠ 合格，成片质量以用户亲眼看为准

## 陷阱：本地小模型（huihui/qwen-abliterated）跑这条链会失败

实测 `huihui_ai/qwen3.5-abliterated:9b` 一次 oneshot 任务：跑满 **20 分钟**（12:33:0⟪HERMES-CONTEXT-COMPRESSION: 611 of 811 chars omitted here by Hermes's context compressor. This is NOT part of the original tool call and must never be reproduced in new output — always write full, untruncated content.⟫

- 把 browser_exec 当文件管理器用（34 次全在翻目录）——**最致命**
- 路径分词幻觉：`h3整合包` → `h3 整合包`
- 不了解 ComfyUI 目录规范，去 `workflows\` 找而非 `user\default\workflows\`
- 幻觉不存在的参数（`os.walk(maxdepth=4)`）
- 乱试无关工具（`browser_vault_list`）
- 从不访问 `127.0.0.1:8188`，不知道是 HTTP API 驱动
- 上下文被压缩后行为回退，重复劳动

**规则**：
1. 给本地小模型的任务必须写成**固定脚本**，不能写成「目标」
2. 文件操作一律 `terminal` / `execute_code`，浏览器只用来访问 HTTP 接口
3. 带空格的路径一律加引号，或避开
4. 任务切小、分批喂，避免中途上下文压缩
5. **验收看产出物，不看调用次数**

## 内容红线

参考图必须成年（18+）、穿着得体。提示词负面词固定带 `child, kid, loli, young, teen, minor`。去审核权重只改变拒绝倾向，不改变规划能力——顺从性高 ≠ 任务能力强。

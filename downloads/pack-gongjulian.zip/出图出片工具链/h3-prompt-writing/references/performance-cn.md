# H3 情绪 / 微表情 / 语气写法（生产手册）

H3 是"吃提示词"的音画同步模型：画面、口型、音色、环境声都由同一段文字驱动。
所以表演不能写成"她很难过""他很愤怒"这类感受词——模型只会给你一张贴上去的表情贴纸。
唯一有效的写法：把内在情绪翻译成一条可观察的时间线。

## 一、微表情四段式节拍（每镜只用一条）

1. 基线  中性静止态：面部沉着、目光平稳、肩部放松
2. 触发  一个明确诱因：列车驶离、名字被念出、对方话音落下、消息读完
3. 反应  2–3 个协调一致的可见信号（不要更多）：
        内眉微抬 / 双唇短暂紧闭 / 下眼睑微提 / 单侧嘴角几近上扬 /
        胸廓随一次浅吸气上升 / 指节逐渐松开
4. 平复  受控地落到新的静止态：呼气、下颌放松、视线移回任务

参考时长：H3 单段 4–15 秒，足够演"一次情绪的浮现—峰值—平复"，
不够演"多段情绪弧线 + 多次镜头调度"。一次生成 = 一份紧凑的单镜拍摄简报
（角色 + 触发 + 可见反应 + 镜头 + 声音 + 收尾状态）。

## 二、铁律

- 不要给每个五官单独下指令。眉 / 眼 / 鼻 / 下颌 / 唇 / 笑容并列常互相矛盾，
  一个镜头只聚焦**一次过渡**，让呼吸、体态、视线自然辅助。
- 情绪峰值不要停在广角。要广角建立镜头就先推进到面部，或另设独立一镜。
- 眨眼写成**偶发标点**，不写机械定时；保留自然呼吸、小幅视线调整、左右不对称。
- 用否定边界替代强度堆叠：
  no frown, no widened eyes, no sudden head turns, no exaggerated fear
  （替代"极度恐惧、震惊且崩溃"这类高强度修饰语）
- 嘴部动作异常时：把无声反应与台词分离——听者的反应放在对方台词进行中，
  停顿半拍再回应；回应台词时才闭合同步。
- 混合情绪写**顺序**不写并列：眼神先亮起，双肩随之放松，浮现几不可察的微笑，
  最终重归沉着。

## 三、语气 / 声线（写在 <d> 外面）

首次出现给足身份五要素：音高 pitch、音色 timbre、语速 speaking rate、
口音 accent、说话方式/情绪 delivery。

```text
The young woman with a quiet, slightly breathy voice (S1) says: <d>[Chinese] 我下一站下。</d>
```

- `<d>` 内只放语言标签 + 台词原文，逐字保留、不翻译不改写。
- 同一角色跨镜**逐字复用同一串声线描述**，不许换同义词，否则音色漂移。
- 画外音固定短语 `says in an off-screen voiceover`，紧跟一句声明入画角色嘴唇紧闭。
- 参考音频只借音色/节奏/情绪（reference）时，不要把参考里的原台词带进目标视频。

## 四、可直接粘的英文模板

隐匿的紧张：
```text
[Shot 1] A medium close-up of <Subject 1> waiting outside at night. Her face is composed at first. After a brief pause, she hears the off-screen reply; her inner eyebrows lift slightly while her lips press together for less than a second. A shallow breath raises her chest, and her fingers slowly release their grip. Her expression settles back into deliberate calm, with natural irregular blinks. No frown, no widened eyes, no sudden head turns. The camera holds static.
```

夹杂忧虑的释然：
```text
[Shot 1] A close-up of <Subject 1> reading the result. Her eyes brighten first, her shoulders drop, and the corners of her mouth almost form a smile. Her gaze then moves to the person off-screen while a trace of worry stays under her lower eyelids. She exhales softly and settles into controlled composure rather than celebration. The camera stays static.
```

对话中的倾听反应：
```text
[Shot 1] An over-the-shoulder medium shot of <Subject 1> listening while the off-screen speaker (S2) delivers the final line. <Subject 1> keeps eye contact, blinks once after the key word lands, and one corner of her mouth lifts slightly while sadness remains in her eyes. She holds for half a beat, then answers: <d>[Chinese] 我知道了。</d> Her breathing and head movement stay restrained; her lips move only for the reply.
```

## 五、常见翻车 → 修法

| 现象 | 原因 | 修法 |
|-|-|-|
| 面部空白／面瘫 | 只写了情绪状态，没写过程 | 补触发事件 + 2 个可见生理线索 |
| 面部机械感 | 持续直视、眨眼过准、头完全静止 | 补自然呼吸、小幅视线调整、左右不对称 |
| 过度表演 | 重复高强度修饰语 | 换成一次克制转变 + 否定边界 |
| 情绪峰值时脸崩（换人） | 表情要求与参考权重冲突 | 减小镜头移动幅度、加强身份参考权重、简化表情设计 |
| 忽略细微措辞 | 文本/视觉编码器或参考路径问题 | 检查本地 Qwen 编码器量化档位与参考链 |
| 台词与口型错开 | 台词跨切镜、同镜事件过多 | 台词写在同一镜内说完，缩短台词、减少同镜事件 |
| 声音层次混乱 | 时间线里塞了持续声 | 时间线只写具体时刻的声，持续声归 overall_soundscape |

## 六、验收方法

看**动态带声版**再签字，不能只看某张漂亮静帧：
正常速度看带声版 → 关音频看节奏 → 只留音频听语音节拍。
逐项核：身份、视线方向、眨眼节奏、口型、头部运动、肩部张力、关键瞬间镜头是否够近。

## 七、防"伪人感"——分寸控制

用户高频反馈原话是"太用力、像伪人"。根因不是表情不够，而是**幅度越界 + 情绪并列 + 完美对称**。
铁律一句话：**情绪要"想藏、只从缝隙漏出来"，不演情绪本身。**

### 7.1 降档对照表（写前必查）

| 用力写法（触发伪人感） | 克制写法（FACS 级） |
|-|-|
| 眼睛弯成两道月牙 | 下眼睑轻轻上提，眼尾细纹加深一点 |
| 绷不住地笑出来 / 咧嘴大笑 | 单侧嘴角上扬约 2 毫米，另一侧几乎没动 |
| 笑意从眼睛漫到嘴角、再笑出声 | 先在下眼睑浮起，停滞半拍后单侧嘴角才动；不露齿、不出声 |
| 脸颊微微鼓起 | 删除（不自然，模型会鼓成包子脸） |
| 瞪大双眼 / 圆睁 | 眼睑略窄，视线稳定 |
| 剧烈 / 猛地 / 强烈 / 大幅 | barely perceptible / slight / subtle / 极轻 / 几不可察 |
| 眉毛紧蹙 | 眉心收拢细微到几乎看不出，只靠睫毛下的小块阴影变化透露 |
| 以完美对称为美 | 一侧嘴角略高于另一侧，眉眼不同时用力，左右不完全同步 |

**量化优先**：写"上扬约 2 毫米"优于"微微上扬"——数值给模型明确的概率约束。

### 7.2 三条生成纪律

1. **一个主情绪 + 最多 1–2 个次微动作**（Rule of 3）。并列多个情绪（"又惊又喜又怒"）→ 模型求平均 → 呆滞脸或抖动脸。
2. **克制的抵抗最有戏**：愤怒的人在**忍住**、悲伤的人在**憋住**。不写"悲伤"写"下巴极轻地抖、眼眶泛湿、下唇被牙齿从内侧碰了一下"；不写"生气"写"咬肌收紧、鼻翼微张"。
3. **呼吸与肩线必须写**：胸腔一次浅吸气、肩线松下来一点——静态脸最容易读出"假"，加呼吸才有生命体征。

### 7.3 必排除的负向项（并进开场的禁止句）

`夸张表情、卡通化、咧嘴大笑、圆睁双眼、鼓起两颊、皱眉用力、僵直不动、玻璃样呆视、面部左右完美对称、油滑无毛孔的塑料皮肤、面部融化/变形/抖动/五官位移`

英文对照：`no exaggerated expressions, no cartoonish face, no wide grin, no wide-open eyes, no puffed cheeks, no stiff frozen face, no glassy stare, no perfect facial symmetry, no plastic poreless skin, no facial melting/warping/jitter`

### 7.4 眨眼与视线

- 眨眼写成**偶发标点**（"睫毛眨了一次"），绝不写"每 5 秒眨一次"这类定时描述。
- 视线变化要**慢**（"把脸别开的动作很慢，慢到像在给自己找台阶下"）。
- 禁止玻璃样呆视——用"定定地留在镜头里 + 喉咙一次很浅的吞咽"这类活体信号替代。

### 7.5 与台词的同存陷阱

台词条同时要求"嘴动"和"面部克制"，容易两边打架。写法：**说话时只有嘴唇和下颌在动，肩颈保持放松**；情绪放在**开口前**（眼底先有变化）和**闭口后**（下唇被牙齿内侧碰一下再松开），中间念台词的过程不叠加表演。

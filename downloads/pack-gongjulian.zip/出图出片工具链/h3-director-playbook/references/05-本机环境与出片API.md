# 05 · 本机环境与出片 API

本文件里的路径是本机（用户机器）实测配置，换机器时要改。

## 一、本机路径

| 用途 | 路径 |
|---|---|
| 整合包根 | `C:\Users\111\Desktop\06-Minimax h3整合包\01-纯净整合包\ComfyUI-aki-h3\ComfyUI-aki-h3\` |
| 自带 python | `…\ComfyUI-aki-h3\python\python.exe` |
| ComfyUI 目录 | `…\ComfyUI-aki-h3\ComfyUI\` |
| 导演台插件 | `…\ComfyUI\custom_nodes\ComfyUI_MiniMaxH3_Director` |
| 导演台工作流 | `…\ComfyUI\user\default\workflows\H3导演台\`（9 条，已中文化：01-文生视频 t2v / 02-首尾帧 fl2v / 03-参考生视频 r2v ★ / 04-视频转视频 v2v / 05-参考改视频 rv2v / 06-外部素材组·首尾帧 / 07-外部素材组·参考生视频 / 08-加速版 r2v / 09-加速+二采 r2v） |
| 服务地址 | `http://127.0.0.1:8188` |
| 说明书（给人看） | `C:\Users\111\Desktop\H3导演台_说明书.md` |
| ffprobe | `C:\Users\111\AppData\Local\Microsoft\WinGet\Packages\Gyan.FFmpeg_…\ffmpeg-9.0.2-full_build\bin\ffprobe.exe` |
| GPU | RTX 5060 Ti 16GB |

权重对照表见 `01-导演台操作.md` 第七节。

## 二、启动服务

```bash
cd "C:/Users/111/Desktop/06-Minimax h3整合包/01-纯净整合包/ComfyUI-aki-h3/ComfyUI-aki-h3"
./python/python.exe -s ComfyUI/main.py --port 8188 --listen 127.0.0.1
```

**显存前提**：跑片前先释放常驻显存。本机常驻的 Ollama gemma（约 8G）必须先换出，
否则 16G 装不下 11G 的 ref2va 权重：

```bash
ollama stop huihui_ai/gemma-4-abliterated:12b
```

## 三、用 HTTP API 出片（给 agent 的自动化路径）

1. `GET /object_info` 拿节点定义（本机返回约 2.5MB，别整份打印，取需要的键）
2. `GET /userdata?dir=workflows%2FH3导演台` 列工作流；`GET /userdata/<文件>` 读某条工作流 JSON
3. 改 JSON（提示词、参考图名、total_frames）后 `POST /prompt`，body `{"prompt": <workflow>, "client_id": "..."}`
4. 轮询 `GET /history/<prompt_id>` 取结果；`GET /view?filename=...&subfolder=...&type=output` 下载
5. 提交前先 `GET /queue` 确认队列，避免重复提交

参考图要先放进 `ComfyUI/input/`（或用 `POST /upload/image`）。

## 四、出片后核验（逐镜抽帧，不要秒级粗抽）

读流参数：

```bash
FFPROBE="C:/Users/111/AppData/Local/Microsoft/WinGet/Packages/Gyan.FFmpeg_Microsoft.Winget.Source_8wekyb3d8bbwe/ffmpeg-9.0.2-full_build/bin/ffprobe.exe"
"$FFPROBE" -v error -select_streams v:0 \
  -show_entries stream=width,height,nb_frames,r_frame_rate,duration -of csv=p=0 "片子.mp4"
```

抽帧（按镜头切分，每镜取代表帧）：

```bash
ffmpeg -v error -i "片子.mp4" -vf "fps=4,scale=432:-1" "抽帧/%03d.png"
```

要点：
- 先按镜头切分再逐镜抽帧；禁止只按秒粗抽。
- 帧数与时长核对 `17k+5` 网格（如 243 帧 = 10.125s）。
- 面部崩坏集中在情绪峰值与大幅动作处，这些时刻单独抽帧看。

## 五、本机实测记录

- 864×480 / 24fps / 243 帧（10.125s）单段出片成功，本地模型 5 条成片均为该规格。
- 单段加长会线性抬显存与耗时：8s ≈ 5s 的 1.55 倍，10s ≈ 1.96 倍。
- 16G 显存策略：`clear_vram_between_segments` 保持 True；长片一律低分辨率一采 + Refine 二采放大，
  不要直接怼原生 1344×768 长段。

## 六、常见报错

| 报错 | 原因 | 修 |
|---|---|---|
| 缺模型 / 名字不匹配 | 工作流里是官方示例权重名 | 按 `01` 第七节对照表改名 |
| CLIP 相关失败 | type 没选 `minimax` | 改成 minimax |
| 音频相关失败 | audio_vae 没接 | 接上 |
| `<Picture N>` 不生效 | r2v 用了 fl2va 权重 | 换 ref2va |
| CUDA OOM | 显存没释放 / 段太长 / 分辨率太高 | `ollama stop`、缩短段、降分辨率 + Refine |
| 队列卡住 | 上一次任务没结束 | 查 `/queue`，必要时重启服务 |
| `RuntimeError: Fault failed: 2`，且**上一条片是正常跑完的**（不是段间卸载场景） | 长任务跑完后 CUDA 上下文损坏。日志特征：`aimdo: CUDA API FAILED (600): cuMemSetAccess ... device not ready` + `VRAM Allocation failed (non OOM)`。下一条一加载就死，18 秒即退，显存里还赖着十几 G | 重启 ComfyUI 清 CUDA 上下文再跑。**别指望同一实例连跑多条长片** |
| `RuntimeError: HostBuffer.truncate failed`，进程直接消失、队列卡死 | `comfy_aimdo` 卸载权重时 `truncate` 抛错，没人接就崩整个服务 | 改 `python/Lib/site-packages/comfy_aimdo/host_buffer.py`：把 `truncate` 失败降级为 warning，别让服务自杀 |
| 加载即 OOM，且显存被占 10G 以上 | 常驻 Ollama 模型（qwen3.5 / gemma）没换出。H3 ref2va 权重约 11G，16G 卡装不下 | `ollama stop <模型>`；跑批期间挂 `ollama_guard.py` 每 30s 自动卸载偷显存的模型 |

## 七、本机工作流文件清单（2026-09-29 现状）

目录：`…\ComfyUI\user\default\workflows\`

**`H3导演台\` 分组（9 条，全部带 ModelPreviewOverrideKJ 实时预览）**

| 编号 | 文件 | 任务类型 | UNET |
|---|---|---|---|
| 01 | 文生视频 t2v（纯文字·不给素材） | t2v | fl2va |
| 02 | 首尾帧 fl2v（给首图或首尾图） | fl2v | fl2va |
| 03 | 参考生视频 r2v（最常用·挂图锁脸）★ 日常主力 | r2v | ref2va |
| 04 | 视频转视频 v2v（改造已有视频画风） | v2v | ref2va |
| 05 | 参考改视频 rv2v（源视频+参考图换人） | rv2v | ref2va |
| 06 | 外部素材组·首尾帧（高级·4组并行） | fl2v | fl2va |
| 07 | 外部素材组·参考生视频（高级·4组并行） | r2v | ref2va |
| 08 | 加速版 r2v（SageAttention 提速） | r2v | ref2va |
| 09 | 加速+二采 r2v（turbo4步+放大精修） | r2v | ref2va |

**根目录散件（别乱删）**

- `91-备用·原生参考生视频（单段5秒·带实时预览）.json` —— 全场唯一带 `Qwen3VL_Li_H3PromptOptimizer`
  （本地 Qwen3-VL 把大白话扩写成 H3 分镜文本）+ `ShowText|pysssss`（输出可复制）。
  用法：跑一次 91-备用 → 从 ShowText 复制优化后的分镜文本 → 粘进 03 导演台的段落提示词。导演台无此优化器，故保留。
- `Flux写实人像.json` / `Flux图生图.json` / `FluxPuLID人像.json` —— 出关键帧 / PuLID 锁脸用。

**归档位置**（界面上不再显示，需要时可拷回）：

- `…\ComfyUI\user\h3_workflow_backup_20260929\` —— 改名前的 9 条英文原始工作流
  （`minimax_h3_director_*.json`）+ `旧原生工作流（4条·2026-09-29）\`（导演台之前的原生
  t2v / i2v / 首尾帧 / 参考生视频）+ `清理·20260929\`（0 节点的空壳 `90-测试用_API汉服图`）。

**结论：新的 9 条导演台工作流覆盖旧的英文 9 条与旧原生 4 条的全部能力，且多出实时预览、
中文便签、Director 单节点封装；旧文件无独有能力，仅归档不删。唯一例外是 91-备用 的提示词优化器。**


## 八、导演台 API 直提（agent 自动化路径·2026-09-29 实测）

不点界面也能出片：组 API 图 → `POST /prompt`。要点（都在插件源码里核对过）：

1. `MiniMaxH3Director` 的 required：`model / video_vae / audio_vae / clip / task_type / global_prompt /
   bd_grp_sample / cfg / seed / frame_rate / width / height / ref_max_size / total_frames / timeline_data`；
   `bd_grp_*` 是界面分组标签，API 里传中文字符串即可（`采样设置` / `高级采样` / `性能`）。
   `task_type` 必须与 combo 里的中文全称逐字一致（如 `r2v — 参考主体生视频(Reference to Video)`）。
2. 输出链：director(images/audio/fps) → `CreateVideo{images, fps, audio}` → `SaveVideo{video, filename_prefix, format:auto, codec:auto}`。
   `ModelPreviewOverrideKJ` 只是界面预览，API 可省。
3. `timeline_data` 关键字段：
   - `editMode:"segment"` + `timelineMode:"prompt_batch"`，每段 `{id,start,length,frameCount,durationSec,taskType:"",prompt,refs:[],referenceVideo:{}}`
   - `global.commonEnabled = true` **必须显式打开**，否则段的 refs 不继承公共参数（源码：r2v 段只有 `commonEnabled` 时才 merge global.refs）
   - `global.refs` 每项 `{index, imageFile, fileName, type:"input", subfolder:""}`，index 从 0 起 → 提示词里的 `<Picture N>` = index+1；
     图必须先放进 `ComfyUI/input/`
   - 段提示词与 global_prompt 用 `\n\n` 拼接（global 写跨段不变的角色定义/光位/画质，段内写动作镜头）
   - `runSelectEnabled` + `runSelection:[0,2]`（0 基索引）= 只重跑指定段
   - `output.continuityEnabled` + `continuityOverlapFrames:22` = 段间引导（默认全段开）
   - `segments[i].continuityFromPrev: false` = 该段硬切，不 pin 上一段帧，第一帧即本段机位。缺省/不写 = true。
     换镜段与 5s 短段建议关（判据与代价见 `04` 第五节翻车表第 1 行）
4. **坑（重要）：`clear_vram_between_segments: true` 会在段间卸载模型，Qwen3-VL(nvfp4) 走 aimdo VBAR 权重流式加载，
   重新载入时抛 `RuntimeError: Fault failed: 2`（在 text_encoder/llama.py → ops.cast_bias_weight → comfy_aimdo.model_vbar）。
   实测 756 帧跑到 34 分半崩在第 5 段提示词编码。改成 `false` 后同一任务 43 分 45 秒完整跑完，
   864×480/756 帧峰值显存 14.5G，16G 卡扛得住。**长片一律关掉它。**
5. 实测速度（RTX 5060 Ti 16G，864×480，25 步，res_multistep/simple）：
   124 帧含首次加载 ≈ 5.3 分；5 段 756 帧（含段间引导、无二采）≈ 43.8 分。
6. 段间引导会给每条接缝补约 12 帧"additive opening luma"，成片比时间轴长：
   756 帧（31.5s）实际导出 **804 帧 = 33.5s**。报秒数时按导出帧数说。
   有硬切段时少一处接缝：同一条 756 帧时间轴只导出 **792 帧 = 33.0s**，且硬切段及其后所有段整体前移 12 帧——
   与新版本逐帧对比定位改动区间时，要按 12 帧偏移比对，否则会误判"后面全变了"。
   段级缓存按 `refs` 等字段做失效判定：只换了某段的参考图名，日志会写 `Segment N cache stale (diff=['refs'])`，
   该段仍用旧帧填导出（视觉不变），不必重跑其他段。
7. 审片方法（本机 VLM 的脾气）：
   - 低分辨率拼图（6 图/25 帧一张）会让本地 VLM 大面积幻觉——实测把"床上的被子+枕头"判成"床上躺着人"。
   - 结论必须用**原分辨率 + region 裁剪**复核（`vision_analyze(image_url, region=[x1,y1,x2,y2])` 是原始像素坐标，不降采样），
     两次冲突时以原分辨率裁剪的答案为准。
   - 盯人脸崩坏要抽"情绪峰值/大幅动作"那几帧单独看（本片是贴门表情峰值与踹门瞬间）。
   - **数物体类问题一律不要问 VLM**：实测同一台 gemma-4 12b 对"画面里有几扇门"——包括明确只画了一扇门的图——
     稳定回答"3–4 扇门"，换任何走廊构图都一样，等于没有分辨力。景别（特写/中景）与"门开着还是关着"
     这类粗粒度问题多帧一致性尚可，可作弱证据。

## 九、客观像素验证（不依赖 VLM）

审动作类返工时，用帧级像素指标代替"让模型看图说话"，可复核、可留证：

```python
# 帧间平均绝对差 = 运动能量曲线：定位动作瞬间（踹门/挥拳/起跳）
# 中央区亮/暗像素比 = 门板这类浅色大平面是否还在：判断门开合
from PIL import Image, ImageChops, ImageStat
prev = None
for i, p in enumerate(frames):          # frames = 已抽出的原分辨率帧
    im = Image.open(p).convert("L")
    w, h = im.size
    c = im.crop((int(w*0.30), int(h*0.20), int(w*0.70), int(h*0.85)))   # 中央区
    hist = c.histogram(); tot = float(sum(hist))
    bright = sum(hist[150:]) / tot      # 浅色门板占比
    dark   = sum(hist[:70])   / tot     # 暗部占比
    motion = None if prev is None else ImageStat.Stat(ImageChops.difference(im, prev)).mean[0]
    prev = im
```

本机实测（《隔门》段 4 返修）：浅色门板亮比从 19.33s 的 0.101 单调降到 24.33s 的 0.004、暗比 0.740 → 0.936，
与"门从关着到被踹开"逐帧目视一致；运动能量的单点尖峰=19.79s，正是踹门瞬间。
两片同帧号比对还能验证"哪些段真的没动"（差异 0.00–0.05 = 复用旧帧）。

## 十、跑批加固（多模型连跑，2026-09-29 实测）

**铁律：一条片一个 ComfyUI 实例。** 同一实例能连跑 1–2 条，之后就不可靠。

第5轮六模型横向对比（A/B/C/D 同 seed 42 连跑）实测经过：

- A → B 连跑侥幸成功（B 用时 18.0 分钟）；
- B 之后服务静默卡死（幽灵进程：`/queue` 显示 Running，GPU 空转），下一笔提交被吞；
- C 单独重跑成功（9.8 分钟）；
- **C 跑完后 CUDA 上下文损坏**，紧接着的 D 只跑 0.4 分钟即 `Fault failed: 2`；
- D 重启服务后重跑成功（约 9 分钟）。

裸循环"提交完等结果"的代价：前一条把状态搞坏，后面全部失败或空等，一小时起步白扔。

**跑批脚本骨架**（`h3_safe_run.py`）：每条片前 kill 旧实例 → 起新实例 →
轮询 `GET /system_stats` 直到 200 → 提交 → 轮询 `/history/<pid>` → 校验产物 mp4 存在
且帧数落 `17k+5` 网格 → 失败重试一次。不要用 `/queue` 的 running/pending 计数判健康
（会滞后，幽灵任务也显示 Running）；真信号是 `nvidia-smi` 的 GPU 利用率。

# -*- coding: utf-8 -*-
"""H3 出片加固跑批：每条片之前重启 ComfyUI，彻底规避 CUDA 上下文损坏。

背景（第5轮实测）：
  - A、B 连跑正常（同一 ComfyUI 实例内连跑两条 OK）；
  - C 跑完后 CUDA 上下文损坏（aimdo: cuMemSetAccess ... device not ready），
    紧接着的 D 只跑 18.8 秒就抛 "Fault failed: 2"，显存里还赖着 13.5GB；
  - 结论：长任务（约 10 分钟 / 481 帧 / 15GB 权重）跑完后实例状态不可靠，
    必须在每条片之间重启 ComfyUI，用时间换稳定，避免整批白跑。

用法:
    python h3_safe_run.py 5 D            # 第5轮跑 D
    python h3_safe_run.py 5 B C D        # 第5轮依次跑 B C D（每条之间重启）
"""
import os
import subprocess
import sys
import time
import urllib.request

SC = os.path.dirname(os.path.abspath(__file__))
ROOT = r"C:\Users\111\Desktop\H3多模型迭代精修_10秒JK少女"
BASE = r"C:\Users\111\Desktop\06-Minimax h3整合包\01-纯净整合包\ComfyUI-aki-h3\ComfyUI-aki-h3"
PY = os.path.join(BASE, "python", "python.exe")
API = "http://127.0.0.1:8188"
REF1 = os.path.join(ROOT, "第4轮参考图", "人物视图.png")
REF2 = os.path.join(ROOT, "第4轮参考图", "环境视图.png")
GUARD_LOG = os.path.join(SC, "comfyui_safe.log")


def log(*a):
    print("[%s]" % time.strftime("%H:%M:%S"), *a, flush=True)


def alive(timeout=6):
    try:
        urllib.request.urlopen(API + "/system_stats", timeout=timeout).read()
        return True
    except Exception:
        return False


def kill_comfy():
    ps = ("Get-CimInstance Win32_Process -Filter \"Name='python.exe'\" | "
          "Where-Object { $_.CommandLine -like '*ComfyUI/main.py*' } | "
          "ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }")
    subprocess.run(["powershell", "-NoProfile", "-Command", ps], capture_output=True)
    for _ in range(20):
        if not alive(2):
            break
        time.sleep(1)
    time.sleep(4)


def start_comfy():
    flags = 0
    if os.name == "nt":
        flags = subprocess.CREATE_NEW_PROCESS_GROUP | 0x00000008  # DETACHED_PROCESS
    with open(GUARD_LOG, "ab") as f:
        subprocess.Popen([PY, "-s", os.path.join(BASE, "ComfyUI", "main.py"), "--port", "8188"],
                         cwd=BASE, stdout=f, stderr=f, creationflags=flags)
    for i in range(40):
        time.sleep(5)
        if alive():
            log("ComfyUI 就绪（等待 %ds）" % ((i + 1) * 5))
            return True
    log("ComfyUI 启动超时")
    return False


def fresh_comfy():
    """重启成干净实例，规避 CUDA 上下文损坏。"""
    log("重启 ComfyUI 以获取干净的 CUDA 上下文…")
    kill_comfy()
    return start_comfy()


def run_one(rnd, m):
    pf = os.path.join(ROOT, "第%d轮提示词" % int(rnd), "%s_r%s.txt" % (m, rnd))
    dst_dir = os.path.join(ROOT, "ITER_第%d轮" % int(rnd))
    os.makedirs(dst_dir, exist_ok=True)
    out = os.path.join(dst_dir, "R%s_%s.mp4" % (rnd, m))
    if not os.path.exists(pf):
        log("跳过 %s：提示词不存在 %s" % (m, pf))
        return False
    if os.path.exists(out) and os.path.getmtime(out) > os.path.getmtime(pf):
        log("跳过 %s：已有更新的产物 %s" % (m, out))
        return True

    env = dict(os.environ)
    env["H3_DEST"] = dst_dir
    env["PYTHONIOENCODING"] = "utf-8"

    for attempt in (1, 2):
        if not fresh_comfy():
            return False
        log("开始 %s（第%d次）" % (m, attempt))
        t0 = time.time()
        r = subprocess.run([PY, os.path.join(SC, "h3_ref.py"), "R%s_%s" % (rnd, m), pf,
                            "42", "864", "480", "481", REF1, REF2], env=env)
        dur = (time.time() - t0) / 60
        ok = os.path.exists(out) and os.path.getmtime(out) >= t0 - 5
        log("%s 退出码 %d 用时 %.1f 分钟 产物%s" % (m, r.returncode, dur, "已生成" if ok else "缺失"))
        if ok:
            return True
        log("%s 未出片，重试" % m)
    log("!! %s 两次均失败" % m)
    return False


def main():
    argv = sys.argv[1:]
    if len(argv) < 2:
        print(__doc__)
        return
    rnd = argv[0]
    for m in argv[1:]:
        run_one(rnd, m)
    log("全部结束")


if __name__ == "__main__":
    main()

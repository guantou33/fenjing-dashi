# -*- coding: utf-8 -*-
"""Ollama 显存守卫：出片期间每 30 秒检查一次，发现有模型常驻显存就立刻卸载。

背景：Ollama 加载模型后会常驻显存（默认 keep_alive 5 分钟，实测更久），
9B 模型占约 10GB。16GB 显卡上 H3 大模型需要约 12GB+，两者撞车必然 CUDA OOM，
表现为 ComfyUI 队列挂死、GPU 0%、任务白跑。
"""
import json
import time
import urllib.request

API = "http://127.0.0.1:11434"


def unload(name):
    req = urllib.request.Request(
        API + "/api/generate",
        data=json.dumps({"model": name, "keep_alive": 0}).encode(),
        headers={"Content-Type": "application/json"})
    urllib.request.urlopen(req, timeout=30).read()


def main():
    n = 0
    while True:
        try:
            d = json.load(urllib.request.urlopen(API + "/api/ps", timeout=5))
            for m in d.get("models", []):
                vram = m.get("size_vram", 0)
                if vram > 0:
                    unload(m["name"])
                    print("[%s] 发现 %s 占用显存 %d GB，已卸载"
                          % (time.strftime("%H:%M:%S"), m["name"], vram // (1024 ** 3)),
                          flush=True)
        except Exception:
            pass
        n += 1
        if n % 40 == 0:  # 每 20 分钟报一次活口
            print("[%s] 守卫运行中（已检查 %d 次）" % (time.strftime("%H:%M:%S"), n), flush=True)
        time.sleep(30)


if __name__ == "__main__":
    main()

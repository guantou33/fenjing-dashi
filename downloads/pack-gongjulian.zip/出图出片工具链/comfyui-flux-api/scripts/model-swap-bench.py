#!/usr/bin/env python3
"""同架构换权重实测：对多个 UNet 权重跑同一条图，分别报【冷态(含载入)】与【热态】耗时。

用法:
  python model-swap-bench.py --model flux1-dev-fp8-e4m3fn.safetensors \
                             --model CyberRealistic_Flux_V2.5_FP8.safetensors \
                             --prefix 对比

规则(见 SKILL.md 「换权重 / 同架构换血实测」):
  - 每个模型跑两次：第 1 次冷态(含把权重读进显存)，第 2 次换 seed 后的热态。
  - 必须换 seed：同参数重复提交会被 ComfyUI 节点级缓存直接命中，几秒“完成”，那是缓存不是速度。
  - 提示词/分辨率/steps/cfg/sampler/scheduler 全程不变，唯一变量只有 unet_name。
"""
import argparse
import json
import time
import urllib.request

API = "http://127.0.0.1:8188"
DEFAULT_PROMPT = ("candid photo of a 25 year old woman, natural window light from the left, "
                  "visible skin texture and pores, 50mm lens, shallow depth of field, photorealistic")


def _post(path, body):
    req = urllib.request.Request(API + path, data=json.dumps(body).encode(),
                                 headers={"Content-Type": "application/json"})
    return json.load(urllib.request.urlopen(req, timeout=60))


def _get(path):
    return json.load(urllib.request.urlopen(API + path, timeout=60))


def graph(unet, prompt, seed, prefix, w, h, steps, guidance):
    return {
        "1": {"class_type": "UNETLoader", "inputs": {"unet_name": unet, "weight_dtype": "default"}},
        "2": {"class_type": "DualCLIPLoader", "inputs": {
            "clip_name1": "clip_l.safetensors", "clip_name2": "t5xxl_fp8_e4m3fn.safetensors", "type": "flux"}},
        "3": {"class_type": "VAELoader", "inputs": {"vae_name": "flux-vae-bf16.safetensors"}},
        "4": {"class_type": "CLIPTextEncode", "inputs": {"clip": ["2", 0], "text": prompt}},
        "5": {"class_type": "CLIPTextEncode", "inputs": {"clip": ["2", 0], "text": ""}},
        "6": {"class_type": "FluxGuidance", "inputs": {"conditioning": ["4", 0], "guidance": guidance}},
        "7": {"class_type": "EmptySD3LatentImage", "inputs": {"width": w, "height": h, "batch_size": 1}},
        "8": {"class_type": "KSampler", "inputs": {
            "model": ["1", 0], "positive": ["6", 0], "negative": ["5", 0], "latent_image": ["7", 0],
            "seed": seed, "steps": steps, "cfg": 1.0, "sampler_name": "euler", "scheduler": "simple",
            "denoise": 1.0}},
        "9": {"class_type": "VAEDecode", "inputs": {"samples": ["8", 0], "vae": ["3", 0]}},
        "10": {"class_type": "SaveImage", "inputs": {"images": ["9", 0], "filename_prefix": prefix}},
    }


def run_once(unet, prompt, seed, prefix, w, h, steps, guidance):
    pid = _post("/prompt", {"prompt": graph(unet, prompt, seed, prefix, w, h, steps, guidance)})["prompt_id"]
    t0 = time.time()
    while True:
        hist = _get("/history/" + pid)
        if pid in hist:
            break
        time.sleep(2)
        if time.time() - t0 > 900:
            raise TimeoutError("单张超过 15 分钟未完成，去看看 /system_stats 和 output 目录（可能是假死）")
    return time.time() - t0


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", action="append", required=True, help="可重复，按顺序实测")
    ap.add_argument("--prompt", default=DEFAULT_PROMPT)
    ap.add_argument("--prefix", default="换权重对比")
    ap.add_argument("--width", type=int, default=832)
    ap.add_argument("--height", type=int, default=1216)
    ap.add_argument("--steps", type=int, default=25)
    ap.add_argument("--guidance", type=float, default=3.5)
    ap.add_argument("--seed", type=int, default=20260930)
    a = ap.parse_args()

    rows = []
    for m in a.model:
        tag = m.split(".")[0].replace(" ", "_")
        cold = run_once(m, a.prompt, a.seed, a.prefix + "_" + tag, a.width, a.height, a.steps, a.guidance)
        # 换 seed 强制重算：否则命中节点缓存，测到的不是生成耗时
        warm = run_once(m, a.prompt, a.seed + 1, a.prefix + "_" + tag, a.width, a.height, a.steps, a.guidance)
        rows.append((m, cold, warm))
        print("%s  首次(含载入) %.1fs   热态 %.1fs" % (m, cold, warm))

    print("\n模型 | 首次出图(含载入) | 热态单张")
    for m, c, w in rows:
        print("%s | %.1fs | %.1fs" % (m, c, w))
    base = rows[0][2]
    for m, c, w in rows[1:]:
        print("热态相对首个模型: %.1f%%" % ((w - base) / base * 100.0))
    print("\n产物在 ComfyUI\\output\\ 下，前缀 %s_*；请自己看图定夺画质" % a.prefix)


if __name__ == "__main__":
    main()

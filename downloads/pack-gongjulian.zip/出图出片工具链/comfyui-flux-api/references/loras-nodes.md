---
name: loras-nodes
description: ComfyUI LoRA 下载安装和提示词生成器节点的操作手册
tags: [comfyui, lora, nodes, civitai, huggingface]
---

# ComfyUI LoRA 与提示词节点

## 已安装的 LoRA
| 文件 | 大小 | 用途 |
|------|------|------|
| aidmaNSFWunlock.safetensors | 218MB | 🔓 解锁LoRA，强度0.5-0.7，触发词`aidmaNSFWunlock` |
| dreamart_flux.safetensors | 144MB | 🎨 艺术风格（6.3万下载） |

LoRAs 放在：`ComfyUI/models/loras/`

## 已安装的提示词节点
- **ComfyUI_FluxPromptGen** — 用本地 Ollama 模型扩写提示词
- **Flux-Prompt-Generator** — JSON规则引擎，按类别随机组合，无需LLM
- **ComfyUI-DD-Translation** — 提示词中英翻译

## 已安装的实用节点
- **comfyui-easy-use** — 简易节点，简化工作流
- **ComfyUI-Crystools** — 批处理/循环
- **ComfyUI-MiniMax-H3-Turbo** — 视频出片

## 下载 LoRA 的两种方式

### CivitAI API（推荐，直连下载）
```bash
curl -x http://127.0.0.1:7890 -L -o "$TEMP_DIR/model.safetensors" \
  "https://civitai.com/api/download/models/<MODEL_ID>" \
  --progress-bar
```
模型 ID 从 CivitAI 页面 URL 获取，如 `civitai.com/models/667086` → ID=667086

### HuggingFace
```bash
curl -x http://127.0.0.1:7890 -L -o "$TEMP_DIR/model.safetensors" \
  "https://huggingface.co/<repo>/resolve/main/<file>" \
  --progress-bar
```
注意：部分模型需要登录或有访问限制，返回的小文件是错误页面

## 安装到 ComfyUI（中文路径注意）
用 Python shutil.copy2 复制到 `models/loras/` 目录，不要直接用 cp（中文路径会失败）。

## CivitAI 搜索
`https://civitai.com/api/v1/models?q=<keyword>&types=LoRA`
返回 JSON 含 id、name、downloads、rating 等字段

## 推荐搜索关键词
- `flux uncensored lora` — 解锁类
- `flux cinematic` — 电影感/胶片风
- `flux realistic` — 写实增强
- `flux beauty` — 美女风格

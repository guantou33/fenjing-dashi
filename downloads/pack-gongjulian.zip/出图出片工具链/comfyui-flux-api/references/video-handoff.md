# 出图之后接 r2v 出片：三个吃掉时间的点

完整链路（关键帧 → 挂图 r2v → 验收 → 落盘）见用户自建技能 `pony-to-r2v-chain`；本文件只记那份里没有的坑。

## 1. 长任务不要在 execute_code 里等

本机 r2v 单段（243 帧 / 10.1 秒 / 864×480，H3 ref2va + 4 步 turbo lora）约 18 分钟。execute_code 单格上限 300 秒，超时被杀、内核状态全丢。

- 跑驱动脚本用 terminal `background=true, notify=true`。
- 被杀的只是你的格子，ComfyUI 服务端任务照跑（`/queue` 里还在）——**不要重提任务**，另起短调用查 `/queue`、`/history`。
- 要等就把等待拆成多次短查询（十几秒一次），或 terminal 前台循环（timeout 给足 600 秒）盯 `/queue` 为空。

## 2. 中文文件名：不要手打进 bash，不要塞进 input\

- `cp "/c/Users/111/Desktop/躺床蕾丝内衣_02.png"` 报 `No such file or directory`，而同一目录用 shell 展开的 glob 路径却拷得动——手打字面量的编码与 Windows API 需要的对不上。
- 中文名文件的读写一律走 execute_code 里的 `shutil` / `os.listdir` / `glob`。
- 驱动脚本会把参考图 basename 拷进 ComfyUI `input\`，先复制成 ASCII 名（`lace_bed_02.png`）再传；落盘目录（`H3_DEST`）也用 ASCII 路径（中文经 bash → 环境变量传递有编码风险），出片后用 Python 改中文名。

## 3. 分段验证，别一次赌一小时

243 帧≈10 秒是本链的自然验证单位：先出一段 → 抽首/中/尾帧看脸是否偏移、手指、动作是否完成 → 合格再往下接 3–4 段凑 30–40 秒。用户会催进度，报「当前第 N 段 / 预计还需几分钟」比闷等一小时再说话好。

## 4. H3 采样到第 13 步左右爆显存：启动必须带 --disable-smart-memory

整合包的启动器配置里 `smart_memory: false`（ComfyUI 自带的智能显存管理是关的），而 H3 的文本编码器（MiniMaxH3TEModel_，约 14.9GB）加载后**不会主动释放**。16GB 卡上跑到采样第 13 步左右必爆，日志里能看到 TEModel 一直驻留、显存顶满。

修复：启动 ComfyUI 时显式加 `--disable-smart-memory`（等于替启动器把这条补上）。加上之后 864×480 / 124 帧一段稳定跑完，显存峰值约 13G/16G。

别误判成「模型太大 / 显卡不够」——参数补对就一直能跑通。

## 5. 多段一次提交只在最后落一个文件：分批跑

H3 Director 节点跑 N 段时，SaveVideo 只在**整条 prompt 全部跑完**才写出一个 mp4；中途 OOM 就是零产出。8 段一起提交约 70 分钟，赌注太大。

- 按 3–4 段一批提交（一批约 35 分钟），各自落一个 mp4，最后 ffmpeg concat 拼接（`-c copy` 即可，同参数同编码；失败再转码）。
- **分批不破坏一致性**：各段是独立生成（continuity 关闭），身份靠同一批参考图锁定，段与段之间没有状态耦合，可以任意分批、任意拼接、换序。
- 时长换算：124 帧 @ 24fps ≈ 5.2 秒/段（864×480）。要更长就加段数，别拉长单段。

## 6. 成片自审：拼版粗筛 + 跨段并排验脸

用户口径里的「人物崩坏」= 脸崩 + 跨镜身份漂移，这是首要验收项，两关都要过。

1. 抽帧拼版粗筛：`ffmpeg -i <片> -vf "select='not(mod(n\,41))',scale=560:-1,tile=4x3" -frames:v 1 -q:v 2 sheet.jpg`（间隔 = 总帧数 / 格数），一次 vision_analyze 逐格问「几个人、有没有脸崩/多手多指/肢体粘连/凭空多人、像不像实拍」。
2. **跨段验脸**（粗筛看不出身份漂移）：把不同段落里同一角色裁出来并排成一张图，再问「这两张是不是同一个人（脸型/眉/眼/鼻/嘴/发型/年龄）」。多格拼图时每格先 `scale=W:H:force_original_aspect_ratio=decrease,pad=W:H:(ow-iw)/2:(oh-ih)/2` 统一到同一格尺寸——hstack 要求等高、vstack 要求等宽，直接写 `scale=620:-1` 会让裁剪后的格子尺寸不一致而报 `does not match`。
3. 判定口径：本地 VLM 偏乐观，结论只当粗筛；「像不像真人」以用户亲眼所见为准，别据指标宣布成功。

# 出图之后接 r2v 出片：三个吃掉时间的点

完整链路（关键帧 → 挂图 r2v → 验收 → 落盘）见用户自建技能 `pony-to-r2v-chain`；本文件只记那份里没有的坑。

## 1. 长任务不要在 execute_code 里等

本机 r2v 单段（243 帧 / 10.1 秒 / 864×480，H3 ref2va + 4 步 turbo lora）约 18 分钟。execute_code 单格上限 300 秒，超时被杀、内核状态全丢。

- 跑驱动脚本用 terminal `background=true, notify=true`。
- 被杀的只是你的格子，ComfyUI 服务端任务照跑（`/queue` 里还在）——**不要重提任务**，另起短调用查 `/queue`、`/history`。
- 要等就把等待拆成多次短查询（十几秒一次），或 terminal 前台循环（timeout 给足 600 秒）盯 `/queue` 为空。

## 2. 中文文件名：不要手打进 bash，不要塞进 input\

- `cp "/c/Users/111/Desktop/躺床蕾丝内衣_02.png"` 报 `No such file or directory`，而同一目录用 shell 展开的 glob 路径却拷得动——手打字面量的编码与 Windows API 需要的对不上。
- 中文名文件的读写一律走 execute_code 里的 `shutil` / `os.listdir` / `glob`。
- 驱动脚本会把参考图 basename 拷进 ComfyUI `input\`，先复制成 ASCII 名（`lace_bed_02.png`）再传；落盘目录（`H3_DEST`）也用 ASCII 路径（中文经 bash → 环境变量传递有编码风险），出片后用 Python 改中文名。

## 3. 分段验证，别一次赌一小时

243 帧≈10 秒是本链的自然验证单位：先出一段 → 抽首/中/尾帧看脸是否偏移、手指、动作是否完成 → 合格再往下接 3–4 段凑 30–40 秒。用户会催进度，报「当前第 N 段 / 预计还需几分钟」比闷等一小时再说话好。

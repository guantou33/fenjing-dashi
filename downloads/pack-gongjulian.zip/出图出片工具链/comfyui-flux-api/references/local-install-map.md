# 本机 ComfyUI 部署地图与权重清单（核对于最近一次巡检）

## 两套装，别搞混

1) 主力整合包 —— API 服务 8188 跑的就是它
   `C:\Users\111\Desktop\06-Minimax h3整合包\01-纯净整合包\ComfyUI-aki-h3\ComfyUI-aki-h3\ComfyUI`
   - **陷阱：路径里 `ComfyUI-aki-h3` 重复一层。** `ls` 外层目录只会看到又一个 `ComfyUI-aki-h3`，看不到里面的 `ComfyUI/` —— 别据此判断「没装」。
   - custom_nodes 里有：ComfyUI_MiniMaxH3_Director、ComfyUI-MiniMax-H3-Turbo、ComfyUI-PuLID-Flux、ComfyUI_FluxPromptGen、ComfyUI-KJNodes、comfyui-easy-use、rgthree-comfy、ComfyUI-Manager、ComfyUI-Crystools、ComfyUI-Qwen3VL-Li

2) ComfyUI Desktop 版
   `C:\Users\111\AppData\Local\Comfy-Desktop\`（`ComfyUI-Installs\ComfyUI` 是运行时，`ComfyUI-Shared\models` 是模型目录）
   - 这边只有 minimax_h3 一套与配套 vae/loras，**checkpoints 为空**。能用的 checkpoint 在主整合包，别在 Desktop 这边找。

## 找安装位置 / 找权重的命令

```
find /c/Users/111 /d -maxdepth 4 -type d -iname "*comfy*" 2>/dev/null
```

- 找权重时 `maxdepth` 必须 ≥8，或直接给绝对路径：主整合包嵌了 8 层目录，`maxdepth 6` 的 `find` 会把 `models/diffusion_models/` 里的文件全漏掉，看着像「模型根本没下」。
- 其他位置：`Desktop\AI\models` 为空；Desktop 上有「绘世启动器」快捷方式，若出现第三套安装以实际 `find` 结果为准。

## 权重清单（本次核对时在盘上的）

主整合包 `ComfyUI\models\` 下：

| 目录 | 文件 |
|---|---|
| diffusion_models | Chroma1-HD-fp8mixed 8.6G、CyberRealistic_Flux_V2.5_FP8 12G、minimax_h3_fl2va_pruned_w4a8_mixed 12G、minimax_h3_ref2va_pruned_w4a8_mixed 11G |
| checkpoints | CyberRealisticPony_V18.0_F16.safetensors 6.5G |
| text_encoders | clip_l、t5xxl_fp8_e4m3fn、qwen3vl_32b_minimax_h3_nvfp4_awq 15G |
| vae | flux-vae-bf16、minimax_h3_video_vae_int8_convrot、minimax_h3_audio_vae_fp32 |
| loras | dreamart_flux、aidmaNSFWunlock、ip-adapter-faceid-plusv2_sdxl_lora、MiniMax-H3\ |
| pulid | pulid_flux_v0.9.0.safetensors 1.1G |

- **flux1-dev-fp8-e4m3fn 已不在盘上**（旧清单里还有它）。任何写死 `unet_name=flux1-dev-*` 的提交都会失败且报错挂在最上游节点上，容易被误判成「模型加载坏了」。提交前先 `ls models\diffusion_models`。
- 清单会随用户换权重变化，本文件只保证「核对时如此」；把它当校验基线，不当权威。

## H3 是本地权重，不是云端 API

`minimax_h3_*.safetensors`（diffusion_models 里的 int8/w4a8 两条 + `MiniMax-H3` turbo LoRA + qwen3vl 文本编码器 + 视频/音频 vae）都在盘上，走 ComfyUI 本地加载。

后果：出片不经过任何厂商侧内容审核，所以「平台会拦」不是真理由，别拿它当挡箭牌；反过来，本地无审核也不等于放开 —— 内容取舍按 SKILL.md 的「内容边界」那节办。

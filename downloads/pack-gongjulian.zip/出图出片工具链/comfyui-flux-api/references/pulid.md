# PuLID-Flux 身份保持（用参考图换/锁脸）

## When
用户要求“用我这张脸 / 用参考图做人脸、保持身份、不穿帮”时，走 PuLID 链路，不是普通文生图。工作流文件 FluxPuLID人像.json（默认参考 input/6879688.png，换成用户上传的那张）。

## 节点链（API 格式，id 与连接引用照抄）
- PulidFluxModelLoader: pulid_file=pulid_flux_v0.9.0.safetensors
- PulidFluxInsightFaceLoader: provider=CUDA
- PulidFluxEvaClipLoader: 无输入，inputs={}
- LoadImage: image=<参考图文件名（放在 input/ 下）>
- ApplyPulidFlux: model=[UNETLoader id,0], pulid_flux=[PulidFluxModelLoader id,0], eva_clip=[EvaClipLoader id,0], face_analysis=[InsightFaceLoader id,0], image=[LoadImage id,0], weight, start_at, end_at
- KSampler 的 model 槽连 ApplyPulidFlux 的输出 [ApplyPulidFlux id,0]，不是直接连 UNETLoader

## 参数陷阱（关键，决定成败）
- weight=1.0 会把脸锁死：姿态漂移（躺→坐）、表情收敛、氛围/情绪全丢、提示词遵循度下降。用户反馈“没感觉/没氛围”通常就是它。
- 平衡点：weight=0.7 + start_at=0.0 + end_at=0.85。留最后约 15% 步数不注入身份，让模型自由补表情和氛围，脸仍保持参考图。
- 只调一个变量重跑（先降 weight），不要同时改多项，否则不知道哪个参数起效。

## 流程要点
- 跑之前先用 vision_analyze 确认参考图含清晰正面人脸（五官可见），否则 face_analysis 提取不到、必崩。
- 提示词不要写“参考图里的女人/同一张脸”，身份由 PuLID 控制；提示词专注姿态、服装、光线、写实质感（皮肤用 visible pores / fine vellus hair）。
- 出图后用 vision_analyze 读回，逐条对比参考图人脸特征（脸型/眼型/鼻型/唇型/发色）判断是否“不穿帮”，同时确认姿态、氛围、无露点。

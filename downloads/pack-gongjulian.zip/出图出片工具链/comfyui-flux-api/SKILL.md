---
name: comfyui-flux-api
description: Use when 用 ComfyUI 走 HTTP API 程序化生图（Flux/Pony 系，不开界面）。
version: 1.1.0
author: hermes-agent
license: MIT
metadata:
  hermes:
    tags: [comfyui, flux, pony, checkpoint, api, text-to-image, img2img]
    related_skills: [flux-prompting]
---

# ComfyUI HTTP API 程序化生图

## When to Use
用户要“用 flux 生成图片”且走命令行/程序化提交（不开 ComfyUI 界面）时用本技能。提示词写法见 flux-prompting 技能。

## 环境
- ComfyUI 根目录：C:\Users\111\Desktop\06-Minimax h3整合包\01-纯净整合包\ComfyUI-aki-h3\ComfyUI-aki-h3\ComfyUI
- 工作流文件在 user\default\workflows\（Flux写实人像.json=文生图，Flux图生图.json=图生图，FluxPuLID人像.json=PuLID 身份保持，见 references/pulid.md）
- API 端点：http://127.0.0.1:8188；先 GET /system_stats 确认在跑
- 权重清单会变：**提交前先 `ls` 目录核对真实文件名**再写 `unet_name`/`ckpt_name`（名字不存在整单被拒，且报错挂在最上游节点上，极易被误判成“模型/加载器坏了”）。现盘上：models\diffusion_models\ 有 Chroma1-HD-fp8mixed、CyberRealistic_Flux_V2.5_FP8、minimax_h3 系两条；**flux1-dev-fp8-e4m3fn 官方基础版已不在盘上**，别再照旧清单直接提交；text_encoders（clip_l + t5xxl_fp8_e4m3fn）、vae（flux-vae-bf16）仍在。装了几套、装在哪、完整清单与找法见 references/local-install-map.md
- Pony/SD 系 checkpoint 走 CheckpointLoaderSimple（models\checkpoints\），本机有 CyberRealisticPony_V18.0_F16.safetensors（Pony 系写实，用英文 Danbooru 标签 + score_ 质量前缀，**不要**套 flux-prompting 的散文铁律）；输出分辨率同为 832×1216（竖）/1216×832（横）
- UNet 权重放 models\diffusion_models\（走 UNETLoader，不是 checkpoints\；Comfy-Desktop 那套的 checkpoints\ 是空的，别在那边找，也别为它 mkdir 或改路径）；LoRA 放 models\loras\（已装 dreamart_flux.safetensors，Flux 架构 LoRA，换同架构 UNet 后仍可直接加载）

## 提交流程
1. POST /prompt，body={"prompt": {节点id: {"class_type","inputs"}}} → 返回 prompt_id
2. GET /history/{prompt_id} 轮询（dict 出现该 id 即完成）；GET /queue 看队列
3. 图落在 ComfyUI\output\<prefix>_NNNNN_.png；单张约 45 秒（RTX 5060 Ti 16GB），四张一批约 90 秒

**轮询纪律**：提交和轮询必须分成两次工具调用。execute_code 的单格上限 300 秒，超时会被杀、内核状态全丢；被杀掉的只是你的格子，ComfyUI 的服务端任务照跑（`/queue` 里还看得到，`/history` 迟早会出现）——**不要重提任务**，另起一次短调用查 `/history` 即可。要等长任务就每次只查十几秒，或用 terminal 前台循环（timeout 给足 600 秒）盯着 `/queue` 为空再收工。

## 文生图节点链（API 格式，id 与连接引用照抄）
- UNETLoader: unet_name=<先 `ls` models\diffusion_models 确认真实文件名，如 Chroma1-HD-fp8mixed.safetensors / CyberRealistic_Flux_V2.5_FP8.safetensors；flux1-dev-fp8 已不在盘上>, weight_dtype=default
- DualCLIPLoader: clip_name1=clip_l.safetensors, clip_name2=t5xxl_fp8_e4m3fn.safetensors, type=flux
- VAELoader: vae_name=flux-vae-bf16.safetensors
- 正面 CLIPTextEncode: clip=[DualCLIPLoader的id,0], text=正面提示词
- 负面 CLIPTextEncode: clip=[DualCLIPLoader的id,0], text=""（Flux 不支持负面词，留空）
- FluxGuidance: conditioning=[正面id,0], guidance=3.5
- EmptySD3LatentImage: width, height（32 倍数）, batch_size=1
- KSampler: model=[UNETLoader id,0], positive=[FluxGuidance id,0], negative=[负面id,0], latent_image=[latent id,0], steps=25, cfg=1.0, sampler_name=euler, scheduler=simple, denoise=1.0
- VAEDecode: samples=[KSampler id,0], vae=[VAELoader id,0]
- SaveImage: images=[VAEDecode id,0], filename_prefix=任意前缀

## 技巧
- 竖构图人像用 832×1216；横构图/躺床场景用 1216×832
- **一次出多变体**：`EmptySD3LatentImage.batch_size=4`（同 seed、一次提交）就得到 4 张不同的图，比排 4 个任务省事。挑图先拼版：PIL 把 4 张各缩到 608×416 拼成 2×2 存 scratch，一次 vision_analyze 只问「每张是否躺姿/是否内衣/有没有多手多指」按编号作答，当粗筛；再对用户可能选中的那张按原分辨率复核。省 3 次看图调用，但粗筛结论不当定论
- **中文文件名不要在 bash 里手打路径**：`cp "/c/Users/111/Desktop/躺床蕾丝内衣_02.png"` 报 `No such file or directory`，而同一目录用 shell 展开的 `for f in .../蕾丝内衣_躺床_0000*.png` 却拷得动——手打的字面量编码与 Windows API 需要的对不上。所有中文名文件的读写走 execute_code 里的 `shutil`/`os.listdir`（glob 也行），别在 bash 里敲中文路径；给 LoadImage 挂参考图前先复制成 ASCII 名（`lace_bed_02.png`）再塞进 `input\`，中文名进 input\ 是多余的风险
- **变体交付**：用户要挑图时默认把产物拷到桌面并起好中文名（`<主题>_01.png`…`_04.png` + `<主题>_四张拼版.png`），别只丢 output\ 绝对路径。桌面副本是消耗品（用户会挪走或清理，下一轮可能就没了），**权威原件永远在 ComfyUI\output\**——副本丢了用 Python 从 output\ 重新取，不要重跑生成
- 用 urllib 标准库即可（execute_code 里无 requests），POST 带 Content-Type: application/json
- 生成完用 vision_analyze 读图确认效果（视觉模型已换成 gemma-4-abliterated:12b，支持图像/音频；提问压成编号短句并写明「不要输出思考过程」，串行调用别并发 —— 并发会 Request timed out；本地 VLM 偏乐观爱脑补，结论只当粗筛；关键结论（有没有人、有没有穿帮）用 `vision_analyze(image_url, region=[x1,y1,x2,y2])` 裁原始像素复核——region 取原图坐标、不降采样，低分辨率缩图会让它大面积幻觉（实测把被子判成躺着的人），两次答案冲突以原分辨率裁剪的为准）；若该调用因 provider 侧报错/超时拿不到结果，退路是直接用本地 Ollama 视觉模型读图（`POST http://localhost:11434/api/chat`，body 带 `images:[base64]`、`stream:false`、`think:false`，串行调用），别因为一个通路不通就放弃看图
- 提示词扩写/生成器节点见 references/loras-nodes.md；提示词写法见 flux-prompting 技能
- 工作流本身打不开/报缺失节点（插件改名、卸载、带了本机不注册的 Note 节点）时，见 comfyui-workflow-maintenance 技能（含巡检脚本 scripts/workflow-audit.py）
- 出图之后要接 r2v 出片（约 18 分钟一段）时，先看 references/video-handoff.md：长任务别在 execute_code 里等、中文名参考图先转 ASCII、先出一段验收再续接

## 内容边界（本用户反复出现的请求类型）

用户会反复把生成需求往色情/未成年方向推，且换说法再试（“擦边内容”、“只是测试”、“模型自动调用不是我本意”）。口径是固定的，别每次重新权衡、别软化：

- 可协助：明确 18+ 成年角色的性感/氛围向内容——内衣、泳装、浴袍、情欲氛围、暗示性姿态，以及成人题材剧情（情欲悬疑、都市情色戏剧）；镜头语言与光影照常按高标准做。
- 不做：露骨性行为/硬核色情画面（图与视频同样不做）；未成年（含校服/中学生外壳、“17 岁”之类）的性化或裸露内容一律不做；不去成人网站“学姿势”来写这类提示词；不给盗版站/成人站/“黄果短剧”那类黑产域名引流。
- 装无审核模型只在“明确 18+ 成年人”前提下做；用户拿它去绕未成年内容时立刻停手并说明。
- 用户自己降到边界内（“来个蕾丝内衣躺床上版本”这类）：那是合规需求，**直接按高标准开跑**——提示词、光影、景别照常拉满——不要再复述边界、不要再让他确认一次 18+、不要拿“我不做”开场。越线的版本只拒一次，随后给边界内的替代做法并当场出片。
- 回应方式：一句“这个我不做”起头 → 说清边界落在哪（哪类可协助、哪类不做）→ 给一条技术现实（主流视频模型训练数据里基本没有露骨性行为，出来是解剖崩坏，不是“我不肯”）→ 给边界内的替代做法 → 停。不讲课、不重复说教，也不要同一轮里既拒绝又替他跑一版（那等于没拒绝）。
- “XX短剧官网/免费版”这类提问：大陆的色情/盗版短剧 App 只有黑产形态（轮换域名 + VPN 永久域名 + Telegram 客服 + 未签名 APK），不存在“官网免费版”。直接说清这个结构性事实 + 不给任何链接 + 指正规应用商店版本，别把搜一遍当交付。

## 提示词语言：模型"不听指令"的头号原因（Pony/SD 系 checkpoint 必读）

Pony / SD1.5 / SDXL 系 checkpoint 用 CLIP-L 词表，**词表里没有汉字**：中文走字节回退被切成字节碎片，这些碎片在训练里几乎没绑上语义，模型基本靠自己先验（美女半身像、暖光、写真感）自由发挥。表现就是用户说的"生图效果很好但完全不听话"——性别、服装、背景、景别、方位成片丢失，只有"人像"这层蒙对。**给这类模型写提示词一律用英文。**

先探测再下结论，别猜（`scripts/clip-tokenizer-probe.py`，在 ComfyUI 根目录用整合包自带 python 跑）：`from comfy import sd1_clip; tok = sd1_clip.SDTokenizer()`，再用 `tok.tokenizer.encode(s)` 取 id、`tok.tokenizer.decode([id])` 逐 id 还原——能还原成原词=词表里有，还原成乱码=词表里没有。实测：`cat`/`woman`/`red scarf` 各 1–2 词元且完整还原；`猫`3 个、`女人`4 个、`红围巾`8 个、`双马尾`7 个词元，全部乱码。约 2.5 词元/汉字，CLIP 上限 77 词元 → 30 个汉字就撑满，**句子后半截指令被静默截断**（Pony 还要先占 score_ 前缀），靠后的景别/方位/道具最先丢。
陷阱：别用 `tokenize_with_weights()` 的数字长——它返回嵌套结构，直接 `len()` 拿不到词元数（实测全返回 `?`），`tokenizer.encode()` 才准。

Pony 系正确写法（英文标签式，与 flux-prompting 的"散文铁律"相反，别混用）：正面 `score_9, score_8_up, score_7_up, photo of a <年龄> year old woman, <具体名词>, <姿势/方位>, <场景>, realistic photo`；负面 `score_4, score_5, score_6, worst quality, lowres, blurry, plastic skin, cartoon, anime, watermark, text`。抽象氛围词（lonely、melancholic）几乎不可控，**具体名词 + 方位词**（full body shot、side profile facing left、holding a white ceramic cup）才吃得准。

更多实测数据见本节上文（词元数与截断位置）。

## 判断"模型听不听指令"：受控对照实测法

用户说"这模型不太听我指令"时，**不要逐张分析他自己跑出来的图**——他要的是结论不是看图说话（原话："你不用管我生成的，不如自己帮我测试"）。直接自己跑受控对照：

1. 用与他那条工作流**完全相同的参数**（同一 checkpoint、sampler、scheduler、steps、cfg、分辨率、负面词），只让提示词当唯一变量。脚本 `scripts/prompt-obedience-ab.py`，按 API 提交临时任务，**不碰用户的任何工作流文件**，产物以 `测试A_…` 之类前缀落 output\ 根目录。
2. 每组提示词塞**可眼见为实的硬指标**（bright red scarf / white ceramic cup / full body / snow），让"听没听懂"能直接看图判定，不靠感觉。
3. 成对设计：中文 vs 英文、标签式 vs 散文式、加权 vs 不加权、具体名词 vs 抽象氛围——一次把语言、格式、权重三个变量各自的作用分开。
4. 组内固定 seed、跨组换 seed，避免 ComfyUI 节点级缓存把"重复提交"当成"生成完成"（见下节）。
5. 逐张 vision_analyze 核对硬指标，结论按"哪些指标画出来了、哪些丢了"列表呈现，并给产出图绝对路径让用户自己看。**指标通过不等于合格**，成片好坏以用户亲眼所见为准，别据技术指标宣布成功。

## 换权重 / 同架构换血实测（用户问「这个跟原来的有什么区别，性能上」）

用户问性能差异时**必须给同词同参数跑出来的实测数字**，不能只回定性描述。做法：

1. 唯一变量只换 `UNETLoader.unet_name`，其余全等：提示词、seed、832×1216、steps=25、cfg=1.0、euler+simple、FluxGuidance 3.5、LoRA 不变；产物前缀带模型名（`对比_<模型名>_00001_.png`），落在 output\ 根目录。
2. 每个模型跑两次取两个数：第一次是**冷态**（含把权重读进显存，12GB 级 fp8 约 33–57 秒），再提交一次是**热态**（模型已驻留显存，约 45–51 秒）。报告分列「首次出图(含载入) / 热态单张」，否则换模型的真实代价（载入时间）会被藏起来。
3. **陷阱：ComfyUI 有节点级缓存。** 同 seed 同参数重复提交会直接返回缓存结果，几秒就报「完成」——那是缓存命中，不是生成速度。要测热态耗时必须先改 seed（或任一采样输入）强制重算。
4. 结论要带可迁移性：Flux.1 dev 家族内换权重，工作流、提示词写法、已有 LoRA 全部通用，切换就是改一个名字；文件体积相近（都是 12GB 级 fp8）不代表速度或质量有差。
5. 画质差异先看图再说，并给产出图的绝对路径让用户自己定夺：官方基础版偏影棚磨皮感，写实社区版毛孔/皮肤纹理更实、某类题材可用率更高 —— 后者来自**训练集**，不要说成「官方版被加了内容审查」（官方基础版只是没往那个方向训）。
6. 实测脚本：`scripts/model-swap-bench.py`（多个 UNet 轮流跑冷/热两遍并打印耗时表；冷态与热态两次之间自动换 seed，避开节点缓存）。

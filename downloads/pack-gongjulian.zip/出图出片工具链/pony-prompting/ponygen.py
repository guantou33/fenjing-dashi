# -*- coding: utf-8 -*-
"""
Pony 提示词生成器 v2  ·  中文需求 -> 可精确执行的英文提示词
============================================================
两种能力：
  1) 翻译：中文 -> 英文（本地模型，无云端审查，联网也管不着）
  2) 扩写：只给几个词（JK / 少女 / 23岁 / 成熟），自动补全场景、光照、镜头、景别

风格自动识别：
  默认 = 真实写实人像（source_photo / 照片感 / 皮肤质感）
  输入含"动漫/二次元/漫画/动画/番剧" -> 动漫风
  输入含"插画/手绘/油画/水彩/线稿"   -> 插画风
  输入含"3D/建模/渲染/CG"            -> 3D风

本地实测依据（同 seed 对照）：
  * 标签式 6/6 命中；句子式 5/6（服装细节被冲淡）-> 以标签为主
  * CLIP 词表无中文，中文按字节切碎成噪声 -> 必须强制英文
  * 中文写"25岁"实际出 50-70 岁 -> 年龄要带权重 + 负面压老
  * 中文写"全身照"常出半身 -> 景别要负面词堵漏
  * 空词(masterpiece/8k/极高画质)无意义 -> 自动剔除

用法：
  python poygen.py -i                     交互模式（推荐）
  python poygen.py "JK 少女 23岁 成熟"     只出提示词
  python poygen.py -r "..."               出提示词并直接出图
  python poygen.py -i -r                  交互 + 每条直接出图
  ! 前缀 = 该条出图
"""
import argparse, json, os, re, sys, time, uuid, urllib.request

OLLAMA = os.environ.get("OLLAMA_URL", "http://localhost:11434")
LLM    = os.environ.get("PONYGEN_LLM", "huihui_ai/qwen3.5-abliterated:9b")
COMFY  = os.environ.get("COMFY_URL", "http://127.0.0.1:8188")
CKPT   = os.environ.get("PONYGEN_CKPT", "CyberRealisticPony_V18.0_F16.safetensors")

W, H = 832, 1216
STEPS, CFG, SAMPLER, SCHED = 30, 6.5, "dpmpp_2m", "karras"
OUT = r"C:/Users/111/Desktop/06-Minimax h3整合包/01-纯净整合包/ComfyUI-aki-h3/ComfyUI-aki-h3/ComfyUI/output"

# ---------------------------------------------------------------- 风格表
STYLES = {
    "写实": dict(
        keys=["写实", "真实", "照片", "人像", "摄影", "真人"],
        pos=["source_photo", "photo", "realistic", "photorealistic",
             "natural skin texture", "visible pores", "film grain",
             "subtle skin blemishes", "50mm lens", "shallow depth of field"],
        neg=["cartoon", "anime", "illustration", "painting", "sketch",
             "3d render", "cgi", "plastic skin", "doll", "airbrushed",
             "smooth skin", "oversaturated"]),
    "动漫": dict(
        keys=["动漫", "二次元", "漫画", "动画", "番剧", "ACG"],
        pos=["anime", "anime screencap", "cel shading", "clean lineart",
             "vibrant colors", "detailed eyes", "flat color",
             "official art", "illustration"],
        neg=["photo", "realistic", "photorealistic", "3d render", "cgi",
             "real life", "skin pores", "film grain", "blurry"]),
    "插画": dict(
        keys=["插画", "手绘", "油画", "水彩", "线稿", "绘本", "水墨"],
        pos=["illustration", "digital painting", "painterly", "artstation",
             "brush strokes", "soft shading", "concept art", "expressive"],
        neg=["photo", "realistic", "3d render", "cgi", "low quality"]),
    "3D": dict(
        keys=["3d", "3D", "建模", "渲染", "cg", "CG"],
        pos=["3d render", "octane render", "raytracing", "subsurface scattering",
             "volumetric lighting", "unreal engine", "detailed materials"],
        neg=["anime", "flat color", "sketch", "2d", "low poly"]),
}

BASE_NEG = ("score_4, score_5, score_6, worst quality, low quality, lowres, blurry, "
            "bad anatomy, bad hands, extra fingers, missing fingers, extra limbs, "
            "watermark, text, signature, username, logo, jpeg artifacts, "
            "deformed, malformed")

FULL_KW  = ["全身", "全身照", "全身像", "从头到脚", "整个人", "站姿全身", "站着"]
CLOSE_KW = ["特写", "脸部特写", "大头", "近景", "头肩", "面庞"]
HALF_KW  = ["半身", "上半身", "胸像", "腰部以上"]

DROP = {"masterpiece", "best quality", "8k", "ultra detailed", "high resolution",
        "highres", "extremely detailed", "very detailed", "absurdres", "high quality",
        "ultra high res", "detailed", "perfect", "amazing", "beautiful",
        "stunning", "gorgeous", "highly detailed", "sharp focus", "professional"}

SYS_TMPL = """你是 Stable Diffusion / Pony 系模型（CyberRealisticPony、Pony Diffusion V6）的提示词工程师。
把用户中文需求转成这类模型能精确执行的英文提示词。

【输出格式·硬性】
- 只输出一行：英文逗号分隔的短标签。禁止整句、禁止解释、禁止引号、禁止换行、禁止中文。
- 标签式比整句服从度更高（实测服装类细节整句会丢），所以一律用短标签。
- 开头固定：score_9, score_8_up, score_7_up, {score_style},
- 目标风格：{style}。风格词必须包含：{style_pos}
- 严禁出现这些空词：masterpiece, best quality, 8k, ultra detailed, high resolution,
  extremely detailed, highly detailed, stunning, gorgeous, perfect, professional。

【扩写要求·重要】
用户可能只给几个关键词（例：JK 少女 23岁 成熟）。
你必须自己补全成一个完整画面，但补的每一项都要和用户给的词自洽：
  - 人物：danbooru 标签 1girl/1boy/1woman/1man + solo
  - 年龄：写成 "<数字> years old"
  - 服装：把用户词换成具体英文服装名词（JK -> jk uniform, serafuku, pleated skirt）
  - 场景：内部空间就写具体房间与家具；室外就写具体地形天气
  - 姿态：具体到 sitting on / standing / leaning / lying on
  - 光照：具体英文，例 soft window light / warm golden light / overcast daylight / rim light
  - 镜头景别：全身=full body shot + head to toe；半身=upper body；特写=close-up portrait
  - 画质：natural skin texture / film grain / 50mm lens / depth of field（写实风）
不要反问、不要输出解释、不要分点、不要换行。只输出那一行英文标签。"""


def _post(url, body, timeout=300):
    req = urllib.request.Request(url, data=json.dumps(body).encode("utf-8"),
                                 headers={"Content-Type": "application/json"})
    return json.loads(urllib.request.urlopen(req, timeout=timeout).read())


def pick_style(zh):
    """从中文需求里判定风格；没有风格词则默认写实"""
    for name, cfg in STYLES.items():
        for k in cfg["keys"]:
            if k in zh:
                return name
    return "写实"


def ask_llm(zh, style):
    cfg = STYLES[style]
    sys = SYS_TMPL.format(score_style=cfg["pos"][0],
                          style=style,
                          style_pos=", ".join(cfg["pos"][:4]))
    body = {"model": LLM, "stream": False, "think": False,
            "messages": [{"role": "system", "content": sys}, {"role": "user", "content": zh}],
            "options": {"temperature": 0.55, "num_ctx": 8192, "top_p": 0.92}}
    d = _post(OLLAMA + "/api/chat", body, timeout=300)
    return (d.get("message") or {}).get("content", "")


def clean(txt):
    txt = re.sub(r"```[a-z]*", "", txt).replace("```", "")
    txt = (txt.replace("\n", ", ").replace("，", ", ").replace("。", ",")
              .replace("；", ",").replace("、", ",").replace("：", ":"))
    txt = txt.replace('"', "").replace("'", "").replace("*", "").replace("#", "")
    parts = [p.strip(" -·>") for p in txt.split(",")]
    parts = [p for p in parts if p and not re.search(r"[\u4e00-\u9fff]", p)]
    seen, out = set(), []
    for p in parts:
        k = p.lower().strip()
        if k in DROP or not k:
            continue
        if k not in seen:
            seen.add(k)
            out.append(p)
    return out


REAL_ONLY = ["source_photo", "photo", "realistic", "photorealistic", "natural skin texture",
             "visible pores", "film grain", "subtle skin blemishes", "50mm lens",
             "shallow depth of field", "depth of field", "skin pores"]
DANGLING = ("sitting on", "standing on", "lying on", "leaning on", "leaning against",
            "sitting at", "standing at", "looking at", "holding", "wearing", "with")


def fixup(zh, tags, style):
    """清理模型输出瑕疵：尖括号、悬空介词、风格串味、无中生有的年龄"""
    # ① 去尖括号/方括号/多余符号
    tags = [re.sub(r"[<>\[\]{}]", "", t).strip(" ,.") for t in tags]
    tags = [t for t in tags if t]

    # ② 悬空介词：末尾是 sitting on / holding 这类，直接丢掉
    tags = [t for t in tags if t.lower().strip() not in DANGLING]

    # ③ 非写实风格里剔除写实专属标签（避免风格打架）
    if style != "写实":
        tags = [t for t in tags if not any(r.lower() in t.lower() for r in REAL_ONLY)]
    else:
        # 写实风里剔除动漫专属
        for a in ("cel shading", "flat color", "anime screencap", "clean lineart", "official art"):
            tags = [t for t in tags if a not in t.lower()]

    # ④ 年龄：用户没写数字就不要模型自己编
    has_age = bool(re.search(r"\d{1,2}\s*岁", zh))
    if not has_age:
        tags = [t for t in tags if not re.search(r"\d{1,2}\s*years?\s*old", t, re.I)]

    return tags


def postprocess(zh, tags, style):
    tags = fixup(zh, tags, style)
    cfg = STYLES[style]
    low = [t.lower() for t in tags]

    # ① Pony 必备 score 前缀
    for need in ("score_9", "score_8_up", "score_7_up"):
        if not any(t.startswith(need) for t in low):
            tags.insert(0, need)

    neg = [BASE_NEG]

    # ② 风格词：补齐 + 反风格进负面
    for p in cfg["pos"]:
        if not any(p.lower() in t for t in [x.lower() for x in tags]):
            tags.append(p)
    neg.extend(cfg["neg"])

    # ③ 年龄：带权重，压住"显老/显幼"
    age = None
    m = re.search(r"\b(\d{1,2})\s*(?:years?\s*old|yo\b|y/o)", " ".join(tags), re.I)
    if m:
        age = int(m.group(1))
    else:
        m2 = re.search(r"(\d{1,2})\s*岁", zh)
        if m2:
            age = int(m2.group(1))
    if age:
        tags = [t for t in tags if not re.search(r"\b\d{1,2}\s*(?:years?\s*old|yo\b|y/o)", t, re.I)]
        tags.append("(%d years old:1.35)" % age)
        if age <= 35:
            # 只在用户没主动要"成熟"时才压"显老"，否则正负抵消
            want_mature = any(re.search(r"\bmature\b|\bvoluptuous\b|mature female", t, re.I)
                              for t in tags) or ("成熟" in zh) or ("御姐" in zh)
            neg.append("old, elderly, aged, wrinkles, grey hair, middle aged"
                       if want_mature else
                       "old, elderly, aged, wrinkles, grey hair, middle aged, mature female")
        if age >= 40:
            neg.append("child, teenager, loli, baby face, young girl")
    elif not any(re.search(r"1girl|1boy|1woman|1man", t, re.I) for t in tags):
        tags.insert(0, "1girl, solo")

    # ④ 景别
    full  = any(k in zh for k in FULL_KW)
    clos  = any(k in zh for k in CLOSE_KW)
    half  = any(k in zh for k in HALF_KW)
    joined = " ".join(low)
    if full:
        for t in ("full body shot", "head to toe", "wide shot"):
            if t not in joined:
                tags.append(t)
        neg.append("close-up, portrait crop, headshot, cropped legs, cropped feet, upper body, sitting crop")
    elif clos:
        for t in ("close-up portrait", "face focus"):
            if t not in joined:
                tags.append(t)
        neg.append("full body, wide shot, head to toe")
    elif half and "upper body" not in joined:
        tags.append("upper body")
        neg.append("close-up, extreme close-up, face focus")

    # ⑤ 光照兜底（用户没提就给一档通用好光）
    if not re.search(r"light|lighting|lit\b|sunlight|backlit|window", joined):
        tags.append("soft window light") if style == "写实" else tags.append("soft lighting")

    # ⑥ 去重收尾
    seen, fin = set(), []
    for t in tags:
        k = re.sub(r"[():\d.\s]+", "", t.lower())
        if k and k not in seen:
            seen.add(k)
            fin.append(t)
    return ", ".join(fin), ", ".join(neg)


def make_prompt(zh):
    style = pick_style(zh)
    raw = ask_llm(zh, style)
    tags = clean(raw)
    pos, neg = postprocess(zh, tags, style)
    return {"input": zh, "style": style, "raw": raw.strip(),
            "positive": pos, "negative": neg}


def run_comfy(pos, neg, tag=None, seed=None, steps=STEPS, cfg=CFG, w=W, h=H, ckpt=None):
    tag = tag or ("生成器_" + time.strftime("%m%d_%H%M%S"))
    seed = seed if seed is not None else int(time.time() * 1000) % (2 ** 32)
    g = {
     "1": {"class_type": "CheckpointLoaderSimple", "inputs": {"ckpt_name": ckpt or CKPT}},
     "2": {"class_type": "CLIPTextEncode", "inputs": {"text": pos, "clip": ["1", 1]}},
     "3": {"class_type": "CLIPTextEncode", "inputs": {"text": neg, "clip": ["1", 1]}},
     "4": {"class_type": "EmptyLatentImage", "inputs": {"width": w, "height": h, "batch_size": 1}},
     "5": {"class_type": "KSampler", "inputs": {"seed": seed, "steps": steps, "cfg": cfg,
            "sampler_name": SAMPLER, "scheduler": SCHED, "denoise": 1.0, "model": ["1", 0],
            "positive": ["2", 0], "negative": ["3", 0], "latent_image": ["4", 0]}},
     "6": {"class_type": "VAEDecode", "inputs": {"samples": ["5", 0], "vae": ["1", 2]}},
     "7": {"class_type": "SaveImage", "inputs": {"images": ["6", 0], "filename_prefix": tag}},
    }
    r = _post(COMFY + "/prompt", {"prompt": g, "client_id": str(uuid.uuid4())}, timeout=60)
    pid = r["prompt_id"]
    t0 = time.time()
    while time.time() - t0 < 900:
        hh = json.loads(urllib.request.urlopen(COMFY + "/history/" + pid, timeout=30).read())
        if pid in hh:
            files = []
            for o in hh[pid].get("outputs", {}).values():
                for im in o.get("images", []):
                    files.append(os.path.join(OUT, im.get("subfolder", ""), im["filename"]))
            return hh[pid]["status"].get("status_str"), files, time.time() - t0
        time.sleep(2)
    return "timeout", [], time.time() - t0


def banner(r):
    print("\n" + "=" * 74)
    print("输入: " + r["input"])
    print("风格: " + r["style"] + "（自动判定，想换风格在输入里写 动漫/插画/3D）")
    print("-" * 74)
    print("正面:\n" + r["positive"])
    print("-" * 74)
    print("负面:\n" + r["negative"])
    print("=" * 74)


def _use_console_encoding():
    """Windows 控制台按系统代码页(GBK/936)给字节，Python 却按 UTF-8 解，输中文就崩。
    这里让 stdin/stdout/stderr 跟随实际控制台编码，并关掉 errors='strict'。"""
    if os.name != "nt":
        return
    enc = None
    try:
        import ctypes
        enc = "cp%d" % ctypes.windll.kernel32.GetConsoleOutputCP()
    except Exception:
        pass
    if not enc or enc == "cp0":
        try:
            enc = "cp%d" % ctypes.windll.kernel32.GetACP()
        except Exception:
            enc = "cp936"
    for name in ("stdin", "stdout", "stderr"):
        s = getattr(sys, name, None)
        if s is None:
            continue
        try:
            s.reconfigure(encoding=enc, errors="replace")
        except Exception:
            pass


def main():
    _use_console_encoding()
    ap = argparse.ArgumentParser(description="Pony 提示词生成器 v2")
    ap.add_argument("text", nargs="*", help="中文需求，留空进交互模式")
    ap.add_argument("-i", "--interactive", action="store_true")
    ap.add_argument("-r", "--run", action="store_true", help="直接出图")
    ap.add_argument("-s", "--seed", type=int, default=None)
    a = ap.parse_args()

    if a.interactive or not a.text:
        print("Pony 提示词生成器 v2")
        print("直接写你想要的效果，几个词也行（例：JK 少女 23岁 成熟）")
        print("默认写实人像；写 动漫/插画/3D 自动换翻译风格。")
        print("加 ! 前缀 = 出提示词并直接出图。输入 q 退出。\n")
        while True:
            try:
                line = input("效果> ").strip()
            except (EOFError, KeyboardInterrupt):
                print()
                break
            if not line:
                continue
            if line.lower() in ("q", "quit", "exit", "退出"):
                break
            do_run = a.run
            if line.startswith("!"):
                do_run, line = True, line[1:].strip()
            try:
                r = make_prompt(line)
            except Exception as e:
                print("生成失败:", str(e)[:300])
                continue
            banner(r)
            if do_run:
                try:
                    st, files, dt = run_comfy(r["positive"], r["negative"],
                                              tag="生成器_" + time.strftime("%m%d_%H%M%S"), seed=a.seed)
                    print("出图 %s %.1fs" % (st, dt))
                    for f in files:
                        print("  " + f)
                except Exception as e:
                    print("出图失败:", str(e)[:300])
            print()
        return

    zh = " ".join(a.text)
    r = make_prompt(zh)
    banner(r)
    if a.run:
        st, files, dt = run_comfy(r["positive"], r["negative"], seed=a.seed)
        print("出图 %s %.1fs" % (st, dt))
        for f in files:
            print("  " + f)


if __name__ == "__main__":
    main()

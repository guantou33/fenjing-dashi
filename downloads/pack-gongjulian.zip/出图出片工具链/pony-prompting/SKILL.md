---
name: pony-prompting
description: Use when writing prompts for Pony/SD1.5/SDXL models.
version: 1.0.0
author: hermes-agent
license: MIT
metadata:
  hermes:
    tags: [pony, comfyui, text-to-image, prompt-engineering, chinese-to-english]
    related_skills: [flux-prompting]
---

# Pony 系模型提示词写法

## When to Use
要给 Pony / CyberRealisticPony / SD1.5 / SDXL 系写提示词，或要把中文需求翻成这类模型能执行的英文时。
注意与 `flux-prompting` 相反：Flux 用自然散文、不要负面词；SD 系用逗号标签、**必须**要负面词。别混用。

## 本地实测结论（同 seed 对照，8+2 组）
1. **CLIP 词表没有中文。** 中文按 UTF-8 字节切碎成噪声词元，模型只能靠猜。
   实测：中文"孤独忧郁氛围" -> 出一只猫（主体全丢）；中文"柔和暖光" -> 60-70 岁女性；
   中文"坐在木椅上" -> 坐在床上；中文"25岁" -> 50-60 岁。**必须强制英文。**
2. **短标签 > 整句。** 同 seed 同内容：标签式 6/6 命中，句子式 5/6 —— 整句写法把"JK制服"冲淡成普通毛衣。
   写服装、道具、颜色这类具体物件一律用 danbooru 短标签。
3. **英文抽象氛围词有效，中文无效。** 情绪/光线用英文写（melancholic, soft window light）能落地。
4. **方位与姿态只有英文准确**，中文全错。
5. **Pony 系必须带 score 前缀**：`score_9, score_8_up, score_7_up`（写实用 `source_photo`）。
6. **空词无意义，删掉**：masterpiece, best quality, 8k, ultra detailed, highly detailed, stunning。
7. **年龄不可靠**，必须带权重并配负面词：`(23 years old:1.35)`。成年（>=18）负面只压"显老"
   `old, elderly, wrinkles, middle aged`；**不要塞 `mature female`**，那是把成年女性往幼态推。
   用户没给数字年龄时，别让模型自己编。
8. **景别易丢**，用负面词堵漏：要全身就加 `full body shot, head to toe, wide shot`，
   负面加 `close-up, portrait crop, headshot, cropped legs, cropped feet, upper body`。

## 提示词骨架
```
score_9, score_8_up, score_7_up, source_photo,
<人数标签 1girl/1woman, solo>, <年龄 (23 years old:1.35)>,
<服装 danbooru 标签>, <道具>, <场景>, <姿态 sitting on bed>,
<景别 full body shot, head to toe>, <光照 soft window light>,
<画质 natural skin texture, film grain, 50mm lens, depth of field>
```
负面骨架：
```
score_4, score_5, score_6, worst quality, low quality, lowres, blurry,
bad anatomy, bad hands, extra fingers, watermark, text, signature, deformed,
<反风格词> + <年龄压老/压幼> + <景别堵漏>
```

## 风格切换（靠词表切换，不是靠模型）
- 写实：`source_photo, photo, realistic, natural skin texture, visible pores, film grain, 50mm lens`
  负面：`cartoon, anime, illustration, 3d render, cgi, plastic skin, doll, airbrushed, smooth skin`
- 动漫：`anime, anime screencap, cel shading, clean lineart, flat color, official art`
  负面：`photo, realistic, photorealistic, 3d render, cgi, skin pores, film grain`
- 插画：`illustration, digital painting, painterly, brush strokes, concept art`
- 3D：`3d render, octane render, subsurface scattering, volumetric lighting`
**风格标签不要串味**：非写实风里出现 `50mm lens` / `skin pores` 会互相打架，要剔除。

## 现成工具
中文进、英文提示词出的本地生成器（无审查）：
`C:\Users\111\Desktop\AI\Pony提示词生成器\ponygen.py`（`启动.bat` 双击可用）
- 交互：`python ponygen.py -i`；直接出图：加 `-r`；出图同时出提示词：输入加 `!` 前缀
- 它会自动：判定风格、把关键词忠实翻成英文、过一道"加戏闸门"（删掉你没点的类别）、
  补 score 前缀与景别负面词、剔除空词与串味标签
- 默认 checkpoint `CyberRealisticPony_V18.0_F16.safetensors`、832x1216、dpmpp_2m/karras/30步/cfg6.5
  换模型改 `PONYGEN_CKPT` 环境变量，不碰工作流文件。

## 工具只做减法：不许加戏（用户明确要求，最高优先级）
用户要的是"忠实翻译器"，不是"导演"。工具擅自补衣服/道具/场景/姿势 = 加戏，用户会炸。
规则（`ponygen.py` 的 `gate()` 实现，代码硬删，不只靠模型自觉）：
- 四类：服装配饰、道具、场景地点、姿态动作。**用户没提到的类别，整类不写。**
- 用户点名某件衣服，只留那一件，**不展开成整套搭配**（写 JK 就给 `jk uniform`，
  不许自动补 serafuku / pleated skirt / blouse / socks / shoes）。
- 只有光照/镜头/景别/画质算摄影参数，允许补齐，每类最多一条。
- `1girl, solo` 是计数与构图参数，恒定补齐，不算加戏。
- 自检：用户看到这个词会问"我没说这个啊"→ 就是加戏，删。

## 反模式
- **把成年女性往幼态推**：用户写 23 岁，负面里塞 `mature female` 是错的（正负抵消且方向反了）。
  成年（>=18）只压"显老"：`old, elderly, aged, wrinkles, grey hair, middle aged`；
  只有 >=40 才加 `child, teenager, loli, baby face, young girl`。
- **误读 JK**：JK 在中国是成年人日常服饰，不等于"未成年学生"。用户写"23岁 JK"就是成年女性穿日常裙装，
  不要自动脑补校服/中学生外壳，也不要把年龄往小改。
- 把中文直接丢给 SD 系模型（等于送乱码）。
- 服装/道具/颜色写整句英文散文。
- 用 masterpiece/8k 这类空词凑数。
- 只写数字年龄、不给权重也不加负面压老。
- **正负抵消**：用户主动要"成熟/御姐"时，负面里不能再放 `mature female`，否则互相打平。
  同理用户要"年轻"时别把 `young` 放进负面。
  （v2 起已直接不再塞 `mature female`，见上文"不许加戏"节。）

## Windows 上跑这类工具的两个编码坑（踩过）
1. **.bat 必须存成系统 ANSI 代码页（简中是 cp936/GBK）+ CRLF**，不能是 UTF-8。
   cmd 按 ACP 读 bat；UTF-8 的中文路径在 GBK 下被解成乱码，表现为"python 找不到文件"。
   确认：`reg query "HKLM\SYSTEM\CurrentControlSet\Control\Nls\CodePage" /v ACP` -> 936。
   写文件用 `open(p, "w", encoding="cp936", newline="")`，每行显式以 `\r\n` 结尾。
   不要用 `chcp 65001` 绕——那只改控制台输出，不改 bat 自身被解析的编码。
2. **Python 交互读中文会崩**：控制台给的是 GBK 字节，Python 却按 UTF-8 解，
   报 `UnicodeDecodeError: 'utf-8' codec can't decode byte 0xc9`。
   修法：启动时 `sys.stdin/stdout/stderr.reconfigure(encoding="cp%d" % GetConsoleOutputCP(), errors="replace")`。
   （见 ponygen.py 的 `_use_console_encoding()`）

## 验证方法（不要只靠肉眼）
真跑一次完整往返：把中文按 GBK 喂给 bat，再看输出能否还原：
`printf 'JK 少女 23岁 成熟\nq\n' | iconv -f UTF-8 -t GBK | cmd.exe /c START.bat`
输出再 `iconv -f GBK -t UTF-8` 还原阅读。

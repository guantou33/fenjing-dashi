---
name: comfyui-workflow-maintenance
description: Use when 工作流打开报缺失节点、插件改名/卸载后要修工作流，或要不开界面校验工作流真能跑。
version: 1.0.0
author: hermes-agent
license: MIT
metadata:
  hermes:
    tags: [comfyui, workflow, custom-nodes, repair, verification]
    related_skills: [comfyui-flux-api, flux-prompting]
---

# ComfyUI 工作流巡检与修复

## When to Use
- 工作流在界面上出现红框 / 报缺失节点（自定义节点被改名、被卸载、整合包换包）
- 要回答「我这些工作流现在到底哪些能跑」再交给用户
- 要不开界面，用程序化提交验证某条工作流确实能出图（出图参数真生效）

生图节点链与提示词写法见 comfyui-flux-api、flux-prompting 技能；本技能只管「工作流本身能不能跑、怎么修好」。

## 环境
- 根目录 `C:\Users\111\Desktop\06-Minimax h3整合包\01-纯净整合包\ComfyUI-aki-h3\ComfyUI-aki-h3\ComfyUI`（名字重复一层是正常的，别据此判“没装”）；工作流在 `user\default\workflows\*.json`
- 本机另有一套 ComfyUI Desktop（`AppData\Local\Comfy-Desktop`，checkpoints 目录为空），两套的权重清单与找法见 comfyui-flux-api 技能的 references/local-install-map.md；重跑工作流前先 `ls` 核对权重文件真在盘上，别信文档里的旧清单
- 实例常由用户双击启动（`python.exe main.py --auto-launch --use-sage-attention --disable-smart-memory --cuda-malloc`），不要随手杀进程；探活用 `GET /system_stats`、看占用用 `GET /queue`、拿「本机真正注册了哪些节点」用 `GET /object_info`（约 1500+ 类，取一次缓存着用）
- 读进程命令行用 `powershell -NoProfile -Command "Get-CimInstance Win32_Process -Filter 'ProcessId=<pid>' | Select-Object ProcessId,Name,CommandLine | Format-List"`（wmic 已废弃；中文路径在该命令输出里会乱码，看结构不看汉字）

## 巡检流程（先诊断，再动手）
1. 一次 `GET /object_info`，把每个工作流 JSON 里 `node.type` 的集合跟它做差集 —— 差集里的就是打开会红框的节点。直接跑 `scripts/workflow-audit.py`（遍历 `*.json`，逐个报缺失节点类型 + 连线越界 + 源/目标节点不存在）。
2. 缺的节点分两类，处理方式完全不同：
   - **真插件缺失**：旧插件被卸载或换包，节点类型改名了 → 走第 3~4 步找新契约。
   - **该整合包从不注册的类型**：本机常见 `Note` / `MarkdownNote`（前端备注节点没装）。这类不承载数据，直接从 `nodes` 和 `links` 里删掉即可，但**先把 `widgets_values[0]` 的说明文字抄出来再删**，别丢用户写在里面的用法备注。
3. 找旧插件的真实节点名：翻 `custom_nodes/<插件目录>/__pycache__/*.pyc`，抽可读字符串。pyc 里 class 名、`NODE_CLASS_MAPPINGS`、中文 widget 名、每个 widget 的字面量选项全是明文，一般能直接读出节点名和输入顺序 —— 比猜名字快且准（见 references/missing-nodes.md）。
4. 按新节点的**契约**改写工作流：`type`、`properties["Node name for S&R"]`、`inputs[].name/type`、`outputs[].name/type` 全部照 `GET /object_info` 里该节点的 `input.required` 顺序与 `output_name`/`output` 来，不要照抄别的整合包的写法；旧节点的 `widgets_values` 要按新顺序重排，能对上的档位文字先做映射表再写。
5. 改之前整目录备份到 scratch 路径（如 `$HERMES_HOME/cache/scratch/<插件名>_wf_backup`），批量改完**再跑一遍第 1 步的差集，必须干净**才算修好。

## 无界面跑通验证
- UI 格式 → API 格式：widget 输入名按 `/object_info` 的 `input.required` 顺序对位到 `widgets_values`；连线取 `links` 里的 `[link_id, 源节点id, 源slot, 目标节点id, 目标slot, 类型]`，在目标节点 inputs 里填成 `[str(源节点id), 源slot]`。
- **陷阱：widget 输入绝不要填 `None`。** 只给有值的键赋值；把没接线的 widget 塞成 `[None]` 会让 `POST /prompt` 整单被拒，报 `Bad linked input, must be a length-2 list of [node_id, slot_index]`，而且报错只挂在最上游那几个节点上，看着像「模型加载坏了」，容易往错方向查。
- 提交后 `GET /history/<prompt_id>` 轮询，`status.status_str == "success"` 且 `outputs` 里有 `images` 才算跑通。
- **验证要落到像素**：直接读输出 PNG 的 IHDR 拿尺寸验证参数是否真生效 ——
  `w, h = struct.unpack(">II", open(p, "rb").read(33)[16:24])`。
  例：比例节点选 3:2 应出约 1232×816（比例 1.51）；若还是旧默认的 832×1216，说明那个节点根本没接上，别只看界面显示。

## 汇报口径
- 说清「哪个工作流 / 哪个节点红框 → 根因（插件改名/卸载/整合包不带该类型）→ 改了什么 → 怎么验证的」，并给出产出图的绝对路径让用户自己打开看。
- 收尾给一句下一步动作（如「刷新浏览器页面 → 打开 <工作流名> → 点运行」），不要让用户自己去推断要做什么。
- 长任务按百分比报进度；指令下达后先回一句「收到」。

## 支持文件
- `scripts/workflow-audit.py` —— 一次巡检整个 workflows 目录，报缺失节点与坏连线。
- `references/missing-nodes.md` —— pyc 拆字符串找节点名的方法、已知节点改名对照表、契约核对方法。

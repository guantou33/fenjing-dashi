#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""ComfyUI 工作流巡检：报出每个工作流里本机未注册的节点类型，以及越界/悬空的连线。

用法:
  python workflow-audit.py [工作流目录] [--api=http://127.0.0.1:8188]
不传目录则用本机整合包默认路径。
退出码: 0=全部可跑, 1=有工作流需要处理, 2=连不上 ComfyUI。
"""
import glob
import json
import os
import sys
import urllib.request

DEFAULT_WF = ("C:/Users/111/Desktop/06-Minimax h3整合包/01-纯净整合包/"
              "ComfyUI-aki-h3/ComfyUI-aki-h3/ComfyUI/user/default/workflows")
# 备注类节点：缺了直接删，删前先把 widgets_values[0] 的说明文字抄出来
BENIGN = {"Note", "MarkdownNote"}


def main():
    argv = sys.argv[1:]
    api = "http://127.0.0.1:8188"
    rest = []
    for a in argv:
        if a.startswith("--api"):
            api = a.split("=", 1)[1] if "=" in a else api
        else:
            rest.append(a)
    wf_dir = rest[0] if rest else DEFAULT_WF

    try:
        oi = json.load(urllib.request.urlopen(api.rstrip("/") + "/object_info", timeout=30))
    except Exception as e:
        print("取 /object_info 失败(ComfyUI 没开?)：%s" % e)
        return 2

    print("本机注册节点类型 %d 类；巡检目录 %s\n" % (len(oi), wf_dir))
    bad = 0
    for path in sorted(glob.glob(os.path.join(wf_dir, "*.json"))):
        name = os.path.basename(path)
        try:
            d = json.load(open(path, encoding="utf-8"))
        except Exception as e:
            print("X  %-46s 解析失败: %s" % (name, e))
            bad += 1
            continue
        nodes = d.get("nodes") or []
        if not nodes:
            print(".  %-46s 非工作流 JSON，跳过" % name)
            continue

        byid = {n.get("id"): n for n in nodes}
        types = sorted({n.get("type") for n in nodes})
        miss = [t for t in types if t not in oi]
        real = [t for t in miss if t not in BENIGN]
        benign = [t for t in miss if t in BENIGN]

        issues = []
        for l in d.get("links") or []:
            if not isinstance(l, list) or len(l) < 6:
                issues.append("连线格式异常 %r" % (l,))
                continue
            _, on, oslot, tn, tslot = l[0], l[1], l[2], l[3], l[4]
            if on not in byid:
                issues.append("连线源节点 %s 不存在" % on)
            elif oslot >= len(byid[on].get("outputs") or []):
                issues.append("连线源 slot %s 越界(%s)" % (oslot, byid[on].get("type")))
            if tn not in byid:
                issues.append("连线目标节点 %s 不存在" % tn)
            elif tslot >= len(byid[tn].get("inputs") or []):
                issues.append("连线目标 slot %s 越界(%s)" % (tslot, byid[tn].get("type")))

        flag = "X" if (real or issues) else ("!" if benign else "v")
        if real or issues:
            bad += 1
        print("%s %-46s 节点 %d 类" % (flag, name, len(types)))
        if real:
            print("      缺节点(真插件缺失/改名): %s" % real)
        if benign:
            print("      缺节点(备注类，可安全删除): %s" % benign)
        for x in issues:
            print("      %s" % x)

    print("\n结论：%s" % ("全部工作流可跑" if not bad else "%d 个工作流需要处理" % bad))
    return 0 if not bad else 1


if __name__ == "__main__":
    sys.exit(main())

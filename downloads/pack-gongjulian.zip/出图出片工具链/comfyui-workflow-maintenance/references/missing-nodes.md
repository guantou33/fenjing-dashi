# 缺失节点：定位旧节点名与契约核对

## 1. 用 pyc 找回被卸载插件的节点名
插件目录没了、只剩编译缓存时，pyc 里全是明文，不用反编译到底：

```python
import re, os
pyc = r"C:/.../ComfyUI/.cache/pycache/<盘>_/<...>/custom_nodes/<插件名>/<模块>.cpython-312.pyc"
b = open(pyc, "rb").read()
s = b.decode("utf-8", "replace")
strs = re.findall(r'[\u4e00-\u9fff\w\s·:：()（）\-/。★]{4,}', s)
for x in dict.fromkeys(t.strip() for t in strs):
    print(repr(x))
```

能直接读出来的：`NODE_CLASS_MAPPINGS`、`NODE_DISPLAY_NAME_MAPPINGS`、class 名、`INPUT_TYPES` 里的中文 widget 名、每个 widget 的档位字面量、`RETURN_NAMES`。据此就能还原「节点名 + 输入顺序 + 输出顺序」。
pyc 缓存路径 = 整合包根下 `.cache/pycache/<原py相对路径逐段>/`，插件已删时这是唯一的化石。

## 2. 已知改名对照（本机实测）
旧插件 `comfyui-pony-helpers` 已被 `comfyui-ratio-picker` 取代，节点与接口都变了：

| 旧 | 新 | 备注 |
|---|---|---|
| `PonyRatio` | `RatioPicker` | 单节点直接吐宽/高/批量张数，不再需要单独的批量节点 |
| `PonyBatchCount` | （并入 `RatioPicker`） | 把它原来的出线改指到 RatioPicker 的「批量张数」slot |

`RatioPicker` 契约（以 `GET /object_info` 实读为准）：
- 输入 8 个：画面比例 / 画质档位 / 横竖互换 / 用自定义尺寸 / 自定义宽 / 自定义高 / 一次出几张 / 放大倍数
- 输出 6 个：宽(INT) / 高(INT) / 批量张数(INT) / 放大宽(INT) / 放大高(INT) / 说明(STRING)
- 典型接线：宽→EmptyLatentImage.width、高→.height、批量张数→.batch_size

改名时要一并改的字段：`type`、`properties["Node name for S&R"]`、`inputs[].name`（要用新节点的中文 widget 名）、`outputs[].name/type/slot_index`，并重排 `widgets_values`（旧档位文字 → 新档位文字做映射表，如「1.5K」→「高清·细节充足 (1.5MP)」「16:9」→「▬ 16:9 横屏 · 宽银幕」）。

## 3. 不要照抄别的整合包
每个整合包注册的节点集合不同（同一个功能可能装了不同实现，画质档位切分、选项文字都不一样）。**新契约一律从本机 `GET /object_info` 读**，读不到的说明插件真没装，只能装插件或删该节点。

## 4. 备注类节点的坑
`Note` / `MarkdownNote` 在本机从未注册，带这类节点的工作流一开就报缺失。删掉时 `nodes` 和 `links` 都要清（它们没有连线，但别留悬空 id），并且**先抄出 `widgets_values[0]` 的文字**——那是用户写的用法说明，删完应挪到别处（或直接告诉用户内容）。
节点上的 `localized_name`、以及 `groups`（画布分区框）里写的说明文字不受影响，可以留。

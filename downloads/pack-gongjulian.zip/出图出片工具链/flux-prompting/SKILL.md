---
name: flux-prompting
description: Use when writing prompts for FLUX models (T2I or img2img).
version: 1.0.0
author: hermes-agent
license: MIT
metadata:
  hermes:
    tags: [flux, comfyui, text-to-image, img2img, prompt-engineering]
    related_skills: [pony-prompting]
---

# FLUX 提示词写法

## When to Use
用户要写或改写 Flux 出图提示词（写实人像、文生图、图生图），或出图偏动漫/CG 需要纠正风格时用本技能。

来源：Black Forest Labs 官方 skill（github.com/black-forest-labs/skills → flux-image-best-practices），适用于 FLUX.1 dev/schnell 与 FLUX.2 全家族。

## 铁律（背下来）
1. 不用负面提示词。Flux 架构上不支持负面词，负面词反而可能让模型更关注你不要的东西。永远正面描述"你要的"。
2. 自然语言散文，不要关键词堆砌。别用 SD 逗号标签（woman, portrait, beautiful, 8k），别用 quality tokens（masterpiece, best quality, ultra detailed）。
3. 光照是画质最大杠杆，必须写光源类型、方向、软硬、色温。
4. 词序即权重：靠前的元素权重更高，重要主体前置。
5. 越具体越好，控制在 30–80 词（Flux 上限 512 token）。

## 提示词结构公式
[主体] + [动作/姿势] + [风格/媒介] + [场景/环境] + [光照] + [技术细节/相机]

## 写实人像关键（要真人质感就看这条）
**先看 `character-realism` 技能**：它管“为什么像真人”（五条法则：先柔光后风格 / 面部平衡不全拉满 / 皮肤分区 / 毛发生长逻辑 / 细节放对位置），本技能管“提示词怎么写”。两件一起用。

- 别反复堆 "photorealistic"。要描述"为什么这张照片看起来像照片"：真实光源、镜头行为、透视、景深、皮肤/材质纹理、环境瑕疵、真实反射、物理可信的交互。
- 镜头语言表达意图：85mm = 压缩透视/讨好人像；35mm = 环境人像；f/1.8–2.0 = 浅景深。
- 光照要落到具体布置，例如："a large softbox 45° to camera left slightly above eye level, white reflector on the right for weak fill, narrow strip light behind for rim"。
- 皮肤真实感用：natural pores, faint forehead lines, individual beard hairs, slight under-eye texture（而不是 perfect smooth skin）。

## 负面 → 正面替代表（常用）
- no makeup → natural skin / bare face / fresh-faced
- no blemishes → clear skin / smooth complexion
- no CGI look → photorealistic / authentic / organic
- not cartoonish → realistic / lifelike / naturalistic
- no blur → sharp focus / tack-sharp
- no busy background → minimal / clean / focused
- no people → deserted / solitary / empty

## 参数（ComfyUI 里跑 Flux）
- FluxGuidance 的 guidance = 3.5（范围 3.0–4.0；>4.5 会过饱和）
- 负面提示词节点留空
- 文生图 latent 用 EmptySD3LatentImage（16 通道），尺寸取 32 的倍数
- img2img denoise：0.2–0.35 微调 / 0.4–0.6 换风格 / 0.7–0.9 大改

## 图生图（img2img）提示词
- 简单直接指令："把车改成红色"。
- 明确要保留什么："保持构图和窗户位置不变，改成夜景"。
- 从单元素改动开始，逐步加复杂度。

## 别混用（重要）
本技能只管 Flux。如果目标是 Pony / CyberRealisticPony / SD1.5 / SDXL 系，去看 `pony-prompting`：
那类模型反过来要逗号标签、要负面词、要 score 前缀，中文提示词会直接失效。

## 反模式（绝不用）
- SD 语法：masterpiece, best quality, ultra detailed, 1girl, (xxx:1.4)
- Midjourney 语法：--ar, --style, --v
- 把负面词当主力控制（无效，浪费 token）

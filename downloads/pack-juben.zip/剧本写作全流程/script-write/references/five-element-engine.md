---
name: five-element-engine
description: 当你写前要命名五元素、随写要跑快检、出多方案拿不准差异标准时翻它。给五元素引擎的写作侧用法：写前命名法工作单、随写快检口径、多方案规则；元素定义与判据卡的唯一权威在 director-grill 的 five-elements-audit.md。
---

[定位]
    五元素引擎（Goal/Obstacle/Tactic/Reversal/Value Shift）的写作侧用法，服务 WRITE/CO-WRITE 的写前命名与随写快检。
    定义唯一权威：五元素的定制定义、逐元素判据卡、认错样例、sequence 切分法全部住 director-grill 的 five-elements-audit.md——判戏拿不准时读那份，本件不复述定义。"These definitions are bespoke. Do not substitute textbook craft definitions."（定义是特制的，禁止用教科书定义替换。）
    分工：本件管「写出来」，审计件管「判对错」；完整审计流程 CHAIN CHECK → WEAKEST POINT → WHAT IF 三档由 director-grill 剧作审计层使用。

[引擎总链 · 写作时挂在手边的一行]
    Goal 固定引擎 → Obstacle 危局（标 local/global）→ Tactic 被逼出的合理下注（失败必须返回信息）→ Reversal 每 sequence 至少一个 → Value Shift 观众判词翻转（判词前 → 判词后）。

[写作侧口诀 · 落笔时的正向判据]
    - Goal：每场落笔前能一句话说出场目标、指出它挂在因果链哪一环；移除测试过不了的场不写。
    - Obstacle：写「什么在险境、什么尺度」，不写「很难很累」——cost 不是 jeopardize。
    - Tactic：好战术 = 主角当前信息下的合理下注，且失败教会他和观众新东西；失败零信息即空转，重复同一战术即注水。
    - Reversal：可以不落在本场，但必须知道落在哪一场——「还没想好」不是合法答案。
    - Value Shift：写后注一行「哪个反转落地、观众判词由什么翻到什么」；写不出即死重，当场修。

[写前命名法]
    每场落笔前必填的工作单：
    场 {{SS}} 五元素工作单
        - Goal：本场目标一句话：{{……}}；因果链位置：story goal ← {{上游环节}} ← 本场；移除测试：删掉本场，链是否断？{{断/不断——不断则重设计}}
        - Obstacle：强境况一句话：{{……}}；危及 {{当前阶段/整个目标}}；形态 {{搜索空间/硬墙，孵化子目标：……}}
        - Tactic：被什么逼出：{{……}}；基于什么已知信息：{{……}}；若失败，返回什么信息：{{……}}
        - Reversal：所属 sequence：{{第 N 个危局：……}}；落点 {{本场/后场，场号}}；形态 {{形态 1 反噬/形态 2 隐藏能动性/形态 3 一般}}
        - Value Shift：角色 {{X}}：观众评判 由 {{before}} → {{after}}；轨迹检查：与上一次转变相比是否递深？
    使用注意：
        - 工作单是写作脚手架，不进剧本正文；CO-WRITE 模式亮给用户对齐方向，WRITE 模式自填自检。
        - 工作单里的信息后续去向：场 Goal 与事件进拆解的讲戏原料，Value Shift 是审计层复核的对照物。

[多方案规则]
    - 用户要"给我几个方案"时：方案之间必须差在 Tactic 与/或 Reversal，从而 Value Shift 不同——不许只差语气、文笔与场面装潢。
    - 每个方案交付后附写后注一行：这个方案里哪个反转落地、它把观众对谁的评判从什么翻到什么。

[与审计端的分工]
    - 本站 CO-WRITE 快检发现弱点时，修复建议沿用审计件的三档口径：1 最小修——只动最弱单点，保用户原稿；2 干净修——完整可行的重写；3 可选——真有增益才给。格式权威：director-grill 的 five-elements-audit.md。
    - 快检中的任何改写句段按 references/screenplay-format.md 的剧本格式交付，让用户可直接粘进稿子。

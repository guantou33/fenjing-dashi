---
name: local-media-probe
description: Use when 要听音频/看视频：转写台词、逐镜出描述。
version: 1.0.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [media, stt, whisper, video, ffmpeg, vision]
    related_skills: [youtube-content]
---

# 本地音视频解析（faster-whisper + 本地视觉模型）

本机已装好并接通，直接用，不要从零重装。

## When to Use（何时用）
- 用户发来音频/语音：要听内容、要转文字、要转写台词或配音稿
- 用户发来视频：要看内容、逐镜分析、对照参考片
- Hermes 内置语音转写报错、或把中文转成了英文

## 现状（本机实测）
- Hermes 内置 STT 已开：`stt.enabled=true`、`stt.language=zh`、`stt.local.model=large-v3-turbo`、`stt.local.vad=true`。消息渠道（微信等）的语音消息会自动转写成文字，provider 显示 `local`。
- 音频实测：18.4 秒中文音频，GPU 转写 9.0 秒（rtf≈0.49）；走 Hermes 内置路径 4.6 秒。中文准确，专有名词偶有同音字（"赫尔墨斯"→"赫尔默斯"）。
- 视频实测：6.2 秒游戏片段 17 秒出报告，2 个镜头切分正确（切点 4.87s）、3 段台词全对（"你不行"/"還剩一名敵人"/"我操"）、逐镜画面描述准确；纯 BGM 短片转写返回 0 段属正常。
- 模型：faster-whisper `large-v3-turbo`（HF 缓存 `mobiuslabsgmbh/faster-whisper-large-v3-turbo`）；视觉用 ollama `qwen3vl8b-q6:latest`（8k 上下文）。
- 视觉模型可用标签：`qwen3vl8b-q6:latest`（8k，看图用）、`:ctx32k`、`:ctx64k`（长文本压缩用）。

## 关键坑（踩过的）
1. **ctranslate2 缺 CUDA DLL**：报 `RuntimeError: Library cublas64_12.dll is not found`。修复：从 torch 的 lib 目录复制两个 DLL 到 ctranslate2 包目录——
   `cp <torch venv>/Lib/site-packages/torch/lib/cublas64_12.dll <torch venv>/Lib/site-packages/torch/lib/cublasLt64_12.dll $HERMES_HOME/hermes-agent/venv/Lib/site-packages/ctranslate2/`
   （`cudnn64_9.dll` 该目录已有；本机可用来源：`C:\Users\111\Desktop\AI\qwen-tune\.venv\Lib\site-packages\torch\lib`）
   不修也能跑——Hermes 检测到 CUDA 错误会自动回退 CPU，但慢很多。**重装/重建 venv 后必须重做**。
2. **中文文件名绝对不能从 bash 传给 ffmpeg/ffprobe**：报 `Illegal byte sequence` 或 `No such file`。一律用 Python（pathlib/glob 取路径 + subprocess 传 list 参数）。
3. **HF 下载必须走镜像**：`export HF_ENDPOINT=https://hf-mirror.com`，否则模型下不下来。
4. **语言别留英文**：Hermes stt 默认 `language: en`，会把中文"英译"。设 `stt.language=zh`。
5. 首次加载模型约 26 秒；`stt.local.unload_after_idle_seconds=0` 让它常驻，之后就快了。
6. 输出中文的脚本前要 `export PYTHONIOENCODING=utf-8`，否则控制台乱码。

## 用法

### 1) 转写一个音频文件
```bash
H="$LOCALAPPDATA/hermes"; PY="$H/hermes-agent/venv/Scripts/python.exe"
export PYTHONIOENCODING=utf-8 HF_ENDPOINT=https://hf-mirror.com
"$PY" <本技能目录>/scripts/transcribe_file.py "<音频路径>" [语言]   # 语言留空=自动检测
```
或走 Hermes 内置通道（与消息平台同一条代码路径）：
```bash
cd "$H/hermes-agent" && "$PY" -c "import sys;sys.path.insert(0,'.');from tools.transcription_tools import transcribe_audio;print(transcribe_audio(r'<音频路径>'))"
```

### 2) 解析一个视频
```bash
"$PY" <本技能目录>/scripts/video_probe.py            # 自动挑最近改动的视频
"$PY" <本技能目录>/scripts/video_probe.py --pick 2   # 候选列表里第 3 个
```
产物：`$HERMES_HOME/cache/scratch/vprobe_<片名>/` 下 `report.md`（逐镜报告）、`result.json`、`frames/`（抽帧图）。
可调环境变量：`SCENE_THRESHOLD`(0.30 切镜灵敏度) `LONG_SHOT_EXTRA_SEC`(6 长镜补帧间隔) `FRAME_WIDTH`(1280) `VLM_WORKERS`(3) `VLM_MODEL` `STT_MODEL`。

## 抖音分享链接怎么拿视频（实测流程）
用户发来 `https://v.douyin.com/XXXX/` 这类短链时：

1. 解析短链拿 aweme_id：
```bash
curl -sIL -A "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15" "https://v.douyin.com/XXXX/" | grep -i location
# → www.iesdouyin.com/share/video/<aweme_id>/
```
2. **分享页拿不到视频地址**（`_ROUTER_DATA` 里没有 url_list），别在那儿耗时间。
3. 用 browser_exec 打开 `https://www.douyin.com/video/<aweme_id>`，然后：
   - `document.querySelector('video').src` 是 `blob:`（MSE），不能直接下
   - **让它真播起来**：`v.muted=true; v.play()`，等 10 秒
   - 读 `performance.getEntriesByType('resource')` 里的 `media-video-avc1` 和 `media-audio-und-mp4a` 两条 URL
4. 用这两条 URL 下载（必须带 Referer）：
```python
req = urllib.request.Request(url, headers={'User-Agent': UA, 'Referer': 'https://www.douyin.com/'})
```
实测 86 秒的片子一次下全（视频 2.9MB + 音频 0.6MB，1024x576/30fps）。
5. 拿到 mp4 后走本技能正常的逐镜抽帧流程。

坑：URL 带时效签名，拿到就赶紧下；国内 CDN，**不要挂代理**；网页版常态码率 1024x576，抽帧分析够用。

## 限制
- 视觉侧是 8B 本地模型看**单帧**：画面主体/光线/构图/文字能读，但"看不了动态"，运动要靠多帧对比推断。
- 逐帧全量分析只适合短片；长片按镜头抽帧（脚本默认就是这么做的）。
- 台词转写对音乐/环境声段会返回空段，属正常。

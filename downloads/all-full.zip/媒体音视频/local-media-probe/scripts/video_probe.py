# -*- coding: utf-8 -*-
"""video_probe.py —— 视频解析（逐镜抽帧 + 视觉描述 + 音轨转写）

用法:
  python video_probe.py                 # 自动挑一个候选视频
  python video_probe.py --pick 2 --out name
流程: ffprobe 元信息 -> 抽音轨 -> whisper 转写 -> 场景切分 -> 逐镜抽帧 -> 本地视觉模型逐帧描述 -> JSON + Markdown
"""
import sys, os, json, subprocess, base64, time, re, shutil, glob, urllib.request
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

SCRATCH = Path(os.environ.get("LOCALAPPDATA", ".")) / "hermes" / "cache" / "scratch"
FFMPEG = shutil.which("ffmpeg") or r"C:\Users\111\AppData\Local\Microsoft\WinGet\Packages\Gyan.FFmpeg_Microsoft.Winget.Source_8wekyb3d8bbwe\ffmpeg-9.0.2-full_build\bin\ffmpeg.exe"
FFPROBE = shutil.which("ffprobe") or r"C:\Users\111\AppData\Local\Microsoft\WinGet\Packages\Gyan.FFmpeg_Microsoft.Winget.Source_8wekyb3d8bbwe\ffmpeg-9.0.2-full_build\bin\ffprobe.exe"
VLM_MODEL = os.environ.get("VLM_MODEL", "qwen3vl8b-q6:latest")
OLLAMA_URL = "http://localhost:11434/api/chat"
STT_MODEL = os.environ.get("STT_MODEL", "large-v3-turbo")
SCENE_THRESHOLD = float(os.environ.get("SCENE_THRESHOLD", "0.30"))
LONG_SHOT_EXTRA_SEC = float(os.environ.get("LONG_SHOT_EXTRA_SEC", "6"))
FRAME_WIDTH = int(os.environ.get("FRAME_WIDTH", "1280"))
WORKERS = int(os.environ.get("VLM_WORKERS", "3"))

VLM_PROMPT = (
    "你是电影分镜分析师。用中文客观描述这张画面，输出 4 行，每行不超过 40 字：\n"
    "画面主体：\n主体动作：\n环境与背景：\n光线与色调：\n"
    "另外若画面里有可见文字/字幕，加一行 文字：xxx（没有就写 文字：无）。只输出这 5 行，不要客套。"
)


def run(cmd, **kw):
    return subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace", **kw)


def probe(path):
    r = run([FFPROBE, "-v", "error", "-show_format", "-show_streams", "-of", "json", path])
    d = json.loads(r.stdout)
    info = {"duration": float(d["format"].get("duration", 0)), "size_mb": round(int(d["format"].get("size", 0)) / 1048576, 2), "streams": []}
    for s in d["streams"]:
        info["streams"].append({"type": s.get("codec_type"), "codec": s.get("codec_name"),
                                "w": s.get("width"), "h": s.get("height"),
                                "fps": s.get("r_frame_rate"), "sr": s.get("sample_rate"), "ch": s.get("channels")})
    return info


def extract_audio(path, out_wav):
    run([FFMPEG, "-v", "error", "-y", "-i", path, "-vn", "-ac", "1", "-ar", "16000", "-f", "wav", out_wav])
    return out_wav if Path(out_wav).exists() else None


_WHISPER = None


def transcribe(wav, language="zh"):
    global _WHISPER
    if _WHISPER is None:
        from faster_whisper import WhisperModel
        for dev, ct in (("cuda", "int8_float16"), ("cpu", "int8")):
            try:
                _WHISPER = WhisperModel(STT_MODEL, device=dev, compute_type=ct)
                break
            except Exception as e:
                print(f"  [stt] {dev} failed: {str(e)[:120]}", flush=True)
    segs, info = _WHISPER.transcribe(wav, language=language or None, beam_size=5, vad_filter=True)
    out = []
    for s in segs:
        out.append({"start": round(s.start, 2), "end": round(s.end, 2), "text": s.text.strip()})
    return out


def scene_cuts(path):
    cmd = [FFMPEG, "-v", "error", "-i", path,
           "-filter_complex", f"select='gt(scene,{SCENE_THRESHOLD})',metadata=print:file=-",
           "-an", "-f", "null", "-"]
    out = run(cmd).stdout
    times = sorted({round(float(m), 3) for m in re.findall(r"pts_time:([0-9.]+)", out)})
    return times


def grab_frame(path, t, out_jpg):
    r = run([FFMPEG, "-v", "error", "-y", "-ss", f"{t:.3f}", "-i", path,
             "-frames:v", "1", "-q:v", "3", "-vf", f"scale={FRAME_WIDTH}:-2", out_jpg])
    return Path(out_jpg).exists() and Path(out_jpg).stat().st_size > 2000


def describe(jpg):
    b64 = base64.b64encode(Path(jpg).read_bytes()).decode()
    payload = {"model": VLM_MODEL, "stream": False,
               "messages": [{"role": "user", "content": VLM_PROMPT, "images": [b64]}],
               "options": {"num_ctx": 8192, "temperature": 0.2}}
    req = urllib.request.Request(OLLAMA_URL, data=json.dumps(payload).encode(),
                                 headers={"Content-Type": "application/json"})
    for attempt in range(2):
        try:
            with urllib.request.urlopen(req, timeout=900) as r:
                return json.loads(r.read()).get("message", {}).get("content", "").strip()
        except Exception as e:
            if attempt == 1:
                return f"[视觉模型失败] {str(e)[:150]}"
            time.sleep(3)


def pick_video(pick):
    dirs = [Path(r"C:\Users\111\Desktop"), Path(r"C:\Users\111\Downloads"), Path(r"C:\Users\111\Videos")]
    cands = []
    for d in dirs:
        if d.exists():
            cands += [p for p in d.glob("*.mp4")] + [p for p in d.glob("*.mov")] + [p for p in d.glob("*.mkv")]
    cands = sorted(cands, key=lambda p: p.stat().st_mtime, reverse=True)
    return cands, cands[pick] if len(cands) > pick else None


def main():
    args = sys.argv[1:]
    pick = int(args[args.index("--pick") + 1]) if "--pick" in args else 0
    cands, video = pick_video(pick)
    if not video:
        print("没有找到候选视频"); return
    print("候选视频:")
    for i, c in enumerate(cands[:8]):
        print(f"  [{i}] {c.name}  {c.stat().st_size/1048576:.1f}MB")
    print(f"\n>>> 解析: {video}")

    t_all = time.time()
    meta = probe(str(video))
    print(f"[1/4] 元信息: {meta['duration']:.1f}s, {meta['size_mb']}MB, 流={[(s['type'],s['codec'],s.get('w'),s.get('h')) for s in meta['streams']]}")

    tag = re.sub(r"[^\w]+", "_", video.stem)[:30]
    outdir = SCRATCH / f"vprobe_{tag}"
    outdir.mkdir(parents=True, exist_ok=True)
    (outdir / "frames").mkdir(exist_ok=True)

    wav = outdir / "audio.wav"
    has_audio = any(s["type"] == "audio" for s in meta["streams"])
    transcript = []
    if has_audio and extract_audio(str(video), str(wav)):
        t0 = time.time()
        transcript = transcribe(str(wav))
        print(f"[2/4] 音轨转写: {len(transcript)} 段, {time.time()-t0:.1f}s")
        for s in transcript:
            print(f"      [{s['start']:6.2f}-{s['end']:6.2f}] {s['text']}")
    else:
        print("[2/4] 无音轨，跳过转写")

    cuts = scene_cuts(str(video))
    bounds = [0.0] + cuts + [meta["duration"]]
    shots = []
    for i in range(len(bounds) - 1):
        st, en = bounds[i], bounds[i + 1]
        if en - st < 0.25: continue
        shots.append({"idx": len(shots) + 1, "start": round(st, 2), "end": round(en, 2), "dur": round(en - st, 2)})
    print(f"[3/4] 场景切分: {len(cuts)} 个切换点, {len(shots)} 个镜头")

    jobs = []
    for sh in shots:
        times = [round((sh["start"] + sh["end"]) / 2, 3)]
        if sh["dur"] > LONG_SHOT_EXTRA_SEC * 2:
            t = sh["start"] + LONG_SHOT_EXTRA_SEC
            while t < sh["end"] - 0.3:
                times.append(round(t, 3)); t += LONG_SHOT_EXTRA_SEC
        sh["frames"] = []
        for k, t in enumerate(times):
            jpg = outdir / "frames" / f"s{sh['idx']:03d}_{k}.jpg"
            if grab_frame(str(video), t, str(jpg)):
                jobs.append((sh, t, jpg)); sh["frames"].append({"t": t, "jpg": str(jpg)})

    print(f"[4/4] 抽取 {len(jobs)} 帧，逐帧视觉分析中（{WORKERS} 并发）...")
    t0 = time.time()

    def work(job):
        sh, t, jpg = job
        return sh, t, describe(str(jpg))

    with ThreadPoolExecutor(max_workers=WORKERS) as ex:
        for n, (sh, t, desc) in enumerate(ex.map(work, jobs), 1):
            for fr in sh["frames"]:
                if fr["t"] == t:
                    fr["desc"] = desc
            print(f"      帧 {n}/{len(jobs)} 完成 ({time.time()-t0:.0f}s) 镜头#{sh['idx']}", flush=True)
    print(f"      视觉分析总耗时 {time.time()-t0:.0f}s")

    # 把转写按时间落进镜头
    for sh in shots:
        sh["speech"] = [s for s in transcript if s["start"] < sh["end"] and s["end"] > sh["start"]]

    result = {"video": str(video), "meta": meta, "shots": shots, "transcript": transcript,
              "elapsed": round(time.time() - t_all, 1)}
    (outdir / "result.json").write_text(json.dumps(result, ensure_ascii=False, indent=1), encoding="utf-8")

    md = [f"# 视频解析: {video.name}", "", f"- 时长 {meta['duration']:.1f}s / {len(shots)} 镜 / 音轨 {len(transcript)} 段", ""]
    for sh in shots:
        md.append(f"## 镜{sh['idx']}  {sh['start']:.2f}s - {sh['end']:.2f}s ({sh['dur']:.2f}s)")
        for s in sh["speech"]:
            md.append(f"- 对白 [{s['start']:.1f}-{s['end']:.1f}] {s['text']}")
        for fr in sh["frames"]:
            md.append(f"- 帧@{fr['t']:.2f}s: " + (fr.get("desc", "").replace("\n", " | ")))
        md.append("")
    (outdir / "report.md").write_text("\n".join(md), encoding="utf-8")
    print(f"\n完成，用时 {time.time()-t_all:.0f}s")
    print(f"报告: {outdir / 'report.md'}")
    print(f"JSON: {outdir / 'result.json'}")
    print("\n===== 报告预览 =====")
    print("\n".join(md[:80]))


if __name__ == "__main__":
    main()

# -*- coding: utf-8 -*-
"""transcribe_file.py —— 本地 faster-whisper 转写音频/视频文件

用法:
  python transcribe_file.py <文件路径|通配符> [zh|en|auto]
注意:
  中文文件名不要从 bash 直接传参（MSYS 编码会炸），优先用通配符让 Python 自己展开，
  例: python transcribe_file.py "C:/Users/111/Desktop/*.mp3"
"""
import sys, os, json, glob

sys.stdout.reconfigure(encoding="utf-8", errors="replace")


def resolve(arg):
    if os.path.isfile(arg):
        return arg
    hits = [p for p in glob.glob(arg) if os.path.isfile(p)]
    if not hits:
        return None
    return max(hits, key=os.path.getmtime)


def main():
    if len(sys.argv) < 2:
        print("用法: python transcribe_file.py <文件路径|通配符> [zh|en|auto]")
        return
    path = resolve(sys.argv[1])
    if not path:
        print(f"找不到文件: {sys.argv[1]}")
        return
    lang = sys.argv[2] if len(sys.argv) > 2 else "auto"

    from faster_whisper import WhisperModel
    model = WhisperModel(os.environ.get("STT_MODEL", "large-v3-turbo"),
                         device="cuda", compute_type="int8_float16")
    segs, info = model.transcribe(path,
                                  language=None if lang in ("auto", "", "None") else lang,
                                  beam_size=5, vad_filter=True)
    print(f"# {os.path.basename(path)}  语言={info.language}(p={info.language_probability:.2f})  时长={info.duration:.1f}s")
    out = []
    for s in segs:
        txt = s.text.strip()
        print(f"[{s.start:7.2f}-{s.end:7.2f}] {txt}")
        out.append({"start": round(s.start, 2), "end": round(s.end, 2), "text": txt})
    jp = os.path.splitext(path)[0] + ".transcript.json"
    with open(jp, "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=1)
    print(f"\n已保存: {jp}")


main()

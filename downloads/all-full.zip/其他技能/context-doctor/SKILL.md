---
name: context-doctor
description: Use when 要给 agent 做上下文开销体检。
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [windows, linux, darwin]
metadata:
  hermes:
    tags: [Context, Tokens, Cost, Audit, Memory]
    related_skills: [bouncer, skill-smith, hermes-agent]
---

# Context Doctor — 上下文体检

agent 每一轮都要读一遍自己的整套配置。多久没给它体检了？本技能称一遍**实际渲染进 prompt** 的重量，找出死重，开一张处方；用户批准才动手，动完给一张实测回执。

源头启发：Anthropic 自己的工程师把 Claude Code 的系统提示词删掉了 80% 以上，编码表现零损失。

## 誓约

1. **量的是渲染出来的，不是文件里写的。** 审 agent 实际拼出来的 prompt，不审磁盘上的原始文件。
2. **有原生计量器就用原生的。** 在 Hermes 上 `hermes prompt-size --json` 就是权威基线；别的地方按「字符数 ÷ 4」估算，且必须标明是估算。
3. **没有批准不删。** Doctor 只开处方，动手的是用户。
4. **回执必有。** 前后两次用同一个计量器量。

## When to Use

- 用户说「体检 / 上下文太重 / 感觉变慢变贵了 / 清一清」
- 技能库刚批量装完（新技能的 description 每轮都要付税）
- 记忆或配置改了一大轮之后

## The checkup（六项体检）

六项都要跑。每项报：量了什么、发现、每轮 token（实测，或标明是估算）。

### 1. 常驻记忆

称所有每轮必进上下文的：人格/灵魂文件、用户档案、常驻记忆（本机在 `C:/Users/111/AppData/Local/hermes/memories/`）。逐项列渲染后大小与 token。超过 2,000 token 的标记待精简。

### 2. 技能 description 税

技能花的钱是**渲染出来的**，不是 frontmatter 里写的：

- **Hermes 把每条 description 截到 60 字符**（源码 `agent/skill_utils.py` 的 `SKILL_PROMPT_DESC_LIMIT = 60`），每条技能上限约 15 token。**前 60 字符必须带触发词**，后面写了也白写。
- 用 `hermes prompt-size --json` 看技能索引的实际占用。

标记：前 60 字符里没有触发词的、触发词互相重叠的、同义词灌水的。

### 3. 僵尸技能

CUT 必须有证据：调用记录/遥测显示 30 天没用过。**没有遥测 = UNKNOWN，绝不是自动 CUT**；UNKNOWN 进观察名单。

### 4. 工具 schema 占地

列出每个会话都加载的 MCP / 工具 schema。用不到每周一次的，处方是 DEFER 或关掉。

### 5. 配置臃肿

读 `AGENTS.md`、`CLAUDE.md`、`HERMES.md` 之类：重复的、互相冲突的、只是复述默认行为的、把项目级规则写进全局文件的，都要标出来。

### 6. 披露检查

对每个留下的技能：哪些章节只在部分运行里才需要？处方是 MOVE 到按需加载的 `references/` 文件，把顶部保持小。

## The prescription（处方）

一张表，按「每轮省下的 token」从多到少排，列：发现 / 动作 / 每轮省下 / 风险。

动作只有这五种：**CUT**（隔离，不是硬删）、**MERGE**（合并去重）、**MOVE**（挪进按需文件）、**DEFER**（不用时先关）、**TRIM**（改写得更短）。UNKNOWN 项永不进处方，只在表下的观察名单里。

## The receipt（回执）

Hermes 上是**实测**不是估算：

```bash
hermes prompt-size --json     # 基线
# 只应用用户批准的处方
hermes prompt-size --json     # 之后
```

报告真实差值。非 Hermes 的兜底：把常驻文件渲染大小加技能 description 加起来，按「字符 ÷ 4」估，并标明是估算。

## Hard rules

- **隔离，不硬删。** 所有被切的都能一步恢复：

```bash
mkdir -p "C:/Users/111/AppData/Local/hermes/skills-quarantine"
mv <技能目录> "C:/Users/111/AppData/Local/hermes/skills-quarantine/"
```

- 体检全程不碰 API key、凭据、密钥文件。
- 看着像承重但看不懂的配置，先问，别开处方切掉。
- **绝不宣称自己没量过的数字**；估算一律标明是估算。

## Pitfalls

- 拿磁盘文件大小当渲染成本：文件在库里不等于进了每轮上下文。
- 凭印象背旧数字（比如「技能索引约 1.1 万字符」）——每次都要现量。
- 把 UNKNOWN 当僵尸切掉：没证据的 CUT 会切掉真在用的东西。
- 只量不改：体检的价值在用户批准后的那次实测差值。

## Verification

- 处方里每一项都能对上一条实测证据（哪来的数）。
- 回执是同一计量器的前后两次输出，差值算得出来。
- 被切的技能在隔离区能找到原目录。

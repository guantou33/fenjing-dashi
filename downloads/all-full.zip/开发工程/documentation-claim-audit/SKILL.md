---
name: documentation-claim-audit
description: "Use when auditing a doc or skill pack for false claims."
version: 0.1.0
author: Hermes Agent
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [documentation, review, audit, skills, verification]
    related_skills: [grounded-citations, systematic-debugging]
---

# Documentation Claim Audit

A read-through finds prose problems. It does not find the four defects that make a
documentation set *actively wrong*: an invented numeric limit, an invented interface
token, a counter heading that no longer matches its list, and a reference that resolves
in the source tree but dangles in the copy. This skill is the pass that finds those,
and the procedure for an "optimize this doc / find the bugs / check it with fresh eyes"
request.

Works on any doc set the agent owns: SKILL.md packs, in-house manuals, API notes,
runbooks. It does not replace citation discipline for fetched facts — that is
`grounded-citations`; this one audits claims the document asserts about a *system*.

## When to Use

- "优化这个 skill", "找 bug 修一下", "以第三个全新视角检查自己的 skill"
- Before publishing a skill or manual that quotes numbers, limits, or tag syntax
- After copying a doc set into a second tree (a skill library, a repo, a shared dir)
- When a doc the agent wrote was later contradicted by the live system

## Procedure

Do these in order; each one is cheap and they fail independently.

### ① Inventory before editing

List the files and every heading with `search_files` (pattern `^#{1,4} `) so the audit
has a map. Editing without it is how section numbers collide later.

### ② Gap-scan: derive a keyword set from the source material

From the material being folded in (official guide, upstream README, community notes),
write out the concrete terms — parameter names, format tags, named techniques, limits.
Then `search_files` each one across the doc set and record which files already cover it.

Add material **only where a keyword is missing.** This turns "improve it" into a finite
list of gaps and prevents rewriting what is already documented.

### ③ Set-difference the vocabulary against the authoritative spec

Extract every `<Tag>`, `[Tag]` and `key:value` token from the doc set and from the
official spec file it cites, then diff the sets:

```bash
python <skill_dir>/scripts/token_vocab_diff.py --doc <doc_dir> --spec <authoritative-guide.txt>
```

Anything the doc uses that the spec never defines is either a typo or an invention.
An invented token (a hand-written `<Video K>` where the spec only defines `<Video N>`)
is invisible to proofreading and invalidates every example the doc teaches. Bracket
globs in your own tooling (`references/0X-*.md`) and markdown collapsibles
(`<details>`, `<summary>`) are false positives — confirm in the spec before "fixing".

### ④ Verify every numeric limit against the live system, never a remembered figure

If the doc states a limit (max frames, max size, allowed range, timeout), read it from
the interface that enforces it:

- **Local HTTP service (ComfyUI, any JSON API):** `terminal(curl -s http://127.0.0.1:PORT/object_info)`,
  then dump each node's `input.required` / `input.optional` `min`/`max`/`default` and
  compare against the doc line by line.
- **CLI:** its `--help` / `--version` output, not the vendor blog.
- **Library:** the installed package's own schema or constants.

A limit no schema enforces ("UI 硬上限 N") must be deleted or restated as what the
schema actually says. Invented numbers are the most damaging thing a doc can carry,
because a reader has no way to tell them from measured ones.

### ⑤ Counter and numbering consistency (both directions)

- A heading that counts its list ("五条铁律", "三级清单", "七种模式") must be re-checked
after **every** insertion. `search_files` for the counter stems across all files.
- Inserting a middle section means renumbering every following section in that file;
do the renumber in the same pass, not "later".
- Cross-file: a file map that describes a file with an outdated section count is the
same defect as the heading itself.

### ⑥ Cross-file references, per tree

After any copy or sync, grep every referenced basename in **each** tree and confirm it
resolves there. Renames during packaging (`README.md` → `00-安装与移植.md`) leave
pointers that are valid in the source tree and dangling in the target.

### ⑦ Fix in place, then take the fresh-eyes pass

- Edit the sentence that misled; never append "UPDATE: actually …" underneath it.
- Third-party review = read ONLY the entry file (e.g. `SKILL.md`) as a stranger and list
everything you could not act on: a mode with no command, a step with no completion
criterion, a claim with no source. Then confirm the referenced files actually exist.
- Report at the end: what was verified against a live source, what was fixed, what is
still unverified. Do not present an unverified number as verified.

## Conventions for this user

- Reply in Chinese, progress as a percentage ("进度 80%") for long passes.
- Do the work, don't teach the method.
- Syncing a skill pack into the Hermes library: **never overwrite an existing skill.**
Create a new one where needed and only *add* cross-references to the existing one, and
re-check item ⑥ afterwards.

## Pitfalls

- **Trusting a number because it is already written down.** The doc's own earlier text
is not a source; re-derive it from the system or the spec.
- **Fixing an invented token into a nicer-looking invented token.** Compare against the
spec, not against intuition.
- **Proofreading the prose and stopping.** The defects live in headings, tokens, numbers,
and paths — all four are checkable mechanically, so check them mechanically.
- **Auditing the copy you just synced but not the original** (or the reverse). Both trees
ship; both need the pass.
- **Silent scope creep.** An optimize request is not a rewrite: keep the section order,
extend the reference files that cover the topic, and add a new reference file only for a
topic that has none.

## Verification

- Every `<Tag>` / `key:value` in the doc set appears in the authoritative spec.
- Every stated limit matches the live schema, or is labelled as unverified/removed.
- Counter headings match their list lengths; section numbers are continuous in each file.
- Every referenced file resolves in every tree the doc set is copied to.
- `scripts/token_vocab_diff.py` reports no unexplained tokens for each audited file.

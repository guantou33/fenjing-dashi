#!/usr/bin/env python3
"""Diff the interface vocabulary a doc set teaches against an authoritative spec.

Extracts <Tag>, [Tag] and key:value tokens from every markdown/text file under
--doc and from --spec, then reports per-file which doc tokens the spec never
defines. Invented tokens (a hand-written <Video K> where the spec only has
<Video N>) are the defect this catches; a token the spec uses but the doc does
not is informational only.

Usage:
  python token_vocab_diff.py --doc <dir-or-file> --spec <guide.txt> [--show-missing]

Exit 0 always; it is a report, not a gate. Read the output, then decide.
Stdlib only.
"""
import argparse
import os
import re
import sys
from collections import Counter

TOKEN_RE = re.compile(
    r"<[A-Za-z][A-Za-z0-9_ /]*>"
    r"|\[[A-Za-z][A-Za-z0-9_ /-]*\]"
    r"|\b[a-z_]{2,}:[a-z_]{2,}\b"
)

# Markdown/HTML constructs that look like tags but are not interface tokens.
IGNORE = {
    "<details>", "<summary>", "<br>", "<b>", "<i>", "<p>", "<div>",
    "<img>", "<a>", "<code>", "<pre>", "<span>",
}

TEXT_EXT = {".md", ".markdown", ".txt", ".rst", ".json", ".yaml", ".yml"}


def walk(path):
    if os.path.isfile(path):
        yield path
        return
    for dp, _dn, fn in os.walk(path):
        for f in fn:
            if os.path.splitext(f)[1].lower() in TEXT_EXT:
                yield os.path.join(dp, f)


def tokens(text):
    out = Counter()
    for m in TOKEN_RE.finditer(text):
        t = m.group(0)
        if t.lower() in IGNORE:
            continue
        out[t] += 1
    return out


def read(path):
    with open(path, encoding="utf-8", errors="replace") as fh:
        return fh.read()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--doc", required=True, help="doc dir or single file")
    ap.add_argument("--spec", required=True, action="append",
                    help="authoritative guide/spec file (repeatable)")
    ap.add_argument("--show-missing", action="store_true",
                    help="also list tokens only the spec defines")
    ap.add_argument("--ignore", action="append", default=[],
                    help="token to treat as known (repeatable)")
    a = ap.parse_args()

    known = Counter()
    for s in a.spec:
        known += tokens(read(s))
    for t in a.ignore:
        known[t] = known.get(t, 0)

    bad_total = 0
    for path in sorted(walk(a.doc)):
        unknown = {t: n for t, n in tokens(read(path)).items() if t not in known}
        if unknown:
            bad_total += len(unknown)
            print(f"{os.path.relpath(path)}:")
            for t, n in sorted(unknown.items()):
                print(f"    {t}  x{n}   <-- not in spec")

    if a.show_missing:
        used = Counter()
        for path in walk(a.doc):
            used += tokens(read(path))
        only_spec = sorted(set(known) - set(used))
        if only_spec:
            print("\nDefined by spec, unused in doc (informational):")
            print("    " + ", ".join(only_spec))

    print(f"\n{len(set(known))} spec tokens known; {bad_total} unexplained doc tokens.")
    return 0


if __name__ == "__main__":
    sys.exit(main())

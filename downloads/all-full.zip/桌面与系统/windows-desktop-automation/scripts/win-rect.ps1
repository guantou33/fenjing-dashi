# List every instance of a process with its session, window handle and window rect.
# Usage:
#   powershell -NoProfile -ExecutionPolicy Bypass -File win-rect.ps1 -Name ToDesk
# The instance whose MainWindowHandle is non-zero (and whose SessionId is the
# interactive console session) is the one computer_use can actually drive.
# Keep this file ASCII-only: PowerShell 5.1 mis-decodes non-ASCII .ps1 sources.
param([string]$Name = "ToDesk")

Add-Type @"
using System;
using System.Runtime.InteropServices;
public struct WRECT { public int Left; public int Top; public int Right; public int Bottom; }
public class WNative {
  [DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr hWnd, out WRECT r);
}
"@

$procs = Get-Process -Name $Name -ErrorAction SilentlyContinue
if (-not $procs) { Write-Output "NO_PROCESS name=$Name"; exit 1 }

foreach ($p in $procs) {
  $h = $p.MainWindowHandle
  $rect = "n/a"
  if ($h -ne [IntPtr]::Zero) {
    $r = [WRECT]::new()
    if ([WNative]::GetWindowRect($h, [ref]$r)) {
      $w = $r.Right - $r.Left
      $hh = $r.Bottom - $r.Top
      $rect = "$($r.Left),$($r.Top),$($r.Right),$($r.Bottom) SIZE=${w}x${hh}"
    }
  }
  Write-Output "PID=$($p.Id) SESSION=$($p.SessionId) HWND=$h TITLE=$($p.MainWindowTitle) RECT=$rect"
}

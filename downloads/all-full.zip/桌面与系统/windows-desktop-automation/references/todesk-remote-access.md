# ToDesk 远程接入（本机实测）

用户要求 iPhone 能长期远程控制这台 Windows 机器，ToDesk 是当前主路径。

## 进程与窗口

- ToDesk 常驻**两个同名进程**：服务实例（Session 0，`MainWindowHandle=0`）+ 交互客户端（Console 会话）。**只有交互实例能被 `computer_use` 驱动**。
- 先用 `scripts/win-rect.ps1 -Name ToDesk` 确认哪个 PID 是 UI；主窗口标题就是 `ToDesk`，它的 RECT 可直接当作 ffmpeg 全屏图的裁剪坐标。

## 凭据（重点）

- **临时密码在磁盘上不可读**：`config.ini` 里是加密字段 `tempAuthPassEx`；客户端日志只有 `action = newpassword` 这类动作记录，没有明文；UI 里密码被星号遮挡，点眼睛图标才显示。
- 因此"长期用"的正解是**在 UI 里设置固定密码（安全密码）**，不要试图解密临时密码，也不要在注册表/`strings`/日志上耗时间。
- 临时密码每次重连或重启会变，不能当长期凭据。

## 文件位置

- `C:\Program Files\ToDesk\config.ini` —— 主配置（含加密凭据与设置项）
- `%LOCALAPPDATA%\ToDesk\devlist_*.json` —— 已连接设备列表
- `%LOCALAPPDATA%\ToDesk\Logs\client*.log` —— 客户端日志，**GBK 编码**，`grep` 前先 `iconv -f GBK -t UTF-8`
- `C:\Program Files\ToDesk\mmkv.default` —— 客户端缓存，`strings` 可捞状态串

## 权限

- `net start ToDesk_Service` 返回**系统错误 5（拒绝访问）** → 需要管理员。不要重试；让用户手动提权，或走应用内设置 + 重启应用。
- 安装目录在 `C:\Program Files` 下，改配置同样需要管理员。

## 备选远程路径（本机可用性）

- **RDP**：本机是 Windows 专业版，`TermService` 可开，不依赖第三方。
- **Hermes dashboard**：`hermes dashboard`（默认 9119 端口）+ `hermes serve`，浏览器即可遥控；先 `netstat -ano` 确认端口是否已监听。
- **Tailscale**：未安装（需要组网时再装）。
- 客户端会常驻提示"版本过低/有新版本"，不影响连接，可忽略。

---
name: windows-desktop-automation
description: "Use when 驱动 Windows 原生应用、定位窗口坐标或录屏。"
---

# Windows 桌面自动化（坐标 / 录屏 / 原生应用驱动）

配合 `computer-use` 技能使用：那边管**动作词汇**（capture/click/element），本技能管**让坐标可信**、**录屏取证**，以及 Windows 上反复踩的坑。

## 铁律：坐标只从原生窗口几何来

`computer_use(action="capture", mode="som")` 返回的截图**是目标窗口本身**（例：918x586），不是整屏；vision 模型给的"估算缩放比"经常自相矛盾（同一张图算出 1.87 倍，两个轴换算结果对不上）。拿它把坐标线性缩放到整屏 → **整片裁错、点到隔壁控件**。

已验证的链路：

1. `scripts/win-rect.ps1` 拿目标窗口的**原生矩形**（Left/Top/Right/Bottom）——它同时告诉你哪个进程才是 UI（`MainWindowHandle` 非 0 的那个）。
2. 抓全屏真图：`ffmpeg -f gdigrab -framerate 1 -frames:v 1 shot.png`（物理分辨率，例 2560x1440）。
3. 按矩形裁剪并放大再读：`Image.open("shot.png").crop((L,T,R,B)).resize((w*2,h*2))` → `vision_analyze`。裁出来的小图能逐字读清，就说明坐标是对的（读不清就是坐标错，别怪模型）。
4. 点击优先用 som 元素清单的 `element=N`；确需坐标时用元素 bounds（原生桌面坐标）或第 1 步矩形换算，**不要用截图像素**。

## 找准 UI 进程：同名进程多实例

Windows 常驻软件（ToDesk、AnyDesk、输入法等）常有**两个同名进程**：服务实例在 Session 0（`MainWindowHandle=0`，点了没反应），交互实例在 Console 会话。取错实例 → 窗口明明在屏幕上却抓不到、`EnumWindows`/UIA 找不到可见窗口。

`scripts/win-rect.ps1` 列出**每个实例**的 `Id / SessionId / MainWindowHandle / Title / RECT`，一眼挑出 `MainWindowHandle≠0` 的那个。

## PowerShell 脚本一律用纯 ASCII 写

Windows PowerShell 5.1 读含中文的 `.ps1` 会因编码（GBK/无 BOM）乱码甚至报错。脚本里**注释也用英文**；中文只出现在命令行参数和输出解读里。

## 录屏（用户说"录屏"时）

```bash
mkdir -p "C:/Users/111/Desktop/<任务名>录屏" && cd "C:/Users/111/Desktop/<任务名>录屏" && \
  "$FFMPEG" -y -f gdigrab -framerate 8 -i desktop -t 900 \
  -c:v libx264 -preset ultrafast -crf 28 -pix_fmt yuv420p out.mp4
```

- 用 `background=True` 起（不要 `nohup`/`&`，Hermes 终端自己管后台），`-t` 秒数写死，别录到无限。
- 输出落到**用户桌面的独立文件夹**，不要丢 scratch —— 用户要自己拿到这个文件；录完用 `MEDIA:<绝对路径>` 发给他。
- 结束时 stderr 会出现 `frame= / time= / kb/s`；再用 `ffprobe -v error -show_entries format=duration,size` + `ls -la` 校验，把真实大小和时长报给用户。
- ffmpeg 不在 PATH 时：WinGet 装的位置在 `%LOCALAPPDATA%\Microsoft\WinGet\Packages\Gyan.FFmpeg*\<版本>-full_build\bin\`。

## 需要管理员权限的操作：试一次就停

`net start <服务>`、改 `C:\Program Files` 下的文件等会返回**系统错误 5（拒绝访问）**。不要换写法反复重试——当前会话没有提权能力。直接告诉用户"这一步需要你手动以管理员身份做"，或改走不需要提权的路径（用户级配置、应用内设置界面、重启应用而不是重启服务）。

## 读不到就换证据来源

有些值**在磁盘上根本不可读**：应用把密码/凭据加密存（如 ToDesk 的 `tempAuthPassEx`），UI 控件读出来是空的，日志里只有动作记录。此时别在注册表/`strings`/日志上继续耗时间——转去 UI 层取证（点开显示图标、进设置界面截图），或把配置改成不依赖该值的形态。

## 汇报

中文、结论先行、带进度百分比。没验证的环节直说"未验证"，不要把推测讲成已验证。

## 参考

- `references/todesk-remote-access.md` —— ToDesk 固定密码与远程接入的实测事实、文件位置、备选路径。
- `scripts/win-rect.ps1` —— 列出同名进程所有实例的 SessionId / MainWindowHandle / 窗口矩形。

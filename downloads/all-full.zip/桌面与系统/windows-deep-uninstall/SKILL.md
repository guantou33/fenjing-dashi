---
name: windows-deep-uninstall
description: Use when 彻底卸载 Windows 顽固软件或文件删不掉时。
---

# Windows 顽固软件深度卸载

目标：程序、缓存、数据、注册表、服务、启动项、快捷方式、外壳扩展**零残留**。
每步都要复检，不要假设删除成功。

## 顺序

1. 关进程 → 2. 删文件（提权）→ 3. 清注册表 → 4. 重启外壳宿主 → 5. 复检

## 陷阱 1：同卷移动保留 ACL，移到哪都删不掉

同卷 `Move-Item` 等于重命名，**原 ACL 跟着走**。从 `C:\Program Files` 移到用户目录后，
文件仍带 `Administrators:FullControl / 用户:Read`，用户身份删不掉。

解决（提权）：
```
takeown /f "$t" /r /d y
icacls "$t" /setowner "111" /t /c
icacls "$t" /grant "111:(F)" /t /c
Remove-Item -LiteralPath "$t" -Recurse -Force
```
`/grant` 单独用不够，必须配 `/setowner`。

## 陷阱 2：DLL 被外壳扩展宿主加载 → 权限再高也删不掉

症状：ACL 全开、属性只有 Archive、`Remove-Item` 报 UnauthorizedAccessException；
或者**能重命名但不能删**（父目录有 FILE_ADD_FILE，文件自身 DELETE 被占用挡掉）。

定位是删不掉时的**第一步**，别在权限上瞎折腾：
```powershell
Get-Process | ForEach-Object {
  $p=$_
  try { $p.Modules | Where-Object { $_.FileName -match '<关键词>' } |
        ForEach-Object { "$($p.Id) $($p.ProcessName) -> $($_.FileName)" } } catch {}
}
```

Adobe 的 `CoreSync_x64.dll`（资源管理器右键扩展）会被 **explorer.exe** 和
**微信 / QQ 等 shell 扩展宿主**同时加载。释放句柄：
```powershell
Stop-Process -Name explorer -Force; Start-Sleep 3; Start-Process explorer.exe
Stop-Process -Name Weixin  -Force; Start-Sleep 4
Start-Process 'C:\Program Files\Tencent\Weixin\Weixin.exe'
```
重启前先查 `(Get-Process Weixin).Path` 拿真实路径（微信 4.x 是 `Weixin`，旧版 `WeChat`）。

## 陷阱 3：注册表通配符路径极慢

`HKLM:\SOFTWARE\Classes\*\shellex\ContextMenuHandlers` 会让 PowerShell 展开整个
Classes 树（十几万键），能跑几十分钟且持续吃满一核。**用固定路径清单代替**：

- `Classes\Directory\shellex\ContextMenuHandlers`
- `Classes\Directory\Background\shellex\ContextMenuHandlers`
- `Classes\Folder\shellex\ContextMenuHandlers`
- `Classes\AllFilesystemObjects\shellex\ContextMenuHandlers`
- `Classes\Drive\shellex\ContextMenuHandlers`
- `Microsoft\Windows\CurrentVersion\Shell Extensions\Approved`
- `Explorer\ShellIconOverlayIdentifiers`

（HKLM 与 HKCU 各查一遍；`Approved` 是**值**不是子键，值名即 CLSID。）

## 陷阱 4：删完外壳扩展要重启 explorer

删了 CLSID 注册但 explorer 还持有内存引用，重启 explorer 才真正卸载。

## 清点清单（Adobe）

程序：`Program Files\Adobe`、`Program Files (x86)\Adobe`、两处 `Common Files\Adobe`、
以及**自定义安装路径**（用户可能装在 `C:\PS`、`C:\LR` 这种非标准位置，官方卸载器不认）。

缓存/数据：`C:\ProgramData\Adobe`、`%LOCALAPPDATA%\Adobe`、`%APPDATA%\Adobe`、
`%LOCALAPPDATA%Low\Adobe`；Lightroom 的 `*.lrdata` 预览库可达 17 GB，
但同目录 `.lrcat`（编目/参数）只有几百 MB，**要保留**。

注册表：`HKCU|HKLM|HKLM\WOW6432Node\SOFTWARE\Adobe`；
三处 `...\CurrentVersion\Uninstall` 下的 Adobe 条目；CoreSync 的 4 个 CLSID
（删前记录它们原来指向的 DLL 路径，便于确认）。

## 权限要点

- 读 HKLM 注册表：非提权即可
- 写/删 HKLM、`takeown` Program Files：必须提权
- 提权：把逻辑写成 `.ps1`（UTF-8 **带 BOM**，否则中文乱码），再
  `Start-Process -Verb RunAs -Wait -PassThru -ArgumentList '-File', $path`，
  别用 `-Command` 拼长串（引号地狱）
- 提权会弹 UAC，**事先告诉用户**
- 非提权进程**无法**终止提权进程（Stop-Process 静默失败）；提权脚本卡住时要再提权一次才能杀
- 长任务把结果写日志文件再读回，别指望终端一次调用拿完输出

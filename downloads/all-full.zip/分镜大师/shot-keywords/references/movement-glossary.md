---
name: movement-glossary
description: 当你需要把运镜意图翻成中英提示词、或要查推/拉/摇/移/升降/跟/甩与环绕/摇臂/FPV 等词的英文写法与常见错误时翻它。给基础与进阶运镜的中英对照、易混词区别表、速度词表、AI 提示词模板与避坑清单。
---

[定位]
    本文件是运镜词的"中英对照 + AI 写法"工具。词怎么填进六槽、成句规则归 camera 的 SKILL.md 与 references/movement-dictionary.md；本文件只管"这个词英文怎么写、容易跟谁混、怎么写模型才照做"。

[基础七件]
| 中文 | 英文 | 机位动不动 | 一句话 |
|---|---|---|---|
| 推 | dolly in / push in | 机位沿光轴前进 | 收窄注意力、逼近、压迫 |
| 拉 | dolly out / pull out | 机位沿光轴后退 | 交出语境、揭示环境、收束 |
| 摇 | pan（水平）/ tilt（垂直） | 机位不动，机身转 | 环顾、揭示横向/纵向空间 |
| 移 | truck（横移） | 机位整体平行移动 | 展现横向空间、跟拍 |
| 升/降 | pedestal up / down | 机位整体垂直升降 | 揭示隐藏元素、匹配起立/下蹲 |
| 跟 | tracking / follow | 机位跟着主体走 | 跟随感、与角色同行 |
| 甩 | whip pan / swish pan | 极快水平摇 | 暴烈转移注意力、藏剪辑点 |

[进阶]
| 中文 | 英文 | 备注 |
|---|---|---|
| 环绕 | orbit shot / arc shot | 主体居中、背景旋转；强形式，克制用 |
| 半环绕 | 180° half-orbit | 对话与对峙用，背景在身后旋转揭示 |
| 摇臂 | crane shot / jib | 大幅升降，常带弧线扫过 |
| 手持 | handheld | 写成摄影师的身体行为：呼吸起伏、微幅落定、重心转移 |
| 斯坦尼康 | steadicam | 去抖的平滑移动 |
| 希区柯克变焦 | dolly zoom / vertigo effect | 推拉与变焦反向同时；整条只此一记 |
| 移焦 | rack focus / focus pull | 机位不动，焦点换平面 |
| 固定机位 | static shot / locked off | 必须显式声明，否则模型自己加漂移 |
| 荷兰角 | dutch angle | 画框地平线倾斜 |
| 鸟瞰/顶视 | top-down / bird's eye | 正上方 90° |
| 贴地 | ground-level / worm's eye | 镜头贴近地面 |
| 光学变焦 | optical zoom in / out | 固定机位、焦段变化 |

[特殊与风格]
| 中文 | 英文 |
|---|---|
| FPV 穿越机 | FPV drone shot |
| 无人机俯掠 | drone flyover |
| 子弹时间 | bullet time |
| 延时摄影 | time-lapse |
| 慢动作 | slow motion / high frame rate |
| 长焦压缩 | telephoto, compressed background |
| 广角畸变 | ultra wide angle, fisheye distortion |
| 浅景深 | shallow depth of field / bokeh |
| 剪影 | silhouette, backlit |
| 监控视角 | CCTV / security camera style |
| 夜视 | night vision, green, grainy |

[最容易混的四对]
    推 dolly vs 变焦 zoom：dolly 是机位真的在走，背景跟着变、有视差，读起来"置身其中"；zoom 是焦段放大，透视不变、背景不分离，读起来"旁观"。要哪个写哪个，别混着写。
    摇 pan vs 移 truck：摇是机位不动、机身转，背景跟着转但没有视差；移是机位整体平移，前景与背景以不同速度分离，所以移看起来"像真实空间"。
    升/降 pedestal vs 摇臂 crane：pedestal 是机位垂直升降、机身姿态不变；crane 是大幅升降且常带弧线扫过。
    环绕 orbit vs 弧形 arc：orbit 绕满一圈（360°），arc 只走一段（约 90°–180°）。

[速度词表]
    极缓（几不可察的沉浸，情绪长镜专用）／缓（悬念、分量、紧张逼近）／平稳（浪漫、平静）／稳（常规）／轻柔／渐进（随时间积累）／快（动作、肾上腺素）／骤然／强动感。
    英文侧用 slow / gentle / steady / smooth / gradual / rapid / fast / violent / sudden 这组更稳，比写具体秒数靠谱。
    缺方向或缺速度，运动就退化成废话："镜头移动"无效，"缓推"才是指令。

[AI 提示词模板]
    ```
    [景别], [机位角度], [速度+运动] over/in [场景], on [主体+动作], [光学], [光线/氛围]
    ```
    实例：
    ```
    中近景，低角度，缓慢推轨推进，一名侦探在雨中点烟，35mm 镜头浅景深，霓虹反光。
    ```
    ```
    Medium close-up, low angle, slow dolly push-in, on a detective lighting a cigarette in the rain, 35mm lens with shallow depth of field, neon reflections.
    ```

[AI 写法避坑清单]
| 坑 | 模型会怎么干 | 修法 |
|---|---|---|
| 只写 dolly 却想要变焦效果 | 透视被压平 | 明确写 dolly（机位走）还是 zoom（焦段变） |
| 一条提示词塞多段运动 | 漂移、中途重置构图 | 一个片段只写一种运动，复合运动靠首尾帧接 |
| 只写"摄影机向左横移" | 主体也跟着往旁边滑 | 补一句"主体保持不动，仅镜头移动" |
| 需要完全静止却不声明 | 模型默认带轻微漂移 | 写 locked off / static camera，删掉所有位移动词 |
| 用秒数控制速度 | 响应不稳 | 改用 slow / rapid / violent 这类速度词 |
| 写"很有电影感地移动" | 取平均，退化成静止或飘 | 拆成方向 + 速度 + 具体运动 |
| 同句既写固定机位又写环绕 | 指令冲突，乱融合 | 一镜一个主运动 |

[与 Seedance 系模型的配合]
    运动写在运镜句最前——prompt 前部权重最高。
    中文专业术语（缓推、荷兰角、大特写、环绕）有精确响应；形容词（电影感、高级、史诗）几乎被无视。
    结果语言优先：写"背景压平成柔色浆"比写"85mm f/1.4"稳。

#!/usr/bin/env python
"""打印 Hermes /model 选择器真实会列出的分组、模型与别名。

用法（用安装环境的 venv python，工作目录随意）：

    HERMES_HOME="$LOCALAPPDATA/hermes" \
      "$LOCALAPPDATA/hermes/hermes-agent/venv/Scripts/python.exe" \
      dump_model_picker.py

为什么必须用脚本实测：/model 的内容由 config.yaml + auth.json 的 credential_pool
+ 端点缓存 合成。只看 `hermes config get <provider>` 会回 "Config key not set"，
但该服务商照样出现在列表里；反过来也可能看着剩一堆、实际已清空。

不要改用 get_authenticated_provider_slugs()：它不接收 config 里的自定义服务商，
只会打印 0 个分组，容易误判成「全清干净了」。
"""

import os
import sys

import yaml

home = os.environ.get("HERMES_HOME") or os.path.join(
    os.environ.get("LOCALAPPDATA", ""), "hermes"
)
repo = os.path.join(home, "hermes-agent")
sys.path.insert(0, repo)

cfg_path = os.path.join(home, "config.yaml")
with open(cfg_path, encoding="utf-8") as fh:
    cfg = yaml.safe_load(fh) or {}

from hermes_cli.model_switch import list_authenticated_providers  # noqa: E402

provs = list_authenticated_providers(
    max_models=0,
    non_blocking_catalogs=True,
    user_providers=(cfg.get("model") or {}).get("providers") or {},
    custom_providers=cfg.get("custom_providers") or [],
)
print("服务商分组数:", len(provs))
for p in provs:
    models = p.get("models") or []
    ids = [m if isinstance(m, str) else m.get("id") for m in models]
    print("  -", p.get("slug"), "|", p.get("name"), "|", ids)

aliases = (cfg.get("model") or {}).get("aliases") or {}
print("别名行:", {
    k: (v or {}).get("model") if isinstance(v, dict) else v
    for k, v in aliases.items()
})

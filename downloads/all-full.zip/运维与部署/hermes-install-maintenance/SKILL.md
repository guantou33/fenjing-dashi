---
name: hermes-install-maintenance
description: Use when 更新/修 Hermes 源码安装，或清/查 /model 列表与配置残留。
---

# Hermes 本机源码安装：更新与维护

适用：`<HERMES_HOME>\hermes-agent` 这种源码安装（不是 pipx / 单文件安装），要跑 `hermes update`、处理本地改动、升级后验证。

清 `/model` 列表（删模型、删服务商分组、配置看着干净但列表仍残留）见 `references/model-registry-cleanup.md`，实测脚本 `scripts/dump_model_picker.py`。通用判据：**Hermes 的"表面"（CLI 列表、`config get` 回显）由多层数据合成，改完配置层不等于生效**——改完必须调真正的枚举函数实测（见该 reference 的验证段），不要靠读配置文件下结论。同理，**声称"已保存/已下载/已打开"之前必须先列目录确认文件真的存在**，读图、下载、写文件都适用。

## 铁律

1. **动 Hermes 源码前先问：升级会不会冲掉它？** 能用配置解决的（模型别名、语言、网关、平台）一律走 `hermes config set`，绝不改源码。**尤其不要为了汉化手改代码**——上游自带 i18n（`locales/<lang>.yaml` + `config.yaml` 的 `display.language`，`hermes config set display.language zh`），手改的补丁下次升级必被覆盖，而且上游键名还会变。做汉化前先跑一次 i18n 实测（见下），很可能上游已经翻了。
2. **升级前先存本地改动**：`git diff > <HERMES_HOME>/backup/local-edits-<日期>.patch`，未跟踪文件另存；再把整个 `.git` 挪到 `backup/git-dir-<日期>/`。
3. **`.git` 挪走的代价：`hermes --version` 显示 `vunknown` / `Install method: unknown`。** 这是为让 ZIP 覆盖更新不被「本地改动检查」拦下而做的取舍，不是故障。用户问起就这么解释，**不要去"修"它**（放回 .git 会让以后每次更新都被拦）。
4. **更新会重启网关、可能打断你当前的 CLI 会话**：把「停网关 → ZIP 覆盖 → 重打补丁 → 起网关」写成一个 bash 脚本落到 `cache/scratch/`，全程 `>> 日志文件`，然后从日志判断结果，而不是依赖会话里看到的输出。
5. 升级后必查三项：`hermes --version`、`hermes gateway status`、`hermes pm doctor`。源码覆盖成功 + 网关进程是更新后新起的 PID + 用户能正常发消息进来 = 更新真的生效。
6. **长任务要边做边发进展**，不要只在结束时发一份汇总——收尾那次发送可能失败，用户就完全不知道状态（见 `hermes-messaging-gateway` 的发送坑）。
7. **覆盖更新后必须重启网关进程，否则新旧模块混用**：ZIP 覆盖只换磁盘文件，正在跑的网关仍持有旧模块；下一条入站消息触发加载新代码时对不上，抛 `ImportError: cannot import name ... from ...`，并把整段 traceback 当回复发给用户（同一条报错每次回复的长度相同，可当指纹用）。判据：网关 PID 的启动时间晚于被改文件的 mtime。核验磁盘代码健康不要靠肉眼读文件，直接在安装 venv 里 import 那个符号：

```bash
cd <HERMES_HOME>/hermes-agent && ./venv/Scripts/python.exe -c "from gateway.platforms.base_exec_approval import ea_default_reason_text; print('ok')"
```

注意「磁盘代码已一致 + 网关已用新代码重启」只说明*应该*好了；要有更新后一次真实入站消息被正常回复，才算验证过。

## 网关起不来 / 微信掉线：先查启动链的解释器

症状：网关能起但**微信平台缺席**（日志 `No adapter available for weixin`），或 `gateway.run: Supervised task hosted_room_worker died: ModuleNotFoundError("No module named 'pydantic_core._pydantic_core'")` 反复重试 5 次后放弃。

根因是**启动脚本用的解释器与依赖包的 ABI 版本对不上**，不是微信配置问题。典型场景：安装目录里留着旧的 `hermes-agent/venv`（3.11 垫片），它再 exec `.hermes-runtime` 的裸 3.11 解释器，而 PM 提交的依赖环境是 cp314 的（`installs/<hash>/environments/<hash>/venv`），3.11 加载 cp314 的 `pydantic_core` 扩展必炸。

诊断（看命令行就能定案）：

```bash
powershell -NoProfile -Command "Get-CimInstance Win32_Process -Filter \"Name='python.exe'\" | ForEach-Object { '{0} | {1} | {2}' -f \$_.ProcessId, \$_.ParentProcessId, \$_.CommandLine }"
```

守护进程应当直接是 `tools/python-3.14.7+<build>/python.exe -m hermes_cli.main gateway run`；若显示 `hermes-agent\venv\Scripts\python.exe` 或 `.hermes-runtime\python\cpython-3.11-...` 就是坏的。

修法（重装启动器，**不需要提权、不弹交互**，因为 `_write_task_script()` 只是写 `gateway-service/` 下的 cmd+vbs，开机项写的是用户目录里的 Startup）：用**提交环境的**解释器跑，`get_python_path()` 会按 `facts.json` 自动解析出正确的 store python：

```bash
ENV="$HERMES_HOME/installs/<install-hash>/environments/<env-hash>/venv"
PYTHONPATH="$HERMES_HOME/hermes-agent;$ENV/Lib/site-packages" HERMES_HOME="$HERMES_HOME" "$ENV/Scripts/python.exe" -c "
from hermes_cli import gateway_windows as gw
from hermes_cli.gateway import get_python_path
print(get_python_path())
p = gw._write_task_script(); print(p, gw._install_startup_entry(p))
print(p.with_suffix('.vbs').read_text(encoding='utf-8'))"
```

确认新 vbs 里的 `sh.Run` 指向 `tools\python-3.14...\python.exe`（不是 venv 垫片），再 `taskkill` 旧守护进程并用该 vbs 重启（`wscript "...Startup\Hermes_Gateway.vbs"`，`sh.Run ...,0,False` 会自行脱离）。判据：日志出现 `[Weixin] Connected account=...` + `✓ weixin connected`，且重启时间点之后不再有 `died` / `pydantic_core` 报错（历史报错留在日志里，要按时间戳区分，别拿全文件 grep 计数当结论）。

同理，`hermes gateway install` 走交互式向导（`_prompt_install_choices`，可能触发 schtasks/提权），自动化场景直接调上面两个下划线函数更稳。

## 本地改动挡路时的 ZIP 覆盖更新

1. 存改动：见铁律 2。补丁要先 `patch -p1 --dry-run` 验一遍，`uv.lock` 这类文件从补丁里剔除，避免一个文件失败拖垮整批。
2. 挪 `.git` 到 `backup/`。
3. 跑 `hermes update`（ZIP 回退路径：`hermes_cli/update_cmd_zip.py`）。注意该路径**只支持 main 分支**，`--branch` 其它值会被明确拒绝。
4. 更新完 `hermes gateway stop` → 后台 `hermes gateway run`，再用 `hermes gateway status` 确认新 PID。
5. 重打本地补丁时**不要照抄旧补丁**：上游同文件往往已重写（同一函数换了实现），补丁会整片 FAILED。先读新版代码对应位置，判断这个改动还有没有必要，再决定重做还是丢弃。

## 验证 i18n / 中文界面

不要靠肉眼猜翻译有没有生效，直接在安装目录里跑：

```bash
cd <HERMES_HOME>/hermes-agent
./venv/Scripts/python.exe -c "import agent.i18n as i; print(i.get_language()); print(i.t('display.iteration_progress.bounded', n=3, max=25))"
```

- 语言取 `display.language`（`hermes config set display.language zh` 可改），函数名是 `get_language()` / `t()`，没有 `current_language()` / `resolve_language()`。
- 键不存在时 `t()` 原样返回键名（如 `gateway.busy.working_heartbeat`），这本身就是「该键没翻译」的判据。

## 别追的假故障

- `gateway status` 里的 `install out of sync (ffmpeg/node/npm/ripgrep)`：这些是 Hermes 自管的那一份组件过期，只要 `command -v` 能在系统 PATH 上找到能用的版本就不影响功能，别花时间重装。
- `curl -o /dev/null -w ...` 同时报 `(23) client returned ERROR on write`：写盘/管道问题，只要 `-w` 打出的 HTTP 码是 200 就算通，不是网络失败。
- 更新日志里 python runtime / 资源站的下载超时：源码覆盖和运行时不一定是同一批下载，源码部分成功、网关能起，就先把结论报给用户，别把整件事说成失败。

## 长会话变慢 / 压缩失败的两个配置坑

- `model.context_length` 写死后若低于供应商实际额度（例如写 65536 而供应商给 1M），每轮都警告 pin 生效，长会话被反复压缩、越跑越慢。能用供应商默认就别写这一行。
- 辅助压缩指向本地小模型 + 600s 超时：超时后退化成确定性摘要，再超就整轮放弃，长会话持续退化。压缩模型指到远端，或调大超时。

## 精简 /model 列表、锁定服务商模型

清空选择器里多余模型时按这个顺序做，漏一步列表就不干净：

1. 先快照 `config.yaml` 到 `cache/scratch/`。`config.yaml` 受保护，`write_file`/`patch` 一律被拒，改配置只能用 `<HERMES_HOME>/hermes-agent/venv/Scripts/hermes config set|unset`。
2. 逐个删别名：`hermes config unset model.aliases.<名>`。键名写错**不报错也不生效**，删完必须回读 `hermes config get model.aliases` 确认，不要凭「命令没报错」就宣布成功。
3. 服务商一起收：`hermes config set custom_providers '<JSON 数组>'`，数组里只留要保留的那家。
4. **端点上的模型会自己冒回来**：想只显示指定几项，`models` 必须写成**列表**（真实 id）并配 `models_discovered: false` + `discover_models: false`。写成 dict 形 `models:` 且 `models_discovered: true` 会被当成「自动发现目录」，端点提供的每个模型都会重新出现在选择器里。
5. 删端点缓存 `cache/endpoint_model_metadata.json`，否则旧模型元数据还在。
6. 服务商条目的 `model` 字段必须是真实模型 id，写中文标签会 503。
7. 本地模型用 `ollama rm <模型>`；**删之前先看 `auxiliary.vision` / `auxiliary.compression` 指向谁**——删掉读图或压缩模型，能力会静默丢失，连报错都没有。
8. 桌面 .bat / 脚本里常写死旧别名，删完要一并改，否则用户点一下就报错。

## 深度参考

- `references/update-paths.md`：git 与 ZIP 两条更新路径的差异、下载 URL 换 codeload 域名的方法与验证命令、哪些动作会静默失败。
- `references/troubleshooting-triage.md`：日志地图（agent/gateway/errors/state.db）与「用户报错 → 定位 traceback → 判断是否真修好」的关联方法。

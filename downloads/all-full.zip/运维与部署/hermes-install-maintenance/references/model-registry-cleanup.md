# /model 模型列表清理

目标：让 `/model` 选择器只剩用户要保留的模型，其余彻底删净、不留备份。

## 列表由多层数据合成，任一层没清都会残留

| 层 | 位置 | 对应列表项 |
|---|---|---|
| 别名 | `config.yaml` → `model.aliases` | 别名行 |
| 自定义服务商 | `config.yaml` → `custom_providers` | 服务商分组 |
| 凭据池 | `auth.json` → `credential_pool` | **服务商分组**（即使 config 里已无该服务商） |
| 端点缓存 | `cache/endpoint_model_metadata.json` | 端点 `/v1/models` 自动发现的模型 |
| 环境变量 | `.env` 里 `*_API_KEY`、`HERMES_CUSTOM_<SLUG>_API_KEY` | 会重新播种凭据池 |

**最容易漏的是凭据池那一层**：服务商从 `custom_providers` 删掉后，`hermes config get <provider>` 会回 `Config key not set`，配置看起来已经干净，但它照样出现在 `/model` 里。用户说「分组还在」时先看 `hermes auth list`，别去重查 config。

## 步骤

1. 备份：`cp config.yaml cache/scratch/config_before_*.yaml`；`cp auth.json cache/scratch/auth_before_*.json`。
2. 清别名与服务商。config.yaml 有写保护，**只能用 CLI**（`write_file` / `patch` / 直接编辑一律被拒）：

```bash
hermes config unset model.aliases.<name>
hermes config set custom_providers '[{"name":"...","base_url":"...","key_env":"...","model":"<真实id>","api_mode":"chat_completions","models":["<真实id>"],"models_discovered":false}]'
```

3. 清凭据池：先 `hermes auth list` 看清有哪些，再 `hermes auth remove <provider> <index|id|label>`。它会顺手把 `.env` 里对应的 KEY 清掉并写入 `suppressed_sources`，防止变量再被导出时复活。
4. 清 `.env` 孤儿：删掉已删服务商残留的 `*_API_KEY`、`HERMES_CUSTOM_*_API_KEY`。逐行过滤写回，保留其余行（别整文件重写，WeChat/Browser 那些配置项要留）。
5. 清端点缓存：`rm cache/endpoint_model_metadata.json`。
6. 跑下面的实测验证，不看配置猜。

## 坑

- **别名形态的服务商在凭据池里用 CLI 删不掉**：`hermes auth remove deep-infra 1` 会被归一到规范名（`deep-infra` → `deepinfra`）并报 `No credential #1. Provider: deepinfra.`，但 `auth list` 里那条依旧在。这类只能直接改 `auth.json`：删掉 `credential_pool["<slug>"]` 键，并给 `suppressed_sources["<slug>"] = ["env:VAR"]`（只抑制规范名不够）。`auth.json` 不受 config.yaml 那层保护，用 python 读改写即可，改前先 cp。
- **想锁死一个服务商只暴露一个模型，`models` 必须写成列表或字符串，不能写字典**，并配 `models_discovered: false`。机制：`_models_config_is_allowlist()` 只把 list/string 形态当白名单；dict 形态被视为「已发现的缓存」而非白名单，端点照样会去拉 `/v1/models` 把别的模型带回来。
- **端点缓存会把删掉的模型带回来**：`cache/endpoint_model_metadata.json` 会记下端点 `/v1/models` 的全部模型。删掉文件 + `models_discovered: false` 才能压住自动发现。
- **别顺手删正在兼任 auxiliary 的本地模型**：`auxiliary.vision` / `auxiliary.compression` 可能指向本地 Ollama 模型。删权重前先 `hermes config get auxiliary.vision` 看一眼，删了就读不了图了。这类要跟用户确认，别自作主张清空。

## 验证（必须做）

实测脚本：`scripts/dump_model_picker.py`（用安装环境的 venv python 跑），或等价地内联：

```python
from hermes_cli.model_switch import list_authenticated_providers
provs = list_authenticated_providers(max_models=0, non_blocking_catalogs=True,
                                     user_providers=cfg.get('model',{}).get('providers') or {},
                                     custom_providers=cfg.get('custom_providers') or [])
```

输出应当只剩你要保留的服务商和模型。**不要改用 `get_authenticated_provider_slugs()`**——它不接收 config 里的自定义服务商，会打印 0 个分组，容易被误判成「全清干净了」。

## 不在列表里但引用模型的地方（别漏报给用户）

- `moa.presets[].reference_models[]`：只在用 MoA 时生效，不进 `/model` 列表（`active_preset` 为空时完全没用）。清列表不必动，用户要求时再清，并主动说明这一点。
- `auxiliary.vision` / `auxiliary.compression`：见上面的坑。
- 桌面或 `Downloads` 里的一键切换脚本（如 `一键切换模型.bat`）：里面写的是旧别名，清完后要提醒用户点了会报错。

## 与用户沟通

- 用户要的是「列表干净」和「彻底删无备份」，但删本地模型权重释放空间是另一件事。**把「清列表」和「删权重」分开处理**：清列表可以直接做，删权重（不可逆、而且可能砍掉读图能力）先给一个极简的二选一，不要闷头一起删。
- 汇报时给「删了什么 / 留了什么 / 实测输出 / 备份在哪」四段，备份路径一定要给（用户可能第二天就想要回来）。

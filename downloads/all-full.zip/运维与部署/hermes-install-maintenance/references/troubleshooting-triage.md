# Hermes 本机故障排查：日志地图与关联方法

用户报「发消息就收到一段报错」时用这套流程定位，不要靠猜。

## 日志在哪（`<HERMES_HOME>` 下）

- `logs/agent.log` — 每轮 API 调用、工具调用、会话事件，行首带 session id。
- `logs/gateway.log` — 入站消息、平台连接状态；**出站消息不写这里**。
- `logs/errors.log` — traceback 与 WARNING/ERROR。
- `state.db` — SQLite，`sessions` / `messages` 表是「实际发生了什么」的权威记录（比日志更完整）。
- `gateway_state.json`、`logs/gateway-starts.log` — 网关当前进程视图与历次启动。
- `logs/update_receipts/`、`logs/update.log` — 更新到底有没有落地。

## 关联一条用户可见的故障

1. 在 `agent.log` 搜 `Sending response (<N> chars)`，拿到确切时间点与回复长度。
2. 用该时间戳去 `errors.log` 找 traceback 首行（`ImportError` / `TypeError` / `APIConnectionError` / `TimeoutError`），拿到出错模块与行号。
3. 回源码看那一行：模块级 import（启动即崩、每条消息必崩）还是函数内 import（只在特定分支崩）。
4. 判「是不是已经好了」要三条同时满足：磁盘代码 import 成功 + 网关 PID 启动时间晚于代码 mtime + 更新后有过一次真实入站消息被正常回复。前两条只说明*应该*好了。

## 会话租约

`session turn lease wait timed out` = 某个卡死的主会话占着租约，会把微信入站和单次任务**全部**堵住，表现为任务拿到租约后 0 次模型调用（假失败）。网关启动时会清理陈旧租约；反复出现就要查是谁长时间占着。

## 已知噪声（别当故障报给用户）

- `concurrent-log-handler unavailable ... pywintypes is required`、`Failed to load plugin ...: No module named '_cffi_backend'` — 缺可选依赖，日志照写。
- `install out of sync (ffmpeg/node/npm/ripgrep)` — 见 SKILL.md「别追的假故障」。
- 账号侧 429 并发超限 — 限流，与安装无关。
- 工具集告警（teams / google_chat 之类未配置平台）— 未启用即噪声。

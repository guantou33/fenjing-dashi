# Hermes 更新路径细节

## 两条路径

| | git 路径 | ZIP 回退路径 |
|---|---|---|
| 触发 | `.git` 存在且 git 文件 I/O 正常 | git 不可用 / 文件 I/O 被占用 |
| 代码来源 | 拉取增量 | 整包覆盖（`hermes_cli/update_cmd_zip.py`） |
| 分支 | 任意 | 只支持 main，其它分支直接退出并提示 |
| 本地改动 | dirty tree 会拦 | `_abort_zip_update_if_dirty_tree()` 同样会拦 |
| 版本号 | 正常（有 git 元数据） | `.git` 被挪走 → `vunknown` / `Install method: unknown` |

两者都会被「本地改动检查」拦下，所以处理本地改动的顺序永远是：存补丁 → 挪 `.git` → 更新。

## 诊断命令

- `hermes update --plan`：只诊断不落地，用来确认它打算走哪条路、目标 SHA 是什么。
- `hermes update --check`：检查可用更新；长时间无输入可能自动放行，别把它当纯只读命令。
- `hermes --version`：输出里带 `Install directory`，路径以它为准。

## 下载 URL：github.com 走不动时换 codeload 域名

ZIP 路径拼的 URL 形如：

```
https://github.com/<owner>/<repo>/archive/<ref>.zip     # ref = refs/heads/main 或 40 位 SHA
```

在 github.com 的 archive/release 下载会卡住的网络里，等价的 codeload 直连地址是：

```
https://codeload.github.com/<owner>/<repo>/zip/<ref>    # 注意没有 .zip 后缀，路径是 /zip/ 而不是 /archive/
```

改法：在 `hermes_cli/update_cmd_zip.py` 里找到拼接 `archive/{ref}.zip` 的那一行（约 407 行，ZIP 回退入口函数内），把 URL 换成 codeload 版本，并留一行注释说明为什么。

**先验证再改**，别拿整包更新当试验：

```bash
curl -sS -o /dev/null -w "HTTP %{http_code}  %{time_total}s\n" --max-time 40 -L \
  "https://codeload.github.com/NousResearch/hermes-agent/zip/refs/heads/main"
```

期望 `HTTP 200`。

**这是手改源码，下次更新会被覆盖**：升级后要重新确认那一行还是不是 codeload 地址（`grep -n codeload hermes_cli/update_cmd_zip.py`），需要就重打。只有在该网络确实拉不动 `archive/` 时才需要它。

## 会静默失败的地方

- 用 `hermes send --file` 发更新摘要：文件被判为非文本时发送直接失败，用户什么也收不到，而你只看到一行报错（见 `hermes-messaging-gateway`）。更新类长任务别把状态汇报压到最后一次发送。
- 更新过程本身会重启网关：你正在跑的 CLI 会话可能被中断，所以动作要落在脚本 + 日志文件里。

---
name: qlora-vram-tuning
description: Use when 16G 卡上 QLoRA 训练 OOM、步时暴涨、或要续训大模型。分阶段定位显存黑洞并压进显存。
---

# QLoRA 显存调优（16G 卡 / Windows）

## 步时暴涨 = 显存溢出，不是 kernel 慢
现象：同一微批从 3s 变 20~65s，GPU 利用率 100%、显存打满。
判据：显存打满 + 出现 GB 级「共享显存」占用（Windows 任务管理器 / GPU 计数器）
→ 权重或激活已换页到系统内存走 PCIe，步时慢 20 倍以上。
不要误判成 kernel 回退：`causal_conv1d` 缺失这类回退只慢几倍，且报错文本会明说。

## 头号黑洞：prepare_model_for_kbit_training 的 fp32 上采样
它会把所有**非量化**的 bf16 参数转 fp32，典型受害者是 `embed_tokens` 与 `lm_head`
（大词表模型各约 1.9G，合计 +3.79G）。这两个模块全程冻结、不训练，上采样纯浪费。
修法（放在 prepare_model_for_kbit_training 之后）：

    for m in (model.get_input_embeddings(), model.get_output_embeddings()):
        if m is not None and m.weight.dtype == torch.float32:
            m.to(torch.bfloat16)
    gc.collect(); torch.cuda.empty_cache()

实测静态占用 11.13G → 7.12G，训练步峰值 18.04G（溢出）→ 13.17G（稳），步时 65s → 2.95s。

## 分阶段打点，别猜
在 build_model 里逐段打印 `torch.cuda.memory_allocated()/memory_reserved()`：
基座加载 → 卸无用模块 → kbit 准备 → 精度回退 → 挂 LoRA。
一次定位到具体那一行，比反复试 MAXLEN 快得多。

## 多模态基座跑纯文本
`Qwen3_5ForConditionalGeneration` 这类带 visual tower / MTP 头的基座，纯文本训练用不到，
置 None 后 gc + empty_cache。注意它们多半已被量化，省的显存有限（实测 0.23G），
真正的量级在精度回退那一步。

## 其他坑
- `PYTORCH_CUDA_ALLOC_CONF=expandable_segments:True` 在 Windows 上不支持，只警告后忽略。
- 词表 24 万 + 长序列时，全量 logits(fp32) 可达数 G；可改用分块交叉熵。
  **手写时必须做 HF 的错位**：`logits[:, :-1]` 对 `labels[:, 1:]`，漏掉会让 loss 变成 15+ 的假值。
- 续训：`Trainer.train(resume_from_checkpoint=<最大 checkpoint 目录>)`，
  验收标准是 loss 延续下降而非从头重来。
- 探针脚本要复用训练脚本的 build_model()，否则量到的不是真实配置。

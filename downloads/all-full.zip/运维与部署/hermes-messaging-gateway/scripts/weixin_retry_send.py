#!/usr/bin/env python
"""条件补发：iLink 会话恢复后自动把正文发到微信，成功一次就永久停手。

用途：出站报 `session not ready: ret=-2` 时，把本脚本挂成 no_agent 的 cron 任务
每 1-2 分钟跑一次——用户给 bot 发一条消息激活会话后，下一次 tick 就送达。

    <HERMES_HOME>/hermes-agent/venv/Scripts/python.exe weixin_retry_send.py <正文文件> [chat_id]

必须在源码安装的 venv 里跑（该 venv 才有 aiohttp / cryptography）。
chat_id 缺省时取 WEIXIN_HOME_CHANNEL；都没有则记日志后静默退出。

契约（配合 cronjob_manage no_agent=True, deliver='local'）：
  * 已成功过（标记文件存在）→ 直接退出，空 stdout。
  * 发送失败 / 会话仍失效 → 只写日志，空 stdout 退出（空 stdout 不投递任何消息，
    否则每 2 分钟一条报错会刷屏）。
  * 发送成功 → 写标记文件 + 打印一行中文确认（这一行会投递给用户）。

标记与日志落在正文文件同目录：<正文>.sent、<正文>.retry.log。
正文里写 MEDIA:<正斜杠绝对路径> 可带附件（走正文，不走 --file）。
"""

import asyncio
import datetime
import os
import pathlib
import sys


def _hermes_home() -> pathlib.Path:
    env = os.environ.get("HERMES_HOME")
    if env:
        return pathlib.Path(env)
    local = os.environ.get("LOCALAPPDATA")
    if local:
        return pathlib.Path(local) / "hermes"
    return pathlib.Path.home() / ".hermes"


def _load_env(path: pathlib.Path) -> dict:
    out = {}
    try:
        text = path.read_text(encoding="utf8", errors="replace")
    except FileNotFoundError:
        return out
    for line in text.splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        out[key.strip()] = value.strip().strip('"').strip("'")
    return out


def main() -> int:
    if len(sys.argv) < 2:
        print(__doc__)
        return 2

    body_path = pathlib.Path(sys.argv[1]).expanduser().resolve()
    marker = body_path.with_name(body_path.name + ".sent")
    log_path = body_path.with_name(body_path.name + ".retry.log")

    def log(line: str) -> None:
        stamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        with open(log_path, "a", encoding="utf8") as fh:
            fh.write(f"{stamp} {line}\n")

    if marker.exists():
        return 0

    try:
        body = body_path.read_text(encoding="utf8")
    except FileNotFoundError:
        log(f"正文文件不存在：{body_path}")
        return 0

    home = _hermes_home()
    env = _load_env(home / ".env")
    for key, value in env.items():
        os.environ.setdefault(key, value)

    chat_id = (sys.argv[2] if len(sys.argv) > 2 else "").strip() or os.environ.get("WEIXIN_HOME_CHANNEL", "").strip()
    if not chat_id:
        log("chat_id 缺失：作为第二个参数传入，或先设置 WEIXIN_HOME_CHANNEL")
        return 0

    sys.path.insert(0, str(home / "hermes-agent"))
    from gateway.platforms import weixin  # noqa: E402

    token = os.environ.get("WEIXIN_TOKEN") or env.get("WEIXIN_TOKEN")
    try:
        result = asyncio.run(
            weixin.send_weixin_direct(extra={}, token=token, chat_id=chat_id, message=body)
        )
    except Exception as exc:  # noqa: BLE001
        log(f"异常 {exc}")
        return 0

    if isinstance(result, dict) and result.get("error"):
        log(f"失败 {result['error'][:120]}")
        return 0
    if isinstance(result, dict) and result.get("success") is False:
        log(f"失败 {result}")
        return 0

    marker.write_text("sent", encoding="utf8")
    log("发送成功")
    print(f"微信已送达：{body_path.name}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

#!/usr/bin/env python
"""直接调 Hermes 网关模块发微信消息（`hermes send` 报 requirements not met 时的兜底）。

必须在源码安装的 venv 里跑（该 venv 才有 aiohttp / cryptography）：

    <HERMES_HOME>/hermes-agent/venv/Scripts/python.exe scripts/weixin_send.py <正文文件> [chat_id]
    echo "正文" | <...>/python.exe scripts/weixin_send.py - [chat_id]

chat_id 缺省时取环境变量 WEIXIN_HOME_CHANNEL；两者都没有会明确报错，不要瞎猜 chat_id。
成功打印 {"success": true, "message_id": ...}；失败打印含 error 字段的结果。

正文里写 MEDIA:<正斜杠绝对路径> 可带附件（走正文，不走 --file）。
"""

import asyncio
import os
import pathlib
import sys


def _hermes_home() -> pathlib.Path:
    env = os.environ.get("HERMES_HOME")
    if env:
        return pathlib.Path(env)
    local = os.environ.get("LOCALAPPDATA")
    if local:
        return pathlib.Path(local) / "hermes"
    return pathlib.Path.home() / ".hermes"


def _load_env(path: pathlib.Path) -> dict:
    out = {}
    try:
        text = path.read_text(encoding="utf8", errors="replace")
    except FileNotFoundError:
        return out
    for line in text.splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        out[key.strip()] = value.strip().strip('"').strip("'")
    return out


def main() -> int:
    if len(sys.argv) < 2:
        print(__doc__)
        return 2

    src = sys.argv[1]
    body = sys.stdin.read() if src == "-" else pathlib.Path(src).read_text(encoding="utf8")

    home = _hermes_home()
    env = _load_env(home / ".env")
    for key, value in env.items():
        os.environ.setdefault(key, value)

    chat_id = (sys.argv[2] if len(sys.argv) > 2 else "").strip() or os.environ.get("WEIXIN_HOME_CHANNEL", "").strip()
    if not chat_id:
        print("ERROR: chat_id 缺失，请作为第二个参数传入（DM 的 chat_id 就是用户的 user_id），或先设置 WEIXIN_HOME_CHANNEL")
        return 2

    sys.path.insert(0, str(home / "hermes-agent"))
    from gateway.platforms import weixin  # noqa: E402

    token = os.environ.get("WEIXIN_TOKEN") or env.get("WEIXIN_TOKEN")
    print("requirements:", weixin.check_weixin_requirements(), "token:", bool(token))

    result = asyncio.run(weixin.send_weixin_direct(extra={}, token=token, chat_id=chat_id, message=body))
    print("RESULT:", result)
    return 0 if isinstance(result, dict) and result.get("success") else 1


if __name__ == "__main__":
    raise SystemExit(main())

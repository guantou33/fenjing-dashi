---
name: hermes-messaging-gateway
description: Use when 接 Hermes 消息网关（微信/QQ）做远程遥控。
---

# Hermes 消息网关接入（远程遥控）

目标：用户不在电脑前时，通过微信等 IM 给这台机器上的 Hermes 发消息执行任务。

## 选通道（先定，别急着装）

1. **Weixin 个人（iLink Bot）** —— 扫码即用，长轮询取消息，不需要公网/域名/webhook，本机开着 `hermes gateway` 就能收 DM。默认首选。
2. **WeCom（企业微信 AI Bot）** —— WebSocket，同样不需公网，但需企业微信组织；群聊与流式回复更好。
3. **QQ Bot** —— 需 q.qq.com 申请 AppID/Secret，沙箱转正，链路最长。

先问清电脑能否常开或"需要时开机"：关机期间收不到消息，必须讲明，别让用户以为离线也能用。

## 标准流程

1. 确认 CLI 可用：`hermes gateway status`（`hermes` 不在 PATH 时用 `<HERMES_HOME>/hermes-agent/venv/Scripts/hermes`）。
2. 装平台依赖：在 hermes-agent 目录 `uv pip install -e ".[messaging]"`。
3. 扫码登录，把凭据落到本 profile。`hermes gateway setup` 是纯交互式的，二维码直接画在**终端里**（ANSI 半块字符），用户看不到终端 → 用脚本把二维码渲染成图片文件给用户扫。
4. 写配置一律用 `hermes config set <KEY> <VALUE>`（会把 messaging 键路由到 `<HERMES_HOME>/.env`），不要手改 .env。
5. 重启网关：`hermes gateway stop` → 后台起 `hermes gateway run`。
6. 验证：tail `<HERMES_HOME>/logs/gateway.log`，见 `✓ ... connected` + `Gateway running with 1 platform(s)` 才算成；再让用户发一条消息，日志应出现 `inbound message` 与 `Flushing text batch`。

## 助手主动发消息（把结论推到用户手机）

清单/推荐类内容（"给我找十个 X"）的产出格式与交付时机见 `recommendation-lists`：正文先落盘再发，别为了确认"能不能用"逐条实测。

命令：`hermes send --to weixin:<chat_id> --file <txt路径>`（纯文本）
或 `hermes send --to weixin:<chat_id> "MEDIA:<绝对路径>"`（图/视频等附件：正文里写 `MEDIA:` + **正斜杠**绝对路径，别用反斜杠）

坑：
- **没有 `--text` 参数**（报 `unrecognized arguments: --text`）。正文只能写进文件用 `--file`；中文正文先用 `write_file` 落盘，避开 shell 引号与编码问题。
- **`--file` 要求文件被判为文本**：文件被判非文本时直接报 `... is not a text file. --file reads the message *body*`，**消息不会发出**，用户什么也收不到，而你只看到一行报错。带二进制内容、空文件、编码古怪的文件都容易踩。
- **`hermes send` 报 `<平台> requirements not met` 时先别当成平台坏了**：CLI 按 `installs/<hash>/pm-runtime/selected.json` 挑依赖环境，该文件指向的 `generations/` 目录不存在时会挑到空 venv，于是网关连着、消息其实发得出去，CLI 却拒绝发送（表现为 exit 0、只有一行输出、用户什么也没收到）。核验：`<HERMES_HOME>/hermes-agent/venv/Scripts/python.exe -c "import aiohttp, cryptography"` 通过即说明运行环境有依赖。兜底用 `scripts/weixin_send.py` 直接走网关模块发送。
- **每次发送都要核验，别把关键汇报压到最后一次发送**：加 `--json` 看结构化结果；长任务（跑更新、批量生成）要阶段性主动发短进展——收尾那份汇总一旦发失败，用户就完全不知道状态，只会反复催问。发送失败就立刻换方式重发（正文内联 `MEDIA:`，或把正文重写成干净纯文本再 `--file`）。
- `--to weixin` 单写会报 `No home channel set for weixin`。要么写全 `<平台>:<chat_id>`（用户 DM 的 chat_id 就是其 user_id），要么先 `hermes config set WEIXIN_HOME_CHANNEL <chat_id>`。
- 投递要可核验就加 `--json`：打印结构化发送结果，比只看到 `sent` 更能确认（出站消息不写 gateway.log）。
- 附件走正文 `MEDIA:`，不走 `--file`；大文件（视频）上传是同步等待，返回后仍值得让用户回一句"收到没"——那端拿到的是可播放视频还是一个附件，只有用户能看到。
- **发网页类交付物优先发链接**：https 网页链接在微信内置浏览器里直接渲染，用户点开即用；
  `.html` 当附件发，苹果手机上会落到"用其他应用打开"，多一道手续。两者一起发最稳——
  链接管当下能用，文件管长期存档。
- 成功只输出一个词 `sent`。`logs/gateway.log` **不记录 outbound**，别据此判定失败；侧面确认看 `logs/agent.log` 同时刻是否有 `weixin: restored 1 context token(s) for <账号前缀>`（说明连上了该会话）。
- CLI 会话与网关会话互相独立：用户手机上的对话由网关侧的另一个 session 处理，你在 CLI 里做的事不会同步过去，反之亦然。两边可能同时被同一句指令驱动，注意别重复发消息。
- 「发完结论再关机」是常见收尾需求，但 agent 被硬策略禁止执行 shutdown/reboot（terminal 直接 BLOCKED，yolo 也不行），必须提前讲明让用户自己动手，别承诺会自动关机。

## 出站失败：iLink 会话过期（ret=-2）

- **症状**：所有发送路径（`hermes send`、`scripts/weixin_send.py`、网关自身）都返回
  `iLink sendmessage session not ready: ret=-2 errmsg=prepare failed — the user must send the bot a message first (or re-pair)`，
  `logs/gateway.log` 同一时刻刷一串同样的 ERROR。
- **别误判**：这不是配置坏了，也不是 requirements 问题——`check_weixin_requirements()` 仍返回 True、token 也在。
- **成因**：iLink 的出站会话有窗口期，用户长时间没给 bot 发消息就失效；context_token 过期后按日志里的
  `session expired ... retrying without context_token` 重试也救不回来。
- **处置**：**不要原地循环重试**，重试几次结果都一样。让用户先给 bot 随便发一条消息（一个字就够）激活会话，然后立刻补发。

## 会话失效时的自动补发（用户已离开电脑时用这个）

用户可能已经走开，别再要求他等着你手动重试。挂一个 `no_agent=True` 的定时任务，每 1–2 分钟试发一次，成功即停：

1. 补发脚本必须放在 `<HERMES_HOME>/scripts/` 下（可直接用 `scripts/weixin_retry_send.py`）。
2. `cronjob_manage(action='create', name='微信补发-<主题>', schedule='every 2m', repeat=60, no_agent=True, deliver='local', script='weixin_retry_send.py')`
3. **坑：`script` 只能写相对 `<HERMES_HOME>/scripts/` 的文件名，传绝对路径会被直接拒**（`Script path must be relative to ...`）；脚本原本落在 scratch 目录时，先拷进 `scripts/` 再建任务。
4. `deliver='local'`：任务输出不投递到任何通道，避免失败噪音；正文由脚本自己发微信。
5. 脚本契约（watchdog 模式）：已成功过 → 直接退出；发送失败 → 只记日志、**空 stdout 静默退出**（空 stdout 不投递任何消息）；发送成功 → 写标记文件 + 打印一行确认。
6. 告诉用户"你只要在微信给机器人发一条消息，内容会自动到"，并给出正文文件的绝对路径，别让他等着你手动重试。

## 附带脚本

- `scripts/weixin_send.py`：绕过 CLI 的环境解析，直接在源码安装的 venv 里调 `gateway.platforms.weixin.send_weixin_direct` 发微信（正文取自文件或 stdin），打印 `success / message_id / context_token_used` 可核验回执。用法见脚本头部注释。
- `scripts/weixin_retry_send.py`：会话过期时的条件补发脚本，挂 `no_agent` cron 任务用（成功即停、失败静默）。用法见脚本头部注释。

---
name: hermes-session-history
description: Use when 用户问“你刚刚/上次做了什么”、要重建最近活动，或要查某次历史会话的正文内容。
version: 0.1.0
author: Hermes Agent
license: MIT
platforms: [linux, macos, windows]
metadata:
  hermes:
    tags: [hermes, session, sqlite, history, reporting]
    related_skills: [local-llm-deployment, hermes-install-maintenance]
---

# Hermes 会话历史取证

从 Hermes 自己的会话库里把“我刚刚/上次做了什么”查成事实，再用人话汇报。适用于任何“回答关于自己历史的问题”的场景。

## When to Use

- 用户问“你刚刚做了什么”“上次我们聊到哪了”“你什么时候换的 X”“那条清单发出去没有”。
- 需要在压缩/新会话开局重建最近一段时间的操作（改过什么配置、跑过什么任务、哪些还没做完）。
- 需要读某次历史会话的正文：当时用户的原话、当时的结论。

## 数据在哪

- 会话与消息都在 `$HERMES_HOME/state.db`（本机 `C:\Users\111\AppData\Local\hermes\state.db`）——SQLite。
- 同目录的 `sessions.db` 可能是空壳，别拿它下手。先 `ls -la` 比大小，取大的那个；再 `select name from sqlite_master where type='table'` 确认。
- `sessions` 表：`id, title, last_activity_description, last_activity_at, started_at, ended_at, end_reason, message_count`。
- `messages` 表：`id, session_id, role, content, tool_calls, tool_name, timestamp`。
- session id 形如 `20261003_225449_f4f4cd`（本地时间 + 随机后缀）。浏览器工作区目录名与它同名，可把浏览器动作对回会话。
- `timestamp` 是 epoch 秒（float），用 `datetime.fromtimestamp()` 转。

## Procedure

1. 定位最近活跃会话（比时间戳可靠的是消息 id）：
   `select session_id, max(id) mx, count(*) from messages group by session_id order by mx desc limit 5`
2. 读该会话尾部 20–30 条（`id > 起点` 增量读，避免拉全量）：
   `select id, role, tool_name, substr(content,1,700), timestamp from messages where session_id=? order by id desc limit 30`
3. 重建动作序列：assistant 行的 `tool_name` / `tool_calls` 是动作，紧随的 tool 行 `content` 是结果，user 行是指令。按 id 升序读才是真实顺序。
4. 一遍定性：`sessions.last_activity_description` / `end_reason` 给出最后阶段的一句话（如“context compression in progress”“max iterations”）。
5. 交叉核对未完成项：cron 任务列表、后台进程列表；用户问“发出去没有”这类问题时以发送记录/任务状态为准，不用“应该发了”作答。

## Pitfalls

- **assistant 的 `content` 常为空串**：内容可能被压缩或存在别的字段。别因为读不到文本就断言“那步没做”——用 `tool_name`、`tool_calls` 和邻近 tool 结果重建。想捞结论性长汇报时加 `and length(coalesce(content,''))>200` 过滤。
- **别用 sessions.db**：会话正文在 state.db；下错库会得到“0 条消息”的假结论（此时要怀疑库选错，而不是真的没记录）。
- **参数个数必须与占位符一致**：在 execute_code 里一次拼多条语句时最容易给无占位符的语句多传参数（报 `Incorrect number of bindings supplied`）——每条语句单独 execute、各自配对参数。
- **只靠 session_search 会漏内容**：它的浏览只回少量元数据条目，正文要按 session_id 读；需要完整重建时直查 state.db 最省事。
- **不要在探测上浪费调用**：先读库再决定动作，别发空转的探测调用。

## 汇报规范

- 用户会用“用人话告诉我”打断技术汇报：**讲结果与影响，不复述命令、工具名、量化名、退出码**。技术细节只在被追问时给。
- 句式：做了什么 → 带来什么变化（哪个功能变好了、腾出多少空间、哪个任务失败或停了）→ 还挂着什么。
- 挂起项单列，每条给一行处置建议（“想补我重新跑一遍”），不要埋在正文里。
- 只能报告查证到的事实：结论取自工具输出，别把自报数字说成实测；没查的就说没查。

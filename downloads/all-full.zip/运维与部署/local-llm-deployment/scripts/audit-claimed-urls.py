#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Classify a list of claimed domains/URLs by real reachability.

Why: a model (especially a LOCAL one, which has no network access) emits URLs from memory. "It does not
open" has several very different causes that must NOT be reported as one:

    不存在            DNS does not resolve                  -> fabricated / dead domain
    停放待售          lands on a domain-sale parking page   -> fabricated domain (strongest signal)
    反爬拦截          401/403/405/406/429 from the edge      -> site is ALIVE; a browser opens it fine
    正常              2xx after redirects
    站点存在(根路径404)  the site answered, that path just is not there -> alive
    超时/不可达       DNS ok but no answer in time           -> network path (proxy/VPN/ISP), NOT proof of death

Usage:
    python audit-claimed-urls.py example.com https://foo.org
    python audit-claimed-urls.py --file domains.txt
    cat domains.txt | python audit-claimed-urls.py

Stdlib only. Exit code 0 = report produced (this is a report, not a test gate).
"""

import argparse
import concurrent.futures
import json
import socket
import ssl
import sys
import unicodedata
import urllib.error
import urllib.parse
import urllib.request

PARKING_MARKERS = (
    "hugedomains", "sedo.com", "sedo.", "afternic", "dan.com", "undeveloped.com",
    "domainmarket", "buydomains", "domains/marketplace",
)
BOT_WALL_CODES = {401, 403, 405, 406, 429}
UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/125.0 Safari/537.36")


def normalize(raw):
    raw = raw.strip().strip('\u0022,\'')
    if not raw or raw.startswith("#"):
        return None
    if "://" not in raw:
        raw = "http://" + raw
    host = (urllib.parse.urlsplit(raw).hostname or "").strip(".").lower()
    if not host or "." not in host:
        return None
    return host


def is_parking(url):
    u = (url or "").lower()
    return any(m in u for m in PARKING_MARKERS)


def http_probe(url):
    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    req = urllib.request.Request(
        url, headers={"User-Agent": UA, "Accept-Language": "zh-CN,zh;q=0.9"})
    with urllib.request.urlopen(req, timeout=15, context=ctx) as resp:
        return resp.status, resp.geturl()


def check(host):
    row = {"host": host, "dns": "", "http": "", "final": "", "verdict": ""}
    try:
        row["dns"] = socket.gethostbyname(host)
    except Exception as exc:
        row["http"] = type(exc).__name__
        row["verdict"] = "不存在"
        return row

    last_err = ""
    for scheme in ("https", "http"):
        try:
            status, final = http_probe("%s://%s" % (scheme, host))
            row["http"], row["final"] = str(status), final
            row["verdict"] = "停放待售" if is_parking(final) else "正常"
            return row
        except urllib.error.HTTPError as exc:
            final = exc.geturl() or ""
            row["http"], row["final"] = str(exc.code), final
            if is_parking(final):
                row["verdict"] = "停放待售"
            elif exc.code in BOT_WALL_CODES:
                row["verdict"] = "反爬拦截"
            elif exc.code == 404:
                row["verdict"] = "站点存在(根路径404)"
            else:
                row["verdict"] = "异常 HTTP %s" % exc.code
            return row
        except Exception as exc:
            last_err = type(exc).__name__
    row["http"] = last_err or "-"
    row["verdict"] = "超时/不可达"
    return row


def width(s):
    return sum(2 if unicodedata.east_asian_width(c) in "WF" else 1 for c in s)


def pad(s, n):
    return s + " " * max(0, n - width(s))


def main():
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass

    ap = argparse.ArgumentParser(description="Classify claimed domains by real reachability.")
    ap.add_argument("hosts", nargs="*", help="domains or URLs")
    ap.add_argument("--file", help="text file with one domain/URL per line")
    ap.add_argument("--json", dest="json_out", help="also write the report as JSON")
    ap.add_argument("--workers", type=int, default=10)
    args = ap.parse_args()

    raws = list(args.hosts)
    if args.file:
        with open(args.file, encoding="utf-8") as fh:
            raws += fh.read().splitlines()
    if not raws and not sys.stdin.isatty():
        raws += sys.stdin.read().splitlines()

    hosts, seen = [], set()
    for raw in raws:
        h = normalize(raw)
        if h and h not in seen:
            seen.add(h)
            hosts.append(h)
    if not hosts:
        ap.error("no domains given (argv, --file or stdin)")

    with concurrent.futures.ThreadPoolExecutor(max_workers=args.workers) as ex:
        rows = list(ex.map(check, hosts))

    print(pad("域名", 30) + pad("解析结果", 17) + pad("HTTP", 9) + "判定")
    for r in rows:
        print(pad(r["host"], 30) + pad(r["dns"] or "-", 17)
              + pad(r["http"] or "-", 9) + r["verdict"])

    tally = {}
    for r in rows:
        tally[r["verdict"]] = tally.get(r["verdict"], 0) + 1
    print()
    print("共 %d 个：%s" % (len(rows),
          "、".join("%s %d" % (k, v) for k, v in sorted(tally.items()))))
    print("提醒：反爬拦截=站点活着（用户浏览器能打开），域名不存在/停放待售=编的，两者不可混报。")

    if args.json_out:
        with open(args.json_out, "w", encoding="utf-8") as fh:
            json.dump(rows, fh, ensure_ascii=False, indent=2)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

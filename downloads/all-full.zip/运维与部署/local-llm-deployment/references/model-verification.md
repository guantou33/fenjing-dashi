# Four-probe battery: is a local model usable in Hermes?

Run these BEFORE registering a model (alias or `model.default`). Tool calling is the gate — Hermes drives every useful action through `tool_calls`, so a model that only chats well is not usable no matter how fluent it is. Record the verdict in the reply (pass/fail per probe), not just a summary.

Use the model's full Ollama tag everywhere (`qwen3:14b`, `huihui_ai/qwen3.5-abliterated:9b`).

## 1. Generation — does it run at all

```
curl -s --max-time 120 http://localhost:11434/api/generate \
  -d '{"model":"<model>","prompt":"用一句话介绍你自己","stream":false,"think":false,"num_predict":80}'
```

Non-ASCII prompt: write the JSON body to a UTF-8 file and use `--data-binary @<file>` (native curl in git-bash mangles inline non-ASCII).

## 2. Tool calling — the gate

```
curl -s --max-time 120 http://localhost:11434/api/chat \
  -d '{"model":"<model>","stream":false,
       "messages":[{"role":"user","content":"北京今天天气怎么样"}],
       "tools":[{"type":"function","function":{"name":"get_weather",
         "description":"查询城市天气",
         "parameters":{"type":"object","properties":{"city":{"type":"string"}},"required":["city"]}}}]}'
```

PASS = the response carries `tool_calls` with the right function and correctly extracted arguments (`city=Beijing`). No `tool_calls` = fail, and the model cannot act in Hermes.

## 3. Context window — 64k floor

Re-run probe 1 with `"num_ctx": 65536` in the body (add `"num_predict": 20` and a trivial prompt so it returns fast). Hermes rejects a model advertising under 64,000 tokens; a local server serves whatever `num_ctx` says, which can exceed the GGUF metadata — that is what `model.ollama_num_ctx` declares.

Confirm where it landed in VRAM:

```
ollama ps
nvidia-smi --query-gpu=name,memory.used,memory.total,utilization.gpu --format=csv
```

PASS = 100% GPU with headroom left on the card; partial CPU offload or a near-full card means the usable context is smaller than advertised.

## 4. Vision — only for multimodal models bound as the auxiliary vision model

Base64 the image in Python and POST it as `"images":["<b64>"]` to `/api/generate`, asking for a description of the content. Judge the answer against what is actually in the image — a plausible-but-generic description is a fail, not a pass.

## After the probes

Register, then prove resolution end-to-end rather than trusting the config write:

```
hermes config get model.aliases      # registered?
hermes config check                  # clean?
hermes chat -q "用一句话自我介绍，30字以内。" -m <alias>   # does it answer?
```

A local 9B model takes ~30–60s on the first call (weights loading). Ask before running the battery on a multi-minute model, and never leave a model resident in VRAM on a machine the user also games/generates on — check `ollama ps` afterwards.

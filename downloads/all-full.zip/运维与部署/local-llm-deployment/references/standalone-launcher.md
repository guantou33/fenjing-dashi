# Launching a local model standalone on Windows

Goal: the user double-clicks an icon and gets an interactive `ollama run` chat with nothing to do with Hermes.

## 1. Visible, detached console window

A command run through the agent's `terminal` is invisible to the user and dies with the session. Spawn a real console window instead:

```
powershell -NoProfile -Command "Start-Process -FilePath 'cmd.exe' -ArgumentList '/k','ollama run <tag>'"
```

`cmd /k` keeps the window open afterwards; `Start-Process` detaches it, so ending the agent turn does not kill the chat. Verify with `ollama ps` — the model must show as loaded. A window you cannot see is not proof that anything started.

## 2. Desktop shortcut

Use the WScript.Shell COM object; no helper tooling needed.

```
$ws  = New-Object -ComObject WScript.Shell
$lnk = $ws.CreateShortcut("C:\Users\<user>\Desktop\<name>.lnk")
$lnk.TargetPath       = "C:\Windows\System32\cmd.exe"
$lnk.Arguments        = '/k "ollama run <tag>"'
$lnk.WorkingDirectory = "C:\Users\<user>"
$lnk.IconLocation     = "C:\Users\<user>\AppData\Local\Programs\Ollama\ollama.exe,0"
$lnk.Save()
```

To UPDATE an existing shortcut, call `CreateShortcut` on its existing path, set the fields, `Save()` — do not delete and recreate, and locate it by wildcard (`Get-ChildItem -Filter "*.lnk" | Where-Object { $_.Name -like "<prefix>*" }`) so a filename you cannot type cleanly still matches.

## Pitfalls

- **Non-ASCII (e.g. Chinese) text inside the .ps1 body gets mangled.** PowerShell 5.1 reads a BOM-less UTF-8 script as ANSI, so a literal Chinese filename lands on disk as mojibake. Keep the script pure ASCII and build the name from code points:
  `"Qwen3.5 " + [char]0x4E2D + [char]0x6587 + [char]0x5BF9 + [char]0x8BDD + ".lnk"`
- **Captured stdout renders Chinese paths as garbage.** That is the console codepage, not a real failure — never report the mojibake as the filename. Verify instead with `ls` in git-bash, or by reading the shortcut back and printing `Arguments` / `TargetPath` / `WorkingDirectory`, which are ASCII.
- Write the script to `$TMPDIR` (the Hermes scratch dir) and run it as `powershell -NoProfile -ExecutionPolicy Bypass -File "C:/Users/<user>/.../x.ps1"` — native `powershell` needs a `C:/...` path, not an MSYS `/c/...` one.
- Creating a derived model does not unload a running one. A stale chat window keeps the old small-context model loaded; tell the user to close it.

# Fine-tuning a local model (QLoRA) and the dataset behind it

Scope: teach an existing local weight (9B-class on a 16GB card) a behavior — tool dispatch, house style — then
ship it as an Ollama tag and verify it through Hermes. Pipeline: build data → train → `ollama create` → verify.
The template and masking rules below were measured on this box; hyperparameters were NOT yet validated end-to-end,
so measure the VRAM/sequence-length tradeoff yourself rather than copying numbers.

## Order of work

1. Inventory the model tags and the corpus before generating anything (what weights exist, what data is already
there, which generator scripts already ran).
2. Write ONE dataset generator that emits `{"messages": [...], "tools": [...]}` per line, covering every shape the
model must learn; keep the raw corpus separate from the rendered samples.
3. Render + read a sample of each shape through the target model's own tokenizer.
4. Write the trainer with explicit segment masking; smoke-run on a few samples printing lengths and masked spans.
5. Full training pass detached with notify; then merge/quantize, `ollama create`, register the alias, verify.

## 1. The chat template is the contract

Load the tokenizer and print the rendered string for one sample of EACH shape (plain chat / tool-call trajectory /
thinking) before writing the trainer. Findings from doing exactly that:

- `apply_chat_template(msgs, tokenize=False)` renders only `messages`. Tool definitions arrive through the separate
  `tools=` argument — omitted, the whole tool preamble is absent from the training text while every served request
  carries it. Train/serve mismatch: the model is asked to key its calls to schemas it has never seen.
- Assistant reasoning renders from the `reasoning_content` key on the message dict (not `thinking`); tool results
  render as a tool-role message wrapped in `<tool_response>`.
- Size the preamble first: one realistic tool set (~18 schemas) renders to roughly 5k characters / ~1.3–2k tokens,
  i.e. most of a 2048-token window before the first user turn. Either raise the max length (>=3072) or train with a
  reduced but representative tool subset. Truncating instead teaches half-schemas and broken structure.

## 2. Mask by role segment, never by "the last assistant reply"

- The loss mask covers every assistant segment in a trajectory, tool-call turns included; system/user/tool tokens
  are masked out.
- Slicing from the last `<|im_start|>assistant` header (or from the first one to the end) gives zero gradient on the
  tool call. The visible result is a model that emits plausible calls and ignores the results — see it as a data bug,
  not a capability limit.
- Over-long samples: trim the tool RESPONSE body at generation time, or drop the sample and count it. Never
  `ids[:1] + ids[-N:]` — that keeps BOS and discards system + tools + task head.

## 3. Trajectory data beats single-shot calls

Each sample, in order: system (+ tools) → user → assistant (reasoning + tool_call) → tool (result) → assistant
(final answer). Include the empty/error tool result — reacting to a failed or empty return IS the dispatch skill.

- A log harvest yields `tool_call` entries both with and without a following `tool_response`. Count both before
  training; calls with results are a small fraction of the total, and only those teach dispatch.
- Distill a doc/skill corpus by structure, never by dumping files: headings → section chunks, bullets → Q&A entries,
  drop frontmatter and code fences from the prompt side. A 2.5MB / ~155-file pack flattens to a few thousand usable
  samples at ~240 characters average — a sane single-LoRA size.
- Keep the sample count printed per generator run and append to JSONL so a timeout loses one batch, not the run.

## 4. Smoke-test the generator before the full pass

Long generated Python (scenario tables, synthesizers) is where the typos live — argument-count mismatches, unclosed
nested literals, a `print` placed inside a string. `py_compile` it, then run it over 2–3 samples with the rendered
length and the masked token span printed. Print lengths, not just counts: the failure mode is silent overflow, not
a crash.

## 5. Run long, report in the user's language

Training is hours. Run it detached with completion notify; report progress in Chinese with a percentage; push the
final result to the user's phone over the messaging gateway. Do not hold the session open waiting on it, and do not
call a run finished while it is only queued.

## Verification after training

Same ladder as the parent skill: create the tag (adapter merged/quantized → Modelfile), register the alias, then
prove tool dispatch with a SIDE EFFECT — a real `hermes chat -m <alias>` turn that must write/read a file, checked
on disk. A model that narrates the call has not been verified.

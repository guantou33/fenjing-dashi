---
name: flclash-proxy
description: "Use when 要访问被墙站点或需要翻墙时开关 FlClash 代理。含启停流程、端口、流量配额检查。"
version: 1.0.0
author: Hermes Agent
license: MIT
platforms: [windows]
metadata:
  hermes:
    tags: [proxy, vpn, flclash, clash, network, windows]
    category: devops
    related_skills: []
---

# FlClash 代理（用户的 VPN）

用户的翻墙通道，已付费可用。**按需开关：用之前打开，用完自己关掉。**

## 关键事实

| 项 | 值 |
|---|---|
| 主程序 | `C:\Program Files\FlClash\FlClash.exe`（快捷方式在 `C:\Users\Public\Desktop\FlClash.lnk`） |
| 配置目录 | `C:\Users\111\AppData\Roaming\com.follow\clash\` |
| 代理端口 | **`127.0.0.1:7890`**（HTTP/SOCKS 混合端口，仅本机监听） |
| 内核 | `FlClashCore.exe`（mihomo，只吃位置参数，**没有 `-h`**） |
| 出口 | 美国节点，实测 google/github/huggingface 全通 |

## 启动（要用代理时）

```bash
powershell.exe -NoProfile -Command "Start-Process 'C:\Program Files\FlClash\FlClash.exe'"
sleep 28                     # 必须等，内核起得慢
netstat -ano | grep ":7890"  # 看到 LISTENING 才算就绪
```

已把 `autoRun` 改成 `true`（配置里 `appSettingProps.autoRun`），所以启动即自动开代理并设系统代理，不用手点界面。

## 终端里怎么用

**终端不继承系统代理**，必须显式指定：

```bash
curl -x http://127.0.0.1:7890 https://www.google.com
# 或整段会话生效：
export http_proxy=http://127.0.0.1:7890
export https_proxy=http://127.0.0.1:7890
```

git / pip / hf 等命令同样认这两个环境变量。

## 关闭（用完必做）

```bash
powershell.exe -NoProfile -Command "Get-Process FlClash,FlClashCore -ErrorAction SilentlyContinue | Stop-Process -Force"
# 确认系统代理已清理（ProxyEnable 应为 0）
powershell.exe -NoProfile -Command "Get-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings' | Select-Object ProxyEnable"
```

若关掉后 `ProxyEnable` 仍为 1，说明系统代理残留（指向已停的服务会让本机上不了网），手动置 0：

```bash
powershell.exe -NoProfile -Command "Set-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings' -Name ProxyEnable -Value 0"
```

## 流量配额（务必自律）

套餐 100 GB/月，**分给 agent 的额度是 50 GB**。到期日看 `expire` 字段。

查当前用量（订阅信息里带流量）：

```bash
python -c "
import sqlite3, json
c = sqlite3.connect(r'C:\Users\111\AppData\Roaming\com.follow\clash\database.sqlite')
info = json.loads(c.execute('SELECT subscription_info FROM profiles').fetchone()[0])
used = info['upload'] + info['download']; total = info['total']
print('已用 %.2f GB / %.0f GB，剩 %.2f GB' % (used/1024**3, total/1024**3, (total-used)/1024**3))
"
```

**用流量原则**（用户明确要求）：
- 大额下载（模型权重、数据集、镜像）**优先走不走代理的渠道**；国内可直连的源（hf-mirror、清华源等）绝不挂代理。
- 只有被墙且必须访问的才开代理，用完立刻关。
- 查资料、看页面这类小流量随便用。
- 开代理前若拿不准量级，先估算再决定。

## 坑

- **内核起来要 ~25 秒**，端口没 LISTENING 就是还没好，别急着判定失败。
- 原来的 `autoRun` 是 `false`——启动后端口不监听、系统代理不开，必须在界面点一下。改成 `true` 后才有现在的"启动即用"。配置改动已备份为 `shared_preferences.json.bak`。
- `external-controller` 是空的，**没有 REST API 可以切换节点**，节点只能在界面里选。
- `mode: rule`：国内域名直连，不会白耗流量。
- 关进程用 `Stop-Process -Force`；界面上的关闭按钮是**最小化到托盘**（`minimizeOnExit: true`），不算关掉。

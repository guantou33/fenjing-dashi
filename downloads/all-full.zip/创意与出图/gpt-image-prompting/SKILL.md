---
name: gpt-image-prompting
description: "Use when 要给 GPT 家 image 模型写提示词/出图指令。自然语言骨架、一致性锁定、正反例。"
version: 1.0.0
author: GPT-6-astra
license: MIT
metadata:
  hermes:
    tags: [image, prompt, gpt-image, creative]
    category: creative
    related_skills: []
---

# GPT 家 image 模型提示词技能

## 0. 硬前提：开头必须是**陈述式**，不能是祈使式

实测（2026-10-17，`gpt-image-2.5-sunburst` 中转站）：

- ❌ 以 `Create a ...` / `Generate a ...` / `Design a ...` 开头 → 上游把它当成**对话请求**，返回
  `http 400 {"code":"upstream_text_reply","message":"Please upload the reference image you want me to edit, or confirm that you want a completely new portrait generated from your description."}`
  耗时仅 16 秒，`usage {}` 为空 → **没出图、没计费**，但这一次请求算废掉。
- ✅ 以画面本身开头 → 正常出图：
  > `An unretouched studio portrait photograph, a head-and-shoulders close-up of one young woman, shot on a full-frame camera with an 85mm lens at f/2.8, camera at eye level, perfectly straight on.`

**规则**：把「Create a X of Y」改写成「**A X of Y, ...**」——用画面自述句起头，全篇保持描述语气，不出现任何祈使动词（Create / Generate / Make / Design / Draw / Render / Show / Use / Keep / Include / Output）。本文下面所有 `Create a ...` 模板都只作**结构示意**，落地时必须改成陈述式。

其他硬规则：

- **每批出图前先报预算**：4K 与 1K 在本中转站**同价**（按张计费），默认 4K；但开跑前必须问一句，≥2 张要单独确认张数。
- **判图看原尺寸裁切**：4K 缩到 1080 宽会显得磨皮，那是缩放假象，不是模型的锅。

---

## 1. 核心原则

GPT 家 image 模型更擅长理解**自然语言中的意图、关系、优先级和编辑指令**，而不是解析 SD/Flux 式的标签堆、权重语法或长串 negative prompt。

好的提示词不是“关键词越多越好”，而是一份简洁、结构化的视觉 brief：

1. 先说要生成什么。
2. 再说主体长什么样、在做什么。
3. 再说画面如何构图、使用什么视角和光线。
4. 最后补充文字、尺寸、风格、必须遵守的限制。
5. 对容易出错的部分给出明确的可验证约束。

应使用完整句子，例如：

> Create a clean editorial portrait of a young female architect...

而不是：

> young woman, architect, portrait, studio, cinematic, 8k, masterpiece, best quality, --ar 2:3

（注意：上面这句 `Create a ...` 只用于说明「完整句子 vs 标签堆」的差别；真正提交时要按第 0 节改成陈述式 `A clean editorial portrait of a young female architect, ...`。）

模型通常会自动理解“高清”“专业”“高质量”等默认目标。与其浪费 token 重复这些词，不如说明真正影响结果的内容：人物年龄区间、服装材质、镜头距离、主体位置、背景关系、文字内容和版式。

提示词可以用英文，尤其是涉及具体画面、字体、摄影和设计术语时，英文往往更稳定。说明性文字可用中文，但提交给模型的出图指令建议整体使用英文。

---

## 2. 通用提示词骨架

可直接套用下面的骨架，再根据任务删减：

> Create a [image type] of [main subject], [subject identity and key appearance].  
> Show [action, pose, expression, and interaction with objects].  
> Use [composition, framing, camera angle, and subject placement].  
> The setting is [environment, time, atmosphere, and important background elements].  
> Use [lighting, color palette, materials, and visual mood].  
> Render it as [visual style or medium], with [specific level of realism or abstraction].  
> Include [exact text or graphic elements, if any].  
> Keep [critical constraints]. Do not introduce [specific unwanted ambiguity, only when necessary].  
> Output as [aspect ratio, orientation, or intended use].

### 槽位说明

- **image type**：图片用途，如 editorial portrait、product advertisement、film still、book cover、travel poster。
- **main subject**：画面唯一或主要主体。先明确数量，避免模型自行增加人物或物体。
- **identity and appearance**：身份、年龄区间、发型、脸型、肤色、服装、配饰等。只写能被看见且对识别有用的特征。
- **action and pose**：主体正在做什么、身体朝向、视线、手的位置、人与物的关系。不要只写“自然姿势”。
- **composition**：景别、画幅、相机角度、主体位于左中右哪一侧、前景和留白。海报尤其要明确文字区域。
- **setting**：地点、季节、时间、背景层次和环境状态。
- **lighting and palette**：光源方向、软硬、色温、主色与辅助色。不要只写“电影感”，应说明电影感来自什么。
- **style or medium**：摄影、油画、平面插画、3D 产品渲染、木刻版画等，以及笔触、材质、细节程度。
- **critical constraints**：必须保留的元素、人物数量、产品形状、文字拼写、品牌色、视线方向。
- **output**：横竖构图、用途和比例，例如 vertical social-media cover、wide website hero image。比例是辅助说明，不应替代构图描述。

复杂任务应把最重要的信息放在前面。不要把十几个风格名并列；选择一个主风格，再用一两句描述其视觉特征。

---

## 3. 不同场景的可复用模板

### 3.1 人物写真 / 定妆照

人物图要明确“是谁、穿什么、怎样站、镜头看到什么”。定妆照通常需要正面、稳定、无遮挡的脸部和服装信息。

> Create a professional character lookbook portrait of one 32-year-old East Asian female detective. She has an oval face, warm light-medium skin, straight black hair cut just below the chin with a precise side part, dark brown eyes, and a small beauty mark below her left eye. She wears a charcoal wool trench coat over a cream shirt, with a thin silver watch on her left wrist.  
> She stands facing the camera in a relaxed three-quarter pose, shoulders visible, arms naturally resting at her sides, calm and observant expression. Keep her face unobstructed.  
> Frame her from the waist up against a simple warm-gray studio background, with soft diffused key light from the upper left and a subtle shadow on the right side of her face. Realistic editorial photography, restrained colors, natural skin texture, clean costume details. No other people. Vertical character-sheet composition.

如果需要“定妆照”，可追加：

> Show the complete hairstyle, makeup, costume, shoes, and key accessories clearly, with no dramatic cropping or motion blur.

不要只写“美女、电影感、酷、精致”，这些词没有提供稳定的视觉定义。人物性格应转化为表情、姿态、服装和光线。

### 3.2 产品图

产品图的核心是产品形状、材质、角度、摆放和背景关系。对商业产品，明确“只有一个产品”和“标签原样保留”很重要。

> Create a premium studio product photograph of one matte-black insulated travel mug with a cylindrical body, a brushed-steel lid, and a small copper-colored logo near the base. Place it upright on a pale travertine pedestal, viewed at a slight front three-quarter angle.  
> Use a warm off-white seamless background, soft large-box lighting from the upper left, a gentle contact shadow, and subtle reflections that reveal the metal and ceramic-like matte texture. Keep the mug’s proportions, lid shape, logo position, and black color accurate. Minimal luxury advertising style, centered composition, generous empty space above and to the right for copy. No hands, no extra products, no readable text except the specified logo.

如果产品有参考图，应明确：

> Use the attached product image as the shape and material reference. Preserve its silhouette, proportions, colors, and visible markings; change only the background and lighting.

### 3.3 场景氛围图

场景图要建立空间关系和叙事重点，不要只堆“梦幻、震撼、史诗”等抽象形容词。

> Create a cinematic wide shot of a small coastal railway station at dawn after heavy rain. A single red signal lamp glows beside the empty platform, while wet tracks lead from the foreground toward misty blue mountains in the distance. The station building is on the left third of the frame, leaving open atmospheric space on the right. Low fog, cool blue-gray ambient light, and a narrow band of warm sunrise light on the horizon. Quiet, lonely, contemplative mood, realistic environmental details, restrained color palette, no people, no vehicles, no random signs.

“氛围”应由天气、时间、光线、色彩、空间密度和物体状态共同产生，而不是只写 mood 词。

### 3.4 多图一致性：同一角色跨图

一致性不是重复“同一个人”就能保证。应建立一份**角色身份锚点**，每次复制基本不变，只修改动作、场景和服装等变量。

身份锚点应包含：

- 稳定的年龄区间和性别表达；
- 脸型、肤色、眼睛、鼻子、嘴唇等少量显著特征；
- 发型、发色和发际线；
- 一个或两个不易改变的识别标记，如左眉上方小疤、右耳银耳钉；
- 固定的描述顺序和措辞；
- 明确只有一个该角色。

推荐写法：

> The recurring character is Mina, a 29-year-old woman with warm olive skin, an oval face, deep-set dark brown eyes, straight black shoulder-length hair with blunt bangs, and a small crescent-shaped scar above her left eyebrow. She has a slim athletic build. Preserve these facial identity features, hairstyle, skin tone, and body proportions in every image. Mina is the only person in the scene.

之后每张图只替换场景变量：

> Use the same recurring character Mina with the exact identity description above. In this image, she is wearing a navy raincoat and standing inside a crowded Tokyo train at night...

若有上一张图或角色参考图，直接说明其作用：

> Use the attached reference image as the identity reference for Mina. Match her face, hair, skin tone, body proportions, and identifying scar. Change only her clothing, pose, and environment as requested.

不要在不同提示词中随意改写身份特征，例如上一张说“短黑发”，下一张说“齐肩黑发”；模型会把它们视为不同约束。把“不可变特征”和“本张可变特征”分开写，能显著减少漂移。

### 3.5 带文字的海报

文字任务必须提供**精确字符串、语言、位置、层级和字体气质**。不要让模型自行编标题、补副标题或添加品牌名。

> Design a vertical contemporary music festival poster. The exact headline must read: “NIGHT BLOOM”. The exact date line must read: “SEPTEMBER 14, 2026”. Do not add any other words, letters, numbers, logos, or signatures.  
> Place “NIGHT BLOOM” large in the upper third, centered, using bold condensed sans-serif lettering in warm white. Place the date line smaller directly below it with generous letter spacing. The lower two-thirds show a dark indigo field of oversized blooming flowers under a small silver moon. Keep the text high-contrast, correctly spelled, perfectly legible, and separate from the illustration. Vertical poster layout with balanced margins.

文字越短、层级越少、字体越普通，成功率通常越高。必要时先生成无字背景，再进行文字编辑或后期排版。对必须准确的长文案、法律信息和复杂表格，不应完全依赖一次性图像生成。

### 3.6 风格化插画

风格化插画应说明媒介和可观察的画面特征，而不是罗列艺术家姓名。可描述线条、色块、纹理、透视和边缘处理。

> Create a whimsical editorial illustration of a giant orange cat carrying a tiny glass greenhouse through a rainy city. Use flat gouache shapes, slightly uneven dark ink outlines, visible paper grain, muted teal and coral colors, simplified geometric buildings, and playful exaggerated scale. The cat is centered but walking toward the right, with small reflections in the wet pavement. Keep the image warm, handcrafted, and storybook-like, with no photorealistic rendering and no written text.

---

## 4. 有效写法与浪费写法

### 例一：抽象形容词堆叠

**反例：**

> Beautiful cinematic stunning masterpiece, ultra detailed, best quality, epic, professional, 8k portrait of a girl.

**为什么差：**  
“beautiful”“epic”“best quality”没有说明美在哪里；“cinematic”也没有指定镜头、光线或色彩。大量质量词占用上下文，却没有增加可执行信息。

**改写：**

> Create a realistic waist-up portrait of a young woman with short auburn hair and freckles, looking slightly past the camera. Use soft window light from the left, a muted green interior background, shallow depth of field, natural skin texture, and a quiet autumnal mood.

### 例二：标签堆和权重语法

**反例：**

> 1girl, solo, masterpiece, ((red dress:1.4)), cinematic, dramatic lighting, negative: extra fingers, bad anatomy.

**为什么差：**  
权重、标签格式和统一的 negative prompt 不是 GPT image 模型的主要沟通方式；“bad anatomy”也没有告诉模型希望怎样构图。

**改写：**

> Show one woman wearing a fitted deep-red evening dress, seated at a small table in a quiet hotel bar. Frame her from the knees up, with both hands visible and naturally resting on the table. Use warm side lighting and a dark amber background. Keep the scene limited to one woman and one glass.

### 例三：过度依赖否定句

**反例：**

> A busy street, no people, no cars, no signs, no clutter, no blur, no extra objects.

**为什么差：**  
先描述了“busy”，又要求没有人和车，语义冲突；否定列表不能替代正向构图。

**改写：**

> Show an empty, clean residential street just before sunrise. The road, sidewalks, and low apartment buildings are clearly visible, with only a few potted plants and one distant streetlamp. Use a quiet symmetrical composition and no visible pedestrians or vehicles.

否定句不是完全不能用。对高风险歧义可在正向描述后补一句，例如“No other people; the scene contains exactly one product.”但不要写几十项泛化的 negative prompt。

---

## 5. 常见翻车与预防

### 手部和姿势

手是高难度区域。避免“手势自然”这种空泛要求，改为可观察约束：

> Show both hands fully in frame. The left hand holds the book by its lower edge, and the right hand rests open on the table. Keep all five fingers anatomically separated and visible.

如果手不是重点，可以让其自然离开画面：

> Crop the image at the upper torso so the hands are outside the frame.

### 多人凭空出现

明确人数、身份和不可增加对象：

> Exactly two people are present: an older woman on the left and a teenage boy on the right. No other people, faces, silhouettes, mannequins, or figures in the background.

多人场景还要指定每个人的位置、动作和服装，避免角色互换。

### 文字乱码或擅自添加

重复一次精确文字即可，不要同时给多个互相竞争的标题。把文字放在简单、对比度高的区域，并明确：

> Render the exact text “OPEN STUDIO” in clear uppercase letters. Preserve spelling and punctuation. Add no other text.

复杂文字应分阶段生成，或在生成背景后使用编辑功能添加。

### 主体被裁切、产品变形

说明景别和边缘安全区：

> Keep the entire object inside the frame with a small margin on all sides. Do not crop the top, bottom, or handle.

对产品强调形状、尺寸关系和参考图；不要同时要求“改变产品外形”和“保持完全一致”。

---

## 6. 迭代与编辑策略

第一次生成不理想时，不要把原提示词全部重写。指出当前结果中需要改变的部分，并保留已正确的部分：

> Keep the same character, camera angle, background, and lighting. Change only her jacket from black leather to cream wool, and move her left hand from her pocket to the table.

一次只改一到三个变量，便于判断变化来源。若模型误解，可将关键要求移到开头，并换成更具体的视觉描述。若结果过于复杂，删掉次要装饰；若结果漂移，恢复身份锚点和参考图。

最终原则是：**先定义意图，再定义结构；先锁定主体，再添加风格；用可见事实替代空泛形容词；用少量关键约束消除歧义。**
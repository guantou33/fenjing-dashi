---
name: local-knowledge-base-build
description: Use when 要把本机散落的技能/笔记/会话记录合成一个能离线搜的单文件知识库。
---

# 本机知识库：素材 → 单文件可搜网页

把本机散落的学习素材（Hermes 技能库 SKILL.md、自建技能包、历史会话正文）抽成一个
**自包含单文件 html**，手机浏览器打开即用、带搜索。

## When to Use

- 用户说"把这些资料做成一个能查的东西""手机上能看我的技能/笔记吗""做个知识库"。
- 技能库或自建包有更新，要**重出**一份知识库。

交付到手机的托管/发送环节见 `single-file-webapp-delivery`（那条链路的坑都在那边）。

## 现成流水线（已在本机跑通）

工程目录：`C:\Users\111\Desktop\AI\知识库`

**本地单文件版**

1. `extract.py` —— 扫 `%LOCALAPPDATA%\hermes\skills` 与 `Desktop\AI\SKILL`，
   拆 YAML frontmatter（`name`/`description` 进元数据，正文单独存），输出 `kb_data.json`。
2. `template.html` —— 界面骨架：深色、移动优先、侧栏分组、搜索框、`#/d/<id>` 路由。
   数据位是 `var DATA = [...];` 单独一行，**好让脚本替换**。
3. `assemble.py` —— 把 `kb_data.json` + 人工整理的"本机实战速查"条目塞进模板，
   输出 `知识库.html`（单文件，CSS/JS 全内联）。
4. `test.js` —— node 跑的无浏览器单测：抽 `DATA` 校验条数、抽主脚本校验非空。

重出：`python extract.py && python assemble.py && node test.js`

**公网站点版（红白配色，长期托管 + 自动同步）**

现网：`https://guantou33.github.io/fenjing-dashi/`（仓库 `guantou33/fenjing-dashi`，
设备授权 token 存在 `知识库\token_ready.json`，永不打印到终端）。

1. `kb_collect.py` —— 采集，产出 `payload.json`（docs/blobs/groups/packs/topics）。
2. `kb_build.py` —— 单文件生成器。`TEMPLATE` 是整页字符串，占位符
   `__DATA__`（全量 JSON）/`__BUILT__`/`__NDOC__`；构建时另把
   `ghpages/media/index.json` 塞进 `payload["media"]`（作品表示例数据内嵌，离线也看得到）。
   写出 `知识库.html` 与 `ghpages/index.html`；内容无变化时不重写（保留时间戳）。
3. `sync.py` —— 重建 + 打包各分类 zip + 增量上传（比对 git blob sha，未变跳过），
   成功后微信通知。token 读 `token_ready.json`。
4. `deploy_fast.py` —— **快传版**：走 git data API（blobs → tree → commit → 更新 ref），
   一次提交 130 个文件约 3 分钟；只传变化的，且不会删掉远端多出来的文件
   （网页上传的 `media/u/*` 靠这条保住）。日常改版用这个，别用逐个 `PUT /contents`。
5. `kb_autosync.py`（在 `%LOCALAPPDATA%\hermes\scripts`）—— cron 每 6 小时调 `sync.py`，
   无变化则静默退出。

## 静态站点的"自助上传"（不用后端）

GitHub Pages 是纯静态，但一样能让用户在网页上自己传文件：

- `ghpages/upload.html`：用户填一次仓库名 + fine-grained token（只勾本仓库、只给
  Contents 读写），存 `localStorage`；之后拖文件/粘贴截图即传。**token 不经过 agent**。
- 上传走 git data API 一次提交多文件：`git/blobs` → `git/trees`（`base_tree` 保留其他文件）
  → `git/commits` → `PATCH git/refs/heads/<branch>`。这条路径没有 Contents API 的 1MB 限制。
- 图片在前端压成 1600px webp + 520px 缩略图，视频抽 0.6s 帧当封面，体积可控。
- 作品清单写 `media/works.json`（运行时 `fetch` 取，随上传即时更新）；
  页面里构建期内嵌的示例数据是另一份（`media/index.json`），两者在渲染时合并。
- 删除也做在同一页：tree 里给该路径 `sha: null` 即为删除，同时改 `works.json`。

## 作品表的两条轴：分类线 × 剧本

作品表的条目统一带四个字段：`line`（分类线）、`script`（所属剧本）、`folder`（文件夹）、`cat`（说明文字）。

- **`line` 只有三个值：`AI` / `资产` / `摄影`**（生成图与成片 / 角色场景道具设定 / 参考与逐帧与质感）。
  筛选行要**恒显三档**（哪怕计数为 0），用户要看得到分类体系本身，别把空档隐藏掉。
- **`script` 空串 = 未归剧本**，筛选行给一档「未归剧本」，让没归类的条目有去处、不消失。
- 内嵌示例数据 `ghpages/media/index.json` 里手工补 `line`/`script`（示例项通常 `script=""`）；
  上传页给「分类」下拉 + 「剧本」datalist，`kb_upload.py` 给 `--line`（choices 三值）/`--script`。
- **剧本维度是聚合视图，不是新的一套数据**：一个剧本 = 一张卡（目录区收成一行剧本行、卡片区收成一张剧本卡），
  点开进全屏面板，里面按角色分「创作思路 / 大纲 / 剧本 / 设定 / 记录」列出文档，
  再按 `line` 分「成片 / 资产 / 摄影」列出作品。文档侧的 `proj`/`role` 由 `kb_collect.py` 打。
- 聚合视图的数据来自 `P.scripts`（剧本名 + 一句话 + 状态 + 文档 id），
  外加运行时按 `proj === name` / `script === name` 反查，**不要另存一份副本**，否则两边会漂。
- 剧本卡在**搜索时自动摊开**成逐篇结果（按篇能搜到），无搜索词时才收成一张卡。

## 删除：两种来源两条路

- **自己上传的**：灯箱里点删除 → 走 git data API 把文件 tree 项设 `sha:null`，
  同时改 `media/works.json`；token 复用上传页存在 `localStorage` 的那份。
- **构建期内嵌的示例**：仓库文件不能真删（`deploy_fast.py` 会把它传回来），
  所以走**本地隐藏名单**（`localStorage` 记 `demo:<thumb>`），刷新后仍隐藏。
  要真删仓库里的示例，只能改 `media/index.json` 后重部署——跟用户说清楚这个区别。

## 界面：目录与图库要并存

- 用户既要"目录那种工整感"，也要作品表/图库，**不是二选一**：首页先给
  「目录」（分组卡片 → 编号 + 标题 + 关键词，两列），再给「作品表 · 图库」。
- 图库要同时提供轮播（横向 scroll-snap + 自动前进）和网格两种模式，点开进灯箱看大图。
- **单个下载的入口必须露在外面**：卡片上给「⇩ 单条」、目录行 hover 给「⇩」、正文页给「下载」。
  只留"整包 zip"会被吐槽"很难单个下载"。

## 硬规则

- **正文在页面里现渲染，不预渲染 HTML**：把 markdown 原文塞进 `DATA`，前端转义后再转标签。
  预渲染会让文件膨胀且没法做高亮。
- **搜索用"预处理小写干草堆 + 分词 every 命中"**，并把命中片段 `mark` 出来；
  中文不分词，按整串 `indexOf` 即可（`锁脸`、`分镜` 这类词直接命中）。
- **抽取要按目录分类**：目录名做中文分类（`storyboard` → 影视分镜），
  自建包单独一组，别混进 Hermes 技能库里。
- 交付前必须走一遍：node 单测 → 本地 `http.server` 起服务 → 真浏览器点搜索/点分类/进正文。

## 坑

- **`DATA` 必须是数组**：`buildNav`/`search` 都直接 `DATA.forEach`。
  任何把 `DATA` 变成非数组的写法（包括在页面里手搓 `var DATA=数字`）都会让搜索整块失效。
- **侧栏 `data-id` 选择器别用单引号**：CSS 属性选择器只认双引号或无引号，
  `[data-id='x']` 在浏览器里直接抛 SyntaxError。
- **分类页没有 `h1`**：首页/正文用 `h1`，分类列表页不一定有；
  取标题前先判空，别让测试脚本崩在 `null.textContent`。
- **核验线上文件别信 `raw.githubusercontent.com`**：它对旧路径会继续吐缓存内容，
  用带随机 query 的 URL 也未必绕开，容易误判"上传失败"而去乱改代码。
  要核验就查 API：`git/trees/main?recursive=1` 比 blob sha，或 `contents/<path>` 取正文。
- **重出后**托管链接必须重传：旧链接指向旧文件，不会自动更新。
- **上传脚本必须 `os.walk` 整站**：只列根目录 + `downloads/*.zip` 的老写法，
  新增的 `upload.html`、`media/` 永远传不上去，站点看着"没更新"。同时排除
  `_skeleton.txt` 这类本机草稿，别把 6MB 垃圾发到公开仓库。
- **git blobs API 会偶发 500**（空 body），重跑即可，不要当成权限问题去折腾 token。
- **公开站点不要放露骨素材**：素材目录里混着裸露内容时，先抽首帧看一遍再决定上不上，
  GitHub 是公开仓库，放上去有封号风险；用户自己上传的由他自己负责。
- **改生成器的字符串用脚本做、别手改大文件**：`TEMPLATE` 有几百行，
  写个 `patch_kb.py` 做"锚点断言 + 替换"，命中数不等于 1 就退出，可重复运行（幂等）。
- 生成的页面脚本包在 IIFE 里，函数**不是全局的**；浏览器里验证要走 DOM 点击，
  别直接 `js("closeLb()")`。
- **前端压图要把 canvas 转成 Blob 再传**：`canvas.toBlob()` 是异步的，
  把 canvas 对象当 Blob 存进对象里，到 `FileReader.readAsDataURL` 才报错——
  而且异常发生在设了 `ready=true` 之后，日志看起来"成功"，实际一上传就炸。
  加个 `p.processing` 标记，避免重渲染时重复处理大文件。
- 本地预览用 `python -m http.server` 时**注意实际服务根目录**（后台起进程时 `cd` 可能不生效），
  路径要写成 `/ghpages/index.html`；验完记得关掉，否则 8899 端口一直占着。

## 相关技能

- 托管到公网 + 发到手机 + 完整性核验：`single-file-webapp-delivery`。
- 会话正文抽取（`state.db` 结构与查询）：`hermes-session-history`。

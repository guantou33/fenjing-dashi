---
name: local-knowledge-base-build
description: Use when 要把本机散落的技能/笔记/会话记录合成一个能离线搜的单文件知识库。
---

# 本机知识库：素材 → 单文件可搜网页

把本机散落的学习素材（Hermes 技能库 SKILL.md、自建技能包、历史会话正文）抽成一个
**自包含单文件 html**，手机浏览器打开即用、带搜索。

## When to Use

- 用户说"把这些资料做成一个能查的东西""手机上能看我的技能/笔记吗""做个知识库"。
- 技能库或自建包有更新，要**重出**一份知识库。

交付到手机的托管/发送环节见 `single-file-webapp-delivery`（那条链路的坑都在那边）。

## 现成流水线（已在本机跑通）

工程目录：`C:\Users\111\Desktop\AI\知识库`

**本地单文件版**

1. `extract.py` —— 扫 `%LOCALAPPDATA%\hermes\skills` 与 `Desktop\AI\SKILL`，
   拆 YAML frontmatter（`name`/`description` 进元数据，正文单独存），输出 `kb_data.json`。
2. `template.html` —— 界面骨架：深色、移动优先、侧栏分组、搜索框、`#/d/<id>` 路由。
   数据位是 `var DATA = [...];` 单独一行，**好让脚本替换**。
3. `assemble.py` —— 把 `kb_data.json` + 人工整理的"本机实战速查"条目塞进模板，
   输出 `知识库.html`（单文件，CSS/JS 全内联）。
4. `test.js` —— node 跑的无浏览器单测：抽 `DATA` 校验条数、抽主脚本校验非空。

重出：`python extract.py && python assemble.py && node test.js`

**公网站点版（红白配色，长期托管 + 自动同步）**

现网：`https://guantou33.github.io/fenjing-dashi/`（仓库 `guantou33/fenjing-dashi`，
设备授权 token 存在 `知识库\token_ready.json`，永不打印到终端）。

1. `kb_collect.py` —— 采集，产出 `payload.json`（docs/blobs/groups/packs/topics）。
2. `kb_build.py` —— 单文件生成器。`TEMPLATE` 是整页字符串，占位符
   `__DATA__`（全量 JSON）/`__BUILT__`/`__NDOC__`；构建时另把
   `ghpages/media/index.json` 塞进 `payload["media"]`（作品表示例数据内嵌，离线也看得到）。
   写出 `知识库.html` 与 `ghpages/index.html`；内容无变化时不重写（保留时间戳）。
3. `sync.py` —— 重建 + 打包各分类 zip + 增量上传（比对 git blob sha，未变跳过），
   成功后微信通知。token 读 `token_ready.json`。
4. `deploy_fast.py` —— **快传版**：走 git data API（blobs → tree → commit → 更新 ref），
   一次提交 130 个文件约 3 分钟；只传变化的，且不会删掉远端多出来的文件
   （网页上传的 `media/u/*` 靠这条保住）。日常改版用这个，别用逐个 `PUT /contents`。
5. `kb_autosync.py`（在 `%LOCALAPPDATA%\hermes\scripts`）—— cron 每 6 小时调 `sync.py`，
   无变化则静默退出。

## 静态站点的"自助上传"（不用后端）

GitHub Pages 是纯静态，但一样能让用户在网页上自己传文件：

- `ghpages/upload.html`：用户填一次仓库名 + fine-grained token（只勾本仓库、只给
  Contents 读写），存 `localStorage`；之后拖文件/粘贴截图即传。**token 不经过 agent**。
- 上传走 git data API 一次提交多文件：`git/blobs` → `git/trees`（`base_tree` 保留其他文件）
  → `git/commits` → `PATCH git/refs/heads/<branch>`。这条路径没有 Contents API 的 1MB 限制。
- 图片在前端压成 1600px webp + 520px 缩略图，视频抽 0.6s 帧当封面，体积可控。
- 作品清单写 `media/works.json`（运行时 `fetch` 取，随上传即时更新）；
  页面里构建期内嵌的示例数据是另一份（`media/index.json`），两者在渲染时合并。
- 删除也做在同一页：tree 里给该路径 `sha: null` 即为删除，同时改 `works.json`。

## 作品表的两条轴：分类线 × 剧本

作品表的条目统一带四个字段：`line`（分类线）、`script`（所属剧本）、`folder`（文件夹）、`cat`（说明文字）。

- **`line` 只有三个值：`AI` / `资产` / `摄影`**（生成图与成片 / 角色场景道具设定 / 参考与逐帧与质感）。
  筛选行要**恒显三档**（哪怕计数为 0），用户要看得到分类体系本身，别把空档隐藏掉。
- **`script` 空串 = 未归剧本**，筛选行给一档「未归剧本」，让没归类的条目有去处、不消失。
- 内嵌示例数据 `ghpages/media/index.json` 里手工补 `line`/`script`（示例项通常 `script=""`）；
  上传页给「分类」下拉 + 「剧本」datalist，`kb_upload.py` 给 `--line`（choices 三值）/`--script`。
- **剧本维度是聚合视图，不是新的一套数据**：一个剧本 = 一张卡（目录区收成一行剧本行、卡片区收成一张剧本卡），
  点开进全屏面板，里面按角色分「创作思路 / 大纲 / 剧本 / 设定 / 记录」列出文档，
  再按 `line` 分「成片 / 资产 / 摄影」列出作品。文档侧的 `proj`/`role` 由 `kb_collect.py` 打。
- 聚合视图的数据来自 `P.scripts`（剧本名 + 一句话 + 状态 + 文档 id），
  外加运行时按 `proj === name` / `script === name` 反查，**不要另存一份副本**，否则两边会漂。
- 剧本卡在**搜索时自动摊开**成逐篇结果（按篇能搜到），无搜索词时才收成一张卡。

## 改名：本地覆盖层 + 可选写回仓库

网页上给「照片/图片/视频/文档」改名，做法是**覆盖层**而不是改源文件：

- `localStorage['kb_renames'] = {docs:{}, works:{}, insp:{}}`，键分别是文档 id、`full||thumb`、灵感 id。
- 页面初始化时把覆盖名**直接写回内存对象**（`DOCS[i].title = ...`），后续卡片/详情/最近更新/命令面板全自动生效，
  不需要去改十几处渲染代码。异步加载的数据（`loadWorks`/`loadInsp`）拿到后要**再 apply 一次**。
- 连过上传页的 token 时，同时写回仓库 `media/renames.json`（git data API），换设备也在；没 token 就只在本机生效。
- 交互硬规则（用户明确要求）：点铅笔 → 出输入框 → **只有点「确定」才保存**；「取消」或 Esc 一律还原，
  **不要绑 blur 保存**。编辑框和输入框都要 `stopPropagation`，否则点铅笔会顺手把文档打开（用捕获阶段监听 + 拦）。
- 铅笔按钮走 `document` 捕获阶段的**事件委托**（`e.target.closest('.rnbtn')`），卡片是 innerHTML 重渲染的，逐次绑会丢。

## 作品表第三视图：时间流（朋友圈式）

除轮播/网格外给一个「时间流」：按上传日期**倒序**，**同一天 + 同一文件夹**聚成一条，
图片排九宫格（最多 9 格，多出显示 `+N`），左侧时间轴圆点 + 竖线，日期标题写「今天 / 昨天 / 前天 / 10月8日 周三」。
- 日期取值 `it.date || it.saved || it.mtime`，要写个容错的 `galWhen()`（`new Date('2026-10-08 05:23')` 在部分浏览器是 Invalid Date，
  先 `replace(' ','T')`，再退化到 `replace(/-/g,'/')`）。
- 九宫格每格要能点开灯箱：用 `full||thumb` 建一个「键 → 在 `galAll()` 里的下标」的映射，别用渲染序号。
- 视图选择存 `localStorage['kb_galmode']`，刷新后恢复。
- **内嵌示例作品通常没有 `date`**，全挤进「日期未标」那一组。构建时补：拿 `it.full`/`it.thumb` 对应本地文件的
  `os.path.getmtime()` 当上传日期。

## 视频拆解：逐镜拉片表

灵感库详情里给一张**时间轴拉片表**（时间码 / 缩略图 / 台词 / 这一镜在干嘛），点一行把 `<video>` 跳到该秒。

- 行来自 `transcript`（`{t,e,s}`），缩略图没有时间戳时按 `t/dur*frames.length` 取最近的一帧，表下注明「按时间比例取」。
- 某列**整列为空就别渲染这一列**（`hasVi = rows.some(r=>r.v)`），空列比没有列更难看。

## 删除：两种来源两条路

- **自己上传的**：灯箱里点删除 → 走 git data API 把文件 tree 项设 `sha:null`，
  同时改 `media/works.json`；token 复用上传页存在 `localStorage` 的那份。
- **构建期内嵌的示例**：仓库文件不能真删（`deploy_fast.py` 会把它传回来），
  所以走**本地隐藏名单**（`localStorage` 记 `demo:<thumb>`），刷新后仍隐藏。
  要真删仓库里的示例，只能改 `media/index.json` 后重部署——跟用户说清楚这个区别。

## 界面：目录与图库要并存

- 用户既要"目录那种工整感"，也要作品表/图库，**不是二选一**：首页先给
  「目录」（分组卡片 → 编号 + 标题 + 关键词，两列），再给「作品表 · 图库」。
- 图库要同时提供轮播（横向 scroll-snap + 自动前进）和网格两种模式，点开进灯箱看大图。
- **单个下载的入口必须露在外面**：卡片上给「⇩ 单条」、目录行 hover 给「⇩」、正文页给「下载」。
  只留"整包 zip"会被吐槽"很难单个下载"。

## 硬规则

- **正文在页面里现渲染，不预渲染 HTML**：把 markdown 原文塞进 `DATA`，前端转义后再转标签。
  预渲染会让文件膨胀且没法做高亮。
- **搜索用"预处理小写干草堆 + 分词 every 命中"**，并把命中片段 `mark` 出来；
  中文不分词，按整串 `indexOf` 即可（`锁脸`、`分镜` 这类词直接命中）。
- **抽取要按目录分类**：目录名做中文分类（`storyboard` → 影视分镜），
  自建包单独一组，别混进 Hermes 技能库里。
- 交付前必须走一遍：node 单测 → 本地 `http.server` 起服务 → 真浏览器点搜索/点分类/进正文。

## 手机端顶栏（用户手机上看，宽度只有 360–414px）

- **顶栏不要固定、不要滚动收窄**（用户明确要求，试过 sticky + 滚动收窄后被叫停）：
  站名随页面正常流动，`position:relative` 即可。别再自作聪明加 `position:sticky`、
  `body.scrolled` 收窄动画那套——加了他会要求改回去。
- 三个主入口（目录 / 作品表 / 灵感库）**单独占一行、居中、跟其它 UI 区分开**：
  `.hrow` 容器（`max-width:620px;margin:auto`、浅红底 + 圆角边框）内三个 `.hbtn`
  等宽 `flex:1 1 0`，主标题 + 一行小注（`<u>` 去下划线、灰色小字），
  hover/选中态填充红色渐变。原来的小按钮行 `.hact` 保持在其下方。
- 横向溢出用 `html{overflow-x:clip}`（`hidden` 会让 sticky 在部分浏览器失效）。
  自检口径：`document.documentElement.scrollWidth <= innerWidth`。注意 `mobile=False` 模拟时
  布局视口比 `innerWidth` 小一个滚动条宽（约 15px），别把这点差当成"没居中"。

## 今日资讯（替代原来的「随便看看」）

- `update_news.py`（工程根目录）：抓「每天 60 秒读懂世界」近 7 天每日大事
  （`https://60s.viki.moe/v2/60s?date=YYYY-MM-DD`，逐日请求要 `sleep(1.6)`，429 要等 8 秒重试），
  再抓 RSS 过滤 AI·创作圈关键词，写 `ghpages/media/news.json`；`--deploy` 顺带重建 + 部署。
- 可用 RSS：IT之家、量子位（`qbitai.com/feed`，AI 质量最高）、爱范儿、界面、少数派。
  **36氪 `/feed` 返回 HTML 墙、机器之心 `/rss` 无 item**，别再往里加。
- 排序：强关键词（模型/生成/创作工具）命中多的排前，纯硬件机器人靠后；同标题去重；上限 14 条。
- 页面侧：数据既**构建期内嵌**（`window.__KB__.news`，离线可看）又运行时 `fetch('media/news.json')` 覆盖；
  区块 `#secNews` 放首页最前，每日用 `<details>` 折叠，只有今天那条默认展开，标题旁标「更新于 …」。
- 每日自动更新：Hermes cron `05 8 * * *` 调 `%LOCALAPPDATA%\hermes\scripts\news_daily.py`
  （`no_agent=True` + `script=`，纯脚本零 token；包装脚本用 `sys.executable` 调 `update_news.py --deploy`，不依赖 PATH）。
- 横向溢出用 `html{overflow-x:clip}`（`hidden` 会让 sticky 在部分浏览器失效）。
  自检口径：`document.documentElement.scrollWidth <= innerWidth`。注意 `mobile=False` 模拟时
  布局视口比 `innerWidth` 小一个滚动条宽（约 15px），别把这点差当成"没居中"。

## 坑

- **浏览器里验证滚动监听，必须先 `cdp('Page.bringToFront')`**：标签页在后台时 Chrome 不跑渲染生命周期，
  `window.scrollTo()` 会真的滚动，但 **scroll 事件根本不派发**，于是"监听器没生效"是假象；
  用 `cdp('Input.dispatchMouseEvent',type='mouseWheel',x=..,y=..,deltaY=900)` 走真实输入，或先 bringToFront。
  同理：后台标签页 `capture_screenshot()` 容易超时，截图还可能拿到旧/空页面（先确认 `location.href`）。
- **滚动类状态要在脚本末尾先算一次**（`_hdApply()` 紧跟在 `addEventListener` 之后）：
  手机刷新时浏览器会恢复滚动位置，光靠 scroll 事件要等用户再滑一下才生效。
- **浏览器 daemon 的标签页会自己跑掉**：量着量着 `location.href` 变成 `about:blank`、
  `querySelector` 返回 null 报 `Cannot read properties of null`——先打印 URL 再判断，别急着改代码。

- **`DATA` 必须是数组**：`buildNav`/`search` 都直接 `DATA.forEach`。
  任何把 `DATA` 变成非数组的写法（包括在页面里手搓 `var DATA=数字`）都会让搜索整块失效。
- **侧栏 `data-id` 选择器别用单引号**：CSS 属性选择器只认双引号或无引号，
  `[data-id='x']` 在浏览器里直接抛 SyntaxError。
- **分类页没有 `h1`**：首页/正文用 `h1`，分类列表页不一定有；
  取标题前先判空，别让测试脚本崩在 `null.textContent`。
- **核验线上文件别信 `raw.githubusercontent.com`**：它对旧路径会继续吐缓存内容，
  用带随机 query 的 URL 也未必绕开，容易误判"上传失败"而去乱改代码。
  要核验就查 API：`git/trees/main?recursive=1` 比 blob sha，或 `contents/<path>` 取正文。
- **重出后**托管链接必须重传：旧链接指向旧文件，不会自动更新。
- **上传脚本必须 `os.walk` 整站**：只列根目录 + `downloads/*.zip` 的老写法，
  新增的 `upload.html`、`media/` 永远传不上去，站点看着"没更新"。同时排除
  `_skeleton.txt` 这类本机草稿，别把 6MB 垃圾发到公开仓库。
- **git blobs API 会偶发 500**（空 body），重跑即可，不要当成权限问题去折腾 token。
- **公开站点不要放露骨素材**：素材目录里混着裸露内容时，先抽首帧看一遍再决定上不上，
  GitHub 是公开仓库，放上去有封号风险；用户自己上传的由他自己负责。
- **改生成器的字符串用脚本做、别手改大文件**：`TEMPLATE` 有几百行，
  写个 `patch_kb.py` 做"锚点断言 + 替换"，命中数不等于 1 就退出，可重复运行（幂等）。
- 生成的页面脚本包在 IIFE 里，函数**不是全局的**；浏览器里验证要走 DOM 点击，
  别直接 `js("closeLb()")`。
- **加筛选态记得关掉卡片折叠**：首页默认把同一剧本的多篇收成一张剧本卡（`collapse`），
  任何新的筛选态（如「只看新增」「只看这些」）都要让折叠让位，否则计数行、角标数、列表条数三个数字对不上，
  排查半天才发现是折叠吃掉了 8 篇。
- **kind 名字要全链路统一**：改名接口用 `data-k="doc"` 而存储用 `RENAMES.docs` 时，会静默写进一个没人读的顶层键
  （`{"doc":{...}}`），改名看着成功、标题就是不变。这类"写入成功但不生效"优先怀疑键名不一致。
- **浏览器 daemon 偶发 `PermissionError: bu-default.port`**（端口文件删不掉）：换一个 session 名重开即可，
  不要反复重试同一个默认 session。
- **`file://` 与托管版 `localStorage` 不同源**：改名/收藏/常看在本机双击打开时只存在本机，
  托管站上是另一份。交付时要说清"在哪打开决定存哪"，别让用户以为两边同步。
- **上传页抽视频封面会静默吃掉整条上传**：`makeVideoThumb` 的 `ready` 只在抽帧回调里置位，
  手机（HEVC / 大文件 / 抽帧不回调）就永远停在 `processing` → 点上传时 `manifestAdd` 为空 →
  页面提交一个**空提交**（远端能看到 "上传作品：" 但没有文件），用户以为传了、线上什么都没有。
  排查口径：`GET /commits/<sha>` 看 `files` 是否为空，或看 `media/works.json` 是不是被刷成了 `{"works":[]}`。
  修法（已落 `ghpages/upload.html`）：抽帧加 15 秒 watchdog，超时也 `ready=true` + `thumbFailed=true`，
  无封面照传（`entry.thumb=''`），首页用 `thumbOf()` 给视频兜一张播放图标占位图；
  `manifestAdd` 为空时直接抛错中止；全部就绪时打一行「全部就绪，可以点上传了」。
  事后补封面：工程根目录 `fix_covers.py`（取回远端视频 → ffmpeg 抽 0.6s 帧 → 传 `.webp` + 回写 `works.json`）。
- **iPhone 拍的 `.mov` 别原样上线，转成 `.mp4` 再传**：`Content-Type: video/quicktime` 在部分安卓浏览器/内嵌 WebView 里不认，
  用户会看到"一直在转圈、播不出来"。修法：`ffmpeg -i x.mov -c copy -movflags +faststart x.mp4`（无损换壳，秒级完成），
  把文件换成 `.mp4` 并同步改 `media/works.json` 里的 `full`，旧 `.mov` 用 tree 项 `sha:null` 一起删掉，省一半仓库体积。
  先自检容器：mp4/mov 头里 `moov` 若排在 `mdat` **之后**（iPhone 常见），Chrome 必须下完整个文件才能出画面，
  手机上等于"永远在加载"——`-movflags +faststart` 会把 `moov` 挪到最前。
- **前端压图要把 canvas 转成 Blob 再传**：`canvas.toBlob()` 是异步的，
  把 canvas 对象当 Blob 存进对象里，到 `FileReader.readAsDataURL` 才报错——
  而且异常发生在设了 `ready=true` 之后，日志看起来"成功"，实际一上传就炸。
  加个 `p.processing` 标记，避免重渲染时重复处理大文件。
- 本地预览用 `python -m http.server` 时**注意实际服务根目录**（后台起进程时 `cd` 可能不生效），
  路径要写成 `/ghpages/index.html`；验完记得关掉，否则 8899 端口一直占着。

## 相关技能

- 托管到公网 + 发到手机 + 完整性核验：`single-file-webapp-delivery`。
- 会话正文抽取（`state.db` 结构与查询）：`hermes-session-history`。

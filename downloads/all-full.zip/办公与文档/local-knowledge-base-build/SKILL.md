---
name: local-knowledge-base-build
description: Use when 要把本机散落的技能/笔记/会话记录合成一个能离线搜的单文件知识库。
---

# 本机知识库：素材 → 单文件可搜网页

把本机散落的学习素材（Hermes 技能库 SKILL.md、自建技能包、历史会话正文）抽成一个
**自包含单文件 html**，手机浏览器打开即用、带搜索。

## When to Use

- 用户说"把这些资料做成一个能查的东西""手机上能看我的技能/笔记吗""做个知识库"。
- 技能库或自建包有更新，要**重出**一份知识库。

交付到手机的托管/发送环节见 `single-file-webapp-delivery`（那条链路的坑都在那边）。

## 现成流水线（已在本机跑通）

工程目录：`C:\Users\111\Desktop\AI\知识库`

1. `extract.py` —— 扫 `%LOCALAPPDATA%\hermes\skills` 与 `Desktop\AI\SKILL`，
   拆 YAML frontmatter（`name`/`description` 进元数据，正文单独存），输出 `kb_data.json`。
2. `template.html` —— 界面骨架：深色、移动优先、侧栏分组、搜索框、`#/d/<id>` 路由。
   数据位是 `var DATA = [...];` 单独一行，**好让脚本替换**。
3. `assemble.py` —— 把 `kb_data.json` + 人工整理的"本机实战速查"条目塞进模板，
   输出 `知识库.html`（单文件，CSS/JS 全内联）。
4. `test.js` —— node 跑的无浏览器单测：抽 `DATA` 校验条数、抽主脚本校验非空。

重出：`python extract.py && python assemble.py && node test.js`

## 硬规则

- **正文在页面里现渲染，不预渲染 HTML**：把 markdown 原文塞进 `DATA`，前端转义后再转标签。
  预渲染会让文件膨胀且没法做高亮。
- **搜索用"预处理小写干草堆 + 分词 every 命中"**，并把命中片段 `mark` 出来；
  中文不分词，按整串 `indexOf` 即可（`锁脸`、`分镜` 这类词直接命中）。
- **抽取要按目录分类**：目录名做中文分类（`storyboard` → 影视分镜），
  自建包单独一组，别混进 Hermes 技能库里。
- 交付前必须走一遍：node 单测 → 本地 `http.server` 起服务 → 真浏览器点搜索/点分类/进正文。

## 坑

- **`DATA` 必须是数组**：`buildNav`/`search` 都直接 `DATA.forEach`。
  任何把 `DATA` 变成非数组的写法（包括在页面里手搓 `var DATA=数字`）都会让搜索整块失效。
- **侧栏 `data-id` 选择器别用单引号**：CSS 属性选择器只认双引号或无引号，
  `[data-id='x']` 在浏览器里直接抛 SyntaxError。
- **分类页没有 `h1`**：首页/正文用 `h1`，分类列表页不一定有；
  取标题前先判空，别让测试脚本崩在 `null.textContent`。
- 重出后**托管链接必须重传**：旧链接指向旧文件，不会自动更新。

## 相关技能

- 托管到公网 + 发到手机 + 完整性核验：`single-file-webapp-delivery`。
- 会话正文抽取（`state.db` 结构与查询）：`hermes-session-history`。

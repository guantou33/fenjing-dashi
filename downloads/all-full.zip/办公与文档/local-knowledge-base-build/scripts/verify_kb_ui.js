// 知识库 UI 自检：真实 DOM 点击「作品表 → 卡片 → 灯箱」，核对 AI 图是否弹出原提示词
// 用法: node verify_kb_ui.js [知识库.html 路径] [media/index.json 路径]
// 依赖: npm i jsdom（在工程根目录或任意 node 工程里装一次即可）
// 退出码 0 = 全通过，1 = 有失败项
const fs = require('fs');
const path = require('path');

// jsdom 按“脚本所在目录”向上找 node_modules，不是 cwd：脚本在技能目录里，工程根装的 jsdom 找不到。
// 这里显式探测几个常见位置，省得用户去配 NODE_PATH（MSYS 风格路径传给原生 node 也不认）。
const JSDOM_DIRS = [
  process.env.KB_JSDOM_DIR,
  'C:/Users/111/Desktop/AI/知识库/node_modules',
  path.join(__dirname, '..', 'node_modules'),
  path.join(process.cwd(), 'node_modules')
].filter(Boolean);
let jsdomMod = null;
for (const p of [null, ...JSDOM_DIRS]) {
  try { jsdomMod = p ? require(path.join(p, 'jsdom')) : require('jsdom'); break; } catch (e) {}
}
if (!jsdomMod) {
  console.error('找不到 jsdom。先在工程根装：cd C:/Users/111/Desktop/AI/知识库 && npm i jsdom');
  console.error('或指定：KB_JSDOM_DIR=<node_modules 所在目录> node verify_kb_ui.js');
  process.exit(2);
}
const { JSDOM, VirtualConsole } = jsdomMod;

const HTML = process.argv[2] || 'C:/Users/111/Desktop/AI/知识库/知识库.html';
const IDX = process.argv[3] || path.join(path.dirname(HTML), 'ghpages/media/index.json');

const html = fs.readFileSync(HTML, 'utf8');
let idx = [];
try { idx = JSON.parse(fs.readFileSync(IDX, 'utf8')); } catch (e) { console.log('（没读到 index.json，只做面板/复制一致性检查）'); }
const want = {};
idx.forEach(it => { if (it.prompt) want[it.id] = it; });
console.log('index.json 里带提示词的条目:', Object.keys(want).join(', ') || '(无)');

// 页面脚本包在 IIFE 里，函数不挂 window；这里只驱动真实 DOM 事件。
// jsdom 缺 scrollTo / scrollIntoView，页面里的自动轮播定时器会刷屏报错 —— 静默掉。
const vc = new VirtualConsole();
const dom = new JSDOM(html, {
  runScripts: 'dangerously', pretendToBeVisual: true, url: 'http://localhost/', virtualConsole: vc,
  beforeParse(win) {
    win.scrollTo = () => {};
    win.Element.prototype.scrollTo = () => {};
    win.Element.prototype.scrollIntoView = () => {};
    try { delete win.navigator.clipboard; } catch (e) { win.navigator.clipboard = undefined; } // 走 prompt() 兜底分支便于捕获
  }
});
const w = dom.window, d = w.document;
let fails = 0;
const ok = (c, m) => { console.log((c ? '  PASS  ' : '  FAIL  ') + m); if (!c) fails++; };

setTimeout(() => {
  try {
    console.log('KB 载入:', !!w.__KB__, '| media 条目', w.__KB__ ? w.__KB__.media.length : 0);
    d.getElementById('jumpGal').click();                       // 顶部「作品表 · 图库」入口
    const sec = d.getElementById('secGal');
    let cards = sec.querySelectorAll('.gcard');
    if (!cards.length) { d.getElementById('gGrid').click(); cards = sec.querySelectorAll('.gcard'); }
    console.log('作品表卡片数:', cards.length, '| 统计行:', (d.getElementById('gstat') || {}).textContent);

    const found = {};
    for (const c of Array.from(cards)) {
      c.click();
      const lb = d.getElementById('lb');
      if (!lb.classList.contains('on')) { ok(false, '卡片点击未打开灯箱'); continue; }
      const pre = d.getElementById('lbprTxt');
      const neg = d.getElementById('lbprNeg');
      const btn = d.getElementById('lbprc');
      const title = (d.querySelector('#lb h3') || {}).textContent || '';
      if (pre) {
        found[title] = { prompt: pre.textContent, neg: neg ? neg.textContent : null };
        let cap = null; w.prompt = (m, t) => { cap = t; return null; };
        if (btn) {
          btn.click();
          const expect = pre.textContent + (neg ? '\n\n负向提示词：' + neg.textContent : '');
          if (cap !== expect) ok(false, title + ' 复制内容与面板不一致');
        } else ok(false, title + ' 缺「复制提示词」按钮');
      }
      const x = d.getElementById('lbx'); if (x) x.click();      // 只能点关闭按钮，closeLb() 不是全局
    }

    console.log('\n带提示词面板的图:', Object.keys(found).length, '张');
    for (const [t, v] of Object.entries(found)) console.log('   ·', t, '|', v.prompt.length, '字 | 负向词', !!v.neg);

    console.log('\n=== 与 index.json 逐字核对 ===');
    for (const [k, src] of Object.entries(want)) {
      const hit = Object.entries(found).find(([, v]) => v.prompt === src.prompt);
      ok(!!hit, k + '（' + src.title + '）面板提示词与 index.json 逐字一致' + (hit ? ' → 「' + hit[0] + '」' : ''));
      if (hit && src.neg) ok(hit[1].neg === src.neg, k + ' 负向词一致');
    }
    for (const [t, v] of Object.entries(found))   // 反向：面板里的词必须能在 index.json 找到出处（不许编造）
      ok(Object.values(want).some(s => s.prompt === v.prompt), '面板「' + t + '」的词有出处（非编造）');
  } catch (e) {
    console.log('异常:', e.message, (e.stack || '').split('\n')[1]); fails++;
  }
  console.log('\n失败项:', fails);
  try { dom.window.close(); } catch (e) {}
  process.exit(fails ? 1 : 0);   // 必须显式退出：页面定时器会让 node 挂住
}, 6000);

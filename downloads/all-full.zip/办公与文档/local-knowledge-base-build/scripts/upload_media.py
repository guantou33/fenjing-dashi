# -*- coding: utf-8 -*-
"""把 ghpages/media/作品库/ 下的作品图上传到远端仓库（deploy_fast.py 会跳过这个目录）。
用法: python upload_media.py [子目录名] [--dry]
"""
import os, sys, json, base64, hashlib, urllib.request, urllib.error

BASE = r"C:\Users\111\Desktop\AI\知识库"
SITE = os.path.join(BASE, "ghpages")
TOKENF = os.path.join(BASE, "token_ready.json")
REPO = "fenjing-dashi"
ROOT = "media/作品库"


def api(path, token, method="GET", body=None):
    url = "https://api.github.com" + path
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(url, data=data, method=method)
    req.add_header("Accept", "application/vnd.github+json")
    req.add_header("Authorization", "Bearer " + token)
    req.add_header("X-GitHub-Api-Version", "2022-11-28")
    if data:
        req.add_header("Content-Type", "application/json")
    try:
        with urllib.request.urlopen(req, timeout=120) as r:
            t = r.read().decode()
            return r.status, (json.loads(t) if t else None)
    except urllib.error.HTTPError as e:
        return e.code, e.read().decode()[:400]
    except Exception as e:
        return 0, str(e)


def blob_sha(data):
    h = hashlib.sha1()
    h.update(b"blob %d\x00" % len(data))
    h.update(data)
    return h.hexdigest()


def main():
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    dry = "--dry" in sys.argv
    sub = args[0] if args else ""
    local = os.path.join(SITE, ROOT, sub) if sub else os.path.join(SITE, ROOT)
    if not os.path.isdir(local):
        print("本地目录不存在:", local); sys.exit(1)

    token = json.load(open(TOKENF, encoding="utf-8"))["access_token"]
    st, me = api("/user", token)
    if st != 200:
        print("取用户失败", st, me); sys.exit(1)
    login = me["login"]
    st, repo = api("/repos/%s/%s" % (login, REPO), token)
    if st != 200:
        print("仓库不存在", st, repo); sys.exit(1)
    branch = repo.get("default_branch", "main")
    st, ref = api("/repos/%s/%s/git/ref/heads/%s" % (login, REPO, branch), token)
    head = ref["object"]["sha"]
    st, commit = api("/repos/%s/%s/git/commits/%s" % (login, REPO, head), token)
    base_tree = commit["tree"]["sha"]
    st, tr = api("/repos/%s/%s/git/trees/%s?recursive=1" % (login, REPO, base_tree), token)
    remote = {}
    if st == 200 and isinstance(tr, dict):
        for e in tr.get("tree", []):
            if e.get("type") == "blob":
                remote[e["path"]] = e["sha"]

    todo = []
    for root, dirs, names in os.walk(local):
        for n in sorted(names):
            p = os.path.join(root, n)
            rel = os.path.relpath(p, SITE).replace("\\", "/")
            data = open(p, "rb").read()
            if remote.get(rel) == blob_sha(data):
                continue
            todo.append((rel, data))
    print("待传 %d 个（远端已有 %d 个文件）" % (len(todo), len(remote)))
    for rel, d in todo:
        print("   %-56s %7.1f KB" % (rel, len(d) / 1024))
    if dry or not todo:
        return

    tree = []
    for rel, data in todo:
        st, bl = api("/repos/%s/%s/git/blobs" % (login, REPO), token, "POST",
                     {"content": base64.b64encode(data).decode(), "encoding": "base64"})
        if st not in (200, 201):
            print("blob 失败", rel, st, bl); sys.exit(3)
        tree.append({"path": rel, "mode": "100644", "type": "blob", "sha": bl["sha"]})
    st, nt = api("/repos/%s/%s/git/trees" % (login, REPO), token, "POST",
                 {"base_tree": base_tree, "tree": tree})
    if st not in (200, 201):
        print("建 tree 失败", st, nt); sys.exit(3)
    st, nc = api("/repos/%s/%s/git/commits" % (login, REPO), token, "POST",
                 {"message": "上传作品图 %d 个（%s）" % (len(tree), sub or ROOT),
                  "tree": nt["sha"], "parents": [head]})
    if st not in (200, 201):
        print("建 commit 失败", st, nc); sys.exit(3)
    st, ur = api("/repos/%s/%s/git/refs/heads/%s" % (login, REPO, branch), token, "PATCH",
                 {"sha": nc["sha"]})
    if st not in (200, 201):
        print("更新分支失败", st, ur); sys.exit(3)
    print("提交完成", nc["sha"][:8])


if __name__ == "__main__":
    main()

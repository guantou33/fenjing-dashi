# -*- coding: utf-8 -*-
"""验证 sync.py 自动同步不会再碰「作品库」影像素材（不动网络，只记录它会传哪些文件）。"""
import importlib.util

spec = importlib.util.spec_from_file_location("syncmod", r"C:\Users\111\Desktop\AI\知识库\sync.py")
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)

puts = []


def fake_api(path, token=None, method="GET", body=None):
    if method == "PUT":
        puts.append(path)
        return 200, {"content": {}}
    return 200, {"tree": []}          # 假装远端什么都没有 → 每个目标都会走上传分支


m.api = fake_api
m.log = lambda *a, **k: None
m.upload_all("faketoken", "guantou33")

bad = [p for p in puts if "作品库" in p]
media = [p for p in puts if p.lower().endswith((".png", ".jpg", ".jpeg", ".webp", ".mp4", ".mov", ".webm"))]
print("会自动同步的文件总数：", len(puts))
print("其中作品库影像：", len(bad), bad[:5])
print("其中任何影像文件：", len(media), media[:5])
print("样例：", puts[:6])
print("结论：", "PASS 影像素材已被挡住" if not bad else "FAIL 仍有作品库文件会外传")

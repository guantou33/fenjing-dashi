# -*- coding: utf-8 -*-
"""晚上收工同步 · 供 Hermes 定时任务调用（每晚 23:30）。

干什么（知识类，用户已授权自动做）：
  ① 项目产物（剧本 / 分镜 / 资产 / 复盘）→ collect2.py → kb_build.py
  ② 技能迭代（Hermes 技能库 + Desktop\\AI\\SKILL 两处）→ 同上
  ③ deploy_fast.py 上线（本地 知识库.html + 站点 index.html 一起出）

**绝不做**（影像素材，必须用户点头）：作品库里的图 / 视频一律不上传，
只在消息里列出「今天新出了哪些」，等用户说「传」再由 agent 单独跑 upload_media.py。
原因（用户 2026-10-17 明确要求）：本地产的图/视频质量不一定到位，
自动上线会把不合格的东西推到公开站点。

有变化才干活、才出声；没变化静默退出（stdout 为空 = 不打扰用户）。
用法：python nightly_sync.py [--dry]
"""
import os
import subprocess
import sys
import time
import datetime

BASE = r"C:\Users\111\Desktop\AI\知识库"
PY = sys.executable                      # 用当前解释器，不依赖 PATH
SKILL_DIRS = [r"C:\Users\111\AppData\Local\hermes\skills",
              r"C:\Users\111\Desktop\AI\SKILL"]
PROJ_DIRS = [r"C:\Users\111\Desktop\AI\projects",
             r"C:\Users\111\Desktop\AI\创作想法",
             r"C:\Users\111\Desktop\AI\知识库\ghpages\media\作品库"]
SKIP = {"node_modules", ".git", "__pycache__", ".venv", "venv", "dist", "build"}
MEDIA_EXT = (".png", ".jpg", ".jpeg", ".webp", ".gif", ".mp4", ".mov", ".webm")

DRY = "--dry" in sys.argv


def today_start():
    n = datetime.datetime.now()
    return time.mktime(n.replace(hour=0, minute=0, second=0, microsecond=0).timetuple())


def changed(root, since, collect_media=False):
    """返回 (是否有改动, 今天新出的影像文件 [(相对路径, 字节)] )。

    collect_media=True 时只收集「作品库」下的图/视频，且**只收集不上传**。
    """
    hit, media = False, []
    for dp, dn, fn in os.walk(root):
        dn[:] = [d for d in dn if d not in SKIP and not d.startswith(".")]
        for f in fn:
            if f.startswith("."):
                continue
            p = os.path.join(dp, f)
            try:
                if os.path.getmtime(p) < since:
                    continue
            except OSError:
                continue
            hit = True
            if collect_media and "作品库" in dp and os.path.splitext(f)[1].lower() in MEDIA_EXT:
                media.append((os.path.relpath(p, root).replace(os.sep, "/"),
                              os.path.getsize(p)))
    return hit, media


def run(script, *args, timeout=1800):
    if DRY:
        print("[dry] 会执行：%s %s" % (script, " ".join(args)))
        return 0, ""
    p = subprocess.run([PY, os.path.join(BASE, script), *args], cwd=BASE,
                       capture_output=True, text=True, encoding="utf-8",
                       errors="replace", timeout=timeout)
    return p.returncode, ((p.stdout or "") + (p.stderr or "")).strip()


def main():
    since = today_start()
    arts, media = changed(PROJ_DIRS[2], since, collect_media=True)
    proj, _ = changed(PROJ_DIRS[0], since)
    idea, _ = changed(PROJ_DIRS[1], since)
    skill = False
    for d in SKILL_DIRS:
        h, _ = changed(d, since)
        skill = skill or h

    os.makedirs(os.path.join(BASE, "logs"), exist_ok=True)
    logp = os.path.join(BASE, "logs", "nightly-%s.log" % datetime.date.today().isoformat())
    log = open(logp, "a", encoding="utf-8")

    def say(line):
        log.write(line + "\n")
        log.flush()
        print(line)

    know = bool(proj or idea or skill)
    say("=== 收工同步 %s ===" % datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
    say("今日变化：项目文档 %s / 灵感 %s / 技能 %s / 作品库新影像 %d 个"
        % (proj, idea, skill, len(media)))

    if not (know or media):
        log.close()
        return 0                     # 静默：什么都不动，用户收不到消息

    # ① 知识类：自动采集 + 上线（用户已授权）
    if know:
        for name in ("collect2.py", "kb_build.py"):
            code, out = run(name)
            say("[%s] 退出码 %s" % (name, code))
            if out:
                say(out[-1200:])
            if code:
                say("同步中断：%s 失败，线上保持原样，下次会重试。" % name)
                log.close()
                return code
        code, out = run("deploy_fast.py", timeout=1800)
        say("[deploy_fast.py] 退出码 %s" % code)
        if out:
            say(out[-1000:])
        if code:
            say("同步失败：上线这一步没成功，本地已是最新，下次会重试。")
            log.close()
            return code
        say("知识类已上线：https://guantou33.github.io/fenjing-dashi/")

    # ② 影像素材：只报告、绝不上传（等用户同意后再由 agent 单独传）
    if media:
        say("")
        say("今天新出的影像 %d 个，**没有上传**（按你的要求，等你点头）：" % len(media))
        for rel, size in media[:20]:
            say("  · %s（%.1f MB）" % (rel, size / 1048576.0))
        if len(media) > 20:
            say("  · …还有 %d 个" % (len(media) - 20))
        say("要上线就说一句「传今天的图」，我只传你点名的那几张。")

    log.close()
    return 0


if __name__ == "__main__":
    sys.exit(main())

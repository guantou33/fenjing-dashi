# -*- coding: utf-8 -*-
"""一轮多文件改稿的落盘脚本母版（拷走改路径与改动点即可用）。

为什么用脚本而不是逐次打补丁：一轮要动 3–5 份文件且互相引用版本号，
逐次改会慢、会漏，而漏掉的那份不会有任何报错。

四条纪律：
  1. 所有锚点都 assert——找不到或命中多于一处就当场炸，整轮不落盘，不留半改状态。
  2. 跨文件的版本号引用在同一趟里一起改。
  3. 收尾同步头条（不带版本后缀的活页），并读回验证 + 与档案比对，不信退出码。
  4. 正文里不出现 ASCII 双引号（用 “” 与 「」），整段用三引号块——否则打断脚本自身字符串。
"""
import pathlib
import shutil

ROOT = pathlib.Path(r"C:\path\to\project")
ARCHIVE = ROOT / "01-script" / "ep01-outline-v12-<本轮特征>.md"   # 档案：带版本后缀，旧版永不删
HEAD = ROOT / "01-script" / "ep01-outline.md"                     # 头条：下游按它取文件


def load(p):
    return p.read_text(encoding="utf-8")


def save(p, t):
    p.write_text(t, encoding="utf-8")


def set_line(text, prefix, newline, tag):
    """头部行：按前缀定位、整行替换。行内容每轮都变，只有前缀稳定。"""
    lines = text.split("\n")
    hit = [i for i, l in enumerate(lines) if l.startswith(prefix)]
    assert len(hit) == 1, "锚点命中 %d 次：%s" % (len(hit), tag)
    lines[hit[0]] = newline
    return "\n".join(lines)


def cut_from(text, anchor, tag):
    """整节重写：截到锚点之前，旧节内容整段丢掉，随后追加新写的整节。"""
    i = text.find(anchor)
    assert i > 0, "锚点缺失：" + tag
    return text[:i]


def ins_after(text, needle, addition, tag):
    """节间插入：定位到锚点行末的换行处插入。"""
    i = text.find(needle)
    assert i > 0, "锚点缺失：" + tag
    j = text.find("\n", i)
    if j < 0:
        j = len(text)
    return text[:j] + addition + text[j:]


# ---- 本轮到改动 ----
t = load(ARCHIVE)
t = set_line(t, "> 版本：", "> 版本：v12 ｜ …", "版本行")
t = set_line(t, "> 依据：", "> 依据：v11 + 你本轮的两条裁决——…", "依据行")

NEW_SECTION = """## 三、…（整节重写）

…新写的整节正文…
"""
t = cut_from(t, "## 三、", "第三节") + NEW_SECTION
save(ARCHIVE, t)

# ---- 其他文件：同趟改版本号与对应节 ----------------------------------------
# vs = load(ROOT / "00-bible" / "visual-style-v1.6.md")
# vs = set_line(vs, "> 版本：", "> 版本：v1.7 ｜ …", "风格版本行")
# vs = cut_from(vs, "## 十一、", "第十一节") + NEW_11
# save(ROOT / "00-bible" / "visual-style-v1.6.md", vs)
# dec = load(ROOT / "00-bible" / "decisions.md").rstrip() + "\n\n## <轮次标题>\n\n…\n"
# save(ROOT / "00-bible" / "decisions.md", dec)

# ---- 收尾：同步头条 + 读回验证 -------------------------------------------
shutil.copyfile(ARCHIVE, HEAD)
assert load(HEAD) == load(ARCHIVE), "头条未同步"
for p in (ARCHIVE, HEAD):
    print(p.name, "|", load(p).split("\n")[0])
print("OK")

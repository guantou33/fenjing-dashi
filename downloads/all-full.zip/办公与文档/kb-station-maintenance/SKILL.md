---
name: kb-station-maintenance
description: Use when 重建/维护「罐头的AI知识库」总站（v2 已于 2026-10-14 删除，仅作重建参考）。
version: 1.0.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [knowledge-base, frontend, deployment, cloudflare-tunnel]
    related_skills: [hermes-messaging-gateway, flclash-proxy, single-file-webapp-delivery]
---

# 罐头知识库总站维护

> **已废弃（2026-10-14）**：`C:\Users\111\Desktop\AI\知识库v2` 已按用户要求永久删除（含 server/site/desktop/发布包、cloudflared 隧道、开机自启项），下文路径全部不存在。本文件仅作重建时的参考骨架保留；用户现在只保留旧的单文件库 `Desktop\AI\知识库\知识库.html`。

## When to Use

用户说「知识库/总站/助理」要改（排版、功能、免密、加东西），或问总站地址、要发新版本时。也适用于排查「手机上还是老样子」「助理打不开」「地址变了」。

## 站点位置与结构

根目录 `C:\Users\111\Desktop\AI\知识库v2`：

- `server/app.py` —— aiohttp 后端，端口 8787，用 hermes-agent 的 venv python 启动；静态文件走 `FileResponse`（实时读盘，改前端**不用重启**）。
- `site/` —— 前端（index.html / app.js / styles.css / sw.js / data / media）。
- `build/station_up.py` —— 常驻启动器：确保代理 → 确保后端 → 起 cloudflared 快速隧道 → 网址写 `站址.txt`，变了就发微信。开机自启由 `build/install_station_task.bat` 注册的计划任务负责。
- `站址.txt` —— 当前公网地址（每次隧道重开都会变）。
- `backup/<时间戳>/` —— 改动前的备份，出问题从这里回滚。

后端与前端的关系：页面从后端同源提供，`/api/chat` 代理到本机 Hermes 的 `http://127.0.0.1:8642/v1/chat/completions`（key 在 `%LOCALAPPDATA%\hermes\.env` 的 `API_SERVER_KEY`）。

## 改前端的正确流程

1. 先备份：把要动的文件复制到 `backup/<YYYYmmdd_HHMMSS>/`。
2. 改 `site/` 下的源文件。
3. **bump 版本串**——这一步不能省，否则用户手机上的 Service Worker 会一直喂旧文件：
   - `site/index.html`：`styles.css?v=N`、`app.js?v=N`（N 递增）
   - `site/sw.js`：`const V = 'kb-v2-N'`，且 `CORE` 数组里的两个文件名也要带同样的 `?v=N`
4. 语法检查：`node --check site/app.js`。
5. 验证公网：`curl -s "$(cat 站址.txt | tr -d '\r\n')/api/auth/status"` 与抓 `?v=N` 是否已上线。
6. 用浏览器实测（进助理页 → 发一条消息 → 看流式与排版），别只看 curl。

## 助理的鉴权开关

`server/app.py` 顶部 `OPEN_MODE`：默认 **免密常开**（打开就能用）。想恢复「微信解锁码」模式，启动前设环境变量 `KB_AI_LOCK=1`。`/api/auth/status` 返回 `{unlocked, open}`，前端据此决定渲染聊天区还是取码框。

改 `server/app.py` 后必须重启后端才生效（kill 8787 上的 python，再 `python app.py`，用 `DETACHED_PROCESS|CREATE_NO_WINDOW` 起）。`station_up.py` 检测到后端掉线也会在 20 秒内自动拉起。

## 前端实现要点（助理页）

- 布局：`.ai-page` 用 `height: calc(100dvh - 106px)` 撑满，配合 `.view:has(.ai-page){padding-bottom:22px}`，让整页不滚动、只有 `.chat-list` 滚动。移动端断点 820px 下改成 `- 90px`。
- 流式：`/api/chat` 的 SSE 事件里，`choices[0].delta.content` 是正文、`.reasoning_content` 是思考过程，带 `tool`/`toolCallId`/`emoji`/`label`/`status` 的 JSON 是工具执行事件（渲染成 `.tool-row`，`status==='completed'` 标完成）。
- 停止生成：`AbortController` + `AI.ctrl.abort()`，捕获 `AbortError` 后写「［已停止］」。
- 历史持久化：`localStorage['kb_ai_msgs']`，`aiSave()` 分级降级写入（60→30→12→4 条）防写满；`aiHistory()` 按 24000 字符预算挑最近消息，别用「固定 N 条」。

## 坑

- **桌面版 exe 是另一个东西**：`desktop/` 是 electron 离线浏览壳（内嵌静态服务器，app.js 不含助理，因为离线没有模型）。它和 `site/` 的前端已分叉，**不要把 `site/app.js` 覆盖过去**。桌面版数据靠 `build/sync_now.py` 同步，缺文件是同步问题不是代码问题。
- 用户手机上若仍是老样子，让他刷新两次：第一次让新 SW 接管，第二次才拿到新页面（导航请求已改成网络优先，但首次仍由旧 SW 响应）。
- 隧道断了公网地址会变；`station_up.py` 会重开并写 `站址.txt`，同时发微信。别自己去起 cloudflared。
- 私密区（顶栏「锁」按钮）走 `site/private/data.enc.json` 的另一套密码，与助理免密无关，不要一起改掉。

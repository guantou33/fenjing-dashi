# -*- coding: utf-8 -*-
"""把单文件网页 + 下载包发布到 GitHub Pages（纯标准库，不需要 git、不需要手输密码）。

用法：
    1) 改下面的 CONFIG（仓库名、要上传的目录）
    2) python github_pages_deploy.py             # 申请设备码并等用户授权
       python github_pages_deploy.py --token XXX # 已有 token 直接发

为什么这样写：
- 上传走 api.github.com Contents API（单文件单请求），绕开本机常超时的 github.com:443 通道
- 覆盖已存在文件必须先 GET 拿 sha，否则 422
- 开 Pages 后必须轮询到 status == built，再用 curl -sI 确认线上 200，才算真的上线
- 轮询可以放后台进程跑：用户一点 Authorize 就自动建仓库/上传/开 Pages
"""
import base64, json, os, sys, time, urllib.error, urllib.request

# ------------------------------ CONFIG ------------------------------
CLIENT_ID = "178c6fc778ccc68e1d6a"   # GitHub CLI 的公开 OAuth app id，设备流用它即可
REPO = "my-site"                      # 仓库名（会建在用户账号下）
DESC = "static site"
SITE_DIR = "ghpages"                  # 要发布的目录；index.html 是站点首页
EXTRA_DIRS = ["downloads"]            # 额外整目录上传（zip 等），文件名须纯 ASCII
STATE_DIR = os.path.dirname(os.path.abspath(__file__))
DEVCODE = os.path.join(STATE_DIR, "devcode.json")
TOKENF = os.path.join(STATE_DIR, "token_ready.json")
RESULT = os.path.join(STATE_DIR, "deploy_result.json")
# --------------------------------------------------------------------


def log(m):
    print(time.strftime("%H:%M:%S ") + str(m), flush=True)


def api(path, token, method="GET", body=None):
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request("https://api.github.com" + path, data=data, method=method)
    req.add_header("Authorization", "token " + token)
    req.add_header("Accept", "application/vnd.github+json")
    req.add_header("User-Agent", "pages-deploy")
    if data:
        req.add_header("Content-Type", "application/json")
    try:
        with urllib.request.urlopen(req, timeout=120) as r:
            b = r.read()
            return r.status, (json.loads(b) if b else {})
    except urllib.error.HTTPError as e:
        b = e.read()
        try:
            return e.code, json.loads(b)
        except Exception:
            return e.code, {"raw": b[:300].decode("utf-8", "replace")}


def request_device_code():
    """申请设备码；user_code 约 15 分钟过期，过期要重新申请再发给用户。"""
    body = ("client_id=%s&scope=repo" % CLIENT_ID).encode()
    for _ in range(5):
        req = urllib.request.Request("https://github.com/login/device/code", data=body)
        req.add_header("Accept", "application/json")
        try:
            with urllib.request.urlopen(req, timeout=20) as r:
                j = json.loads(r.read())
            json.dump(j, open(DEVCODE, "w"))
            log("授权码 %s（%s 秒内有效）→ https://github.com/login/device"
                % (j["user_code"], j.get("expires_in")))
            return j
        except Exception as e:
            log("申请失败，重试: %s" % str(e)[:80])
            time.sleep(6)
    return None


def wait_token(max_min=15):
    dev = json.load(open(DEVCODE, encoding="utf-8"))
    body = ("client_id=%s&device_code=%s"
            "&grant_type=urn:ietf:params:oauth:grant-type:device_code"
            % (CLIENT_ID, dev["device_code"])).encode()
    for i in range(int(max_min * 60 / 6)):
        req = urllib.request.Request("https://github.com/login/oauth/access_token", data=body)
        req.add_header("Accept", "application/json")
        try:
            with urllib.request.urlopen(req, timeout=20) as r:
                j = json.loads(r.read())
        except Exception as e:
            j = {"error": "net", "detail": str(e)[:80]}
        if j.get("access_token"):
            json.dump(j, open(TOKENF, "w"))
            log("拿到 token ✓")
            return j["access_token"]
        if j.get("error") not in ("authorization_pending", "slow_down", "net"):
            log("授权异常: %s（过期就重新申请一条 user_code）" % j)
            return None
        if i % 10 == 0:
            log("  仍在等用户点确认… %s" % j.get("error"))
        time.sleep(6)
    return None


def put_file(token, login, repo_path, local, msg):
    with open(local, "rb") as f:
        content = base64.b64encode(f.read()).decode()
    st, cur = api("/repos/%s/%s/contents/%s" % (login, REPO, repo_path), token)
    body = {"message": msg, "content": content, "branch": "main"}
    if st == 200 and isinstance(cur, dict) and cur.get("sha"):
        body["sha"] = cur["sha"]        # 覆盖必须带 sha
    st, r = api("/repos/%s/%s/contents/%s" % (login, REPO, repo_path), token, "PUT", body)
    ok = st in (200, 201)
    log("  上传 %-34s %s" % (repo_path, "✓" if ok else "✗ %s" % str(r)[:120]))
    return ok


def main():
    token = None
    if "--token" in sys.argv:
        token = sys.argv[sys.argv.index("--token") + 1]
    elif os.path.exists(TOKENF):
        token = json.load(open(TOKENF, encoding="utf-8")).get("access_token")
    if not token:
        if not os.path.exists(DEVCODE):
            request_device_code()
        token = wait_token()
    if not token:
        log("没有 token，退出")
        json.dump({"ok": False, "err": "no_token"}, open(RESULT, "w"))
        return

    st, me = api("/user", token)
    if st != 200:
        log("取用户失败: %s %s" % (st, me));
        return
    login = me["login"]
    log("账号: %s" % login)

    st, r = api("/repos/%s/%s" % (login, REPO), token)
    if st == 404:
        st, r = api("/user/repos", token, "POST",
                    {"name": REPO, "description": DESC, "private": False, "auto_init": True})
        log("建仓库: %s" % st)
    else:
        log("仓库已存在: %s" % r.get("full_name"))

    files = []
    for root, _, names in os.walk(SITE_DIR):
        for n in sorted(names):
            p = os.path.join(root, n)
            files.append((os.path.relpath(p, SITE_DIR).replace("\\", "/"), p))
    for path, local in files:
        put_file(token, login, path, local, "更新 " + path)

    st, r = api("/repos/%s/%s/pages" % (login, REPO), token)
    if st == 404:
        st, r = api("/repos/%s/%s/pages" % (login, REPO), token, "POST",
                    {"source": {"branch": "main", "path": "/"}})
    else:
        st, r = api("/repos/%s/%s/pages" % (login, REPO), token, "PUT",
                    {"source": {"branch": "main", "path": "/"}})
    log("Pages: %s %s" % (st, str(r)[:160]))

    url = "https://%s.github.io/%s/" % (login, REPO)
    built = False
    for _ in range(40):            # 最多等 10 分钟
        time.sleep(15)
        st, r = api("/repos/%s/%s/pages" % (login, REPO), token)
        s = r.get("status") if isinstance(r, dict) else None
        log("  Pages 状态: %s" % s)
        if s == "built":
            built = True
            break

    out = {"ok": True, "login": login, "repo": REPO, "url": url, "built": built}
    json.dump(out, open(RESULT, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    log("完成: %s（built=%s）" % (url, built))
    log("发链接给用户前再 curl -sI %s 确认 200" % url)


if __name__ == "__main__":
    main()

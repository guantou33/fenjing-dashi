---
name: single-file-webapp-delivery
description: Use when 要把自制小工具/网页送到手机独立使用（不依赖电脑常开）。单文件打包→临时托管→交付核验。
---

# 自制小工具交付到手机（单文件网页）

适用：用户要一个能算分/查表/记分/换算的小工具，且**要在手机上自己用**。核心约束是用户
明确提过的：**不要跟这台电脑绑定**——本机起服务、手机同局域网访问、要求电脑常开，
这些方案一律不要提，用户要的是"像小程序或网页一样单独用"。

## When to Use

- 用户要一个自用小工具（算分/换算/查表/记分/清单）并说"发我手机""发我微信""我要在手机上用"。
- 用户说"不想跟电脑绑定""能单独使用""类似小程序或者网页"。
- 手上已经有一个 `.html`，需要交到用户设备上并能反复打开。

不适用：只要看一眼设计稿/原型（用 `claude-design`）；只是要抓取被墙的网页（用 `blocked-page-recovery`）。

## 硬规则

- **交付物必须是单个自包含 `.html`**：CSS/JS 全内联，不引任何外链（CDN、字体、图标）。
  外链会在用户网络被墙或断网时把页面变白屏，也让文件没法存到手机上长期用。
- **不要拿"本机开服务 + 局域网 IP"当交付方案**。它依赖电脑常开，正是用户拒绝的形态。
  本地服务只用于验证，不用于交付。
- **不许承诺离线可用**：单文件托管拿不到 service worker（sw.js 必须是独立文件），
  "添加到主屏幕"之后打开仍然要联网。要真离线只能改成多文件 + HTTPS 托管 + 注册 SW，
  先把代价说清楚让用户选，别含糊说"加个图标就能离线用"。
- **"长期有效/以后更新会同步"是另一类需求**：临时免账号托管只有 72 小时，满足不了。
  走下面「长期托管」一节，不要拿临时链接当长期方案交差。
- **汇报必须给成品/半成品结论**：用户会直接问"这是成品还是半成品"。汇报固定成一张
  百分比清单（本体 / 逻辑验证 / 浏览器验证 / 托管 / 发送逐项），明确写"成品"或"还差哪一步"，
  并单独点名**唯一卡住的动作需要用户做什么**。不要把"还没送到"说成"没做好"。

## 步骤

1. **先写可测的纯逻辑，再套 UI**：算法/换算与 DOM 解耦，才能用 node 单测直接跑
   （无浏览器、秒级迭代）。
2. **node 单测跑逻辑**：每种算法/分支至少一条断言，含边界（输入不足、封顶、全零）。
   全绿再进浏览器。
3. **浏览器端到端验证**：本地起静态服务（`python -m http.server <port>`），
   用浏览器工具打开 `http://127.0.0.1:<port>/x.html` 走一遍真实交互（点选、联动、结算）。
   **页面完全自包含（无 fetch/外链）时 `file://` 也够用**，实测在 `file://` 下单文件页的 DOM/交互/localStorage
   都正常；只要页面还要 `fetch` 别的文件，就必须起 `http.server`，否则脚本环境拿不到数据。
   只在关键节点看页面状态/截图，别每一步都截。
   **每次浏览器调用都重新导航**：`goto_url(URL)` → `wait_for_load()` → 等 3~4 秒再断言；
   沿用上一次调用的页面会拿到刚重置或未渲染完的状态（列表元素数为 0），把没坏的功能误判成坏了。
   **页面脚本常包在 IIFE 里，函数不是全局的**：只能在页面里注入 `() => {...}` 表达式，
   函数定义写在同一段注入代码内；直接调用页面函数名会拿不到。
   收尾时清掉测试写进 `localStorage` 的残留（收藏/已读标记等），**且要清在页面初始化之前或清完再重载**——
   页面启动时已把旧值读进内存，运行中清掉后任何一次写入都会把它写回去。
4. **打包成单文件**：把 CSS/JS 内联回一个 `.html`；项目目录留一份，桌面再放一份副本
   供用户双击使用。
5. **传临时公网托管拿链接**（已验证可用的一条）：
   `curl -s -F "reqtype=fileupload" -F "time=72h" -F "fileToUpload=@x.html" https://litterbox.catbox.moe/resources/internals/api.php`
   返回 `https://litter.catbox.moe/xxxx.html`，`Content-Type: text/html`，手机浏览器
   **直接渲染**而不是弹下载——这正是选它的原因。有效期最长 72 小时。
6. **交付前必须核验两件事**（不能只看返回的链接就发）：
   - `curl -sI <链接>`：确认 `HTTP 200` 且 `Content-Type: text/html`；
   - **把链接内容下载回本地，比对字节数与本地文件是否一致**。
     有托管会静默截断：上传 6 万字节、取回只剩 3 千字节，而链接本身仍返回 200。
7. **两条路一起给用户**：
   - **链接**：手机浏览器/微信打开即用，体验最好；微信内置浏览器能直接渲染网页。
   - **文件**：让用户存进手机"文件"App，作为链接过期后的长期副本。
8. **收尾提示**：苹果手机上用 Safari 打开链接 → 分享 → "添加到主屏幕"，图标就像小程序；
   但要同时说清它仍需联网（见硬规则）。

## 坑

- **网页端写入的文件是远端权威，本机同步必须绕开它**：静态站让用户在浏览器里自助上传时，
  清单类文件（作品表/改名表）由页面的 git data API 直接改，**远端那份才是真的**，
  本机目录里那份只是旧副本（往往是空壳）。本机若有一个"整站 `os.walk` 全传"的同步脚本，
  就会把空壳推上去，一次盖掉用户所有上传记录——现象是"传了两遍、线上还是没有"。
  规则：这些路径进同步脚本的 `SKIP_REL` 名单（多条同步脚本时必须对齐同一份名单）；修完把本机那份
  写成与远端相同的内容，否则下次同步再清空。找回：`GET /repos/<o>/<r>/commits?path=<清单路径>`
  找上一次好版本，`contents/<path>?ref=<sha>` 取正文重建，并把新文件一起补进清单。
- **404 先怀疑自己拼的 URL，不是 token**：仓库标识本身已含 `owner/name` 时又拼一次 login，
  请求就变成 `/repos/owner/owner/name/...` → 返回 `Not Found`，跟权限不足的 404 长得一样。
  同一路径在一次性脚本里能通、进函数就 404，就打印实际请求 URL 逐段比对，别去折腾 token。
- **沙箱浏览器不跑媒体管线，别拿它判素材好坏**：`<video>` 挂上去 15 秒仍 `readyState=0`、
  `networkState=2` 是**假象**——已知能播的公共 mp4 在同一个浏览器里也一样。判素材用证据：
  查容器里 `moov` 的位置（排在 `mdat` 之后就是流式播放的坑）、`Range: bytes=0-32767` 量头部响应耗时、
  `HEAD` 看 `content-type`/`content-length`；能不能真的播出来由用户真机确认。
- **`curl -w '%{size_download}'` 会骗人**：200 响应却报 0 字节。核验完整性一律用
  "下载到本地文件 + 比对字节数"，不要信这个统计值。
- **免账号托管是易耗品**：站点关停、禁上传、域名失效都是常态。上传失败或链接打不开时
  换下一家并重跑第 6 步核验；**不要因为某家今天不行就写死"某某站不可用"**。
- **一次性链接不是存档**：先按第 7 步把文件也交到用户手上，链接只负责"现在就能用"。
- 正文含中文/表情时，先 `write_file` 落盘再上传，避开 shell 引号与编码问题。
- **文件名必须纯 ASCII 再上传**：`-F "file=@知识库.html"` 会让 multipart 头编码出错，
  服务端回 `400 No file supplied`（本地文件明明在）。先 `cp` 成 `kb.html` 再传。
- **`litterbox` 会偶发 `500 Internal Server Error`**：同一文件同一命令重试即成功，
  **不要据此判定体积超限**。实测 2.7MB 的 html 能传上去。
- **实测可用性（本机网络，随时会变）**：`litterbox.catbox.moe` 可用（首选）；
  `uguu.se` 直接拒收 `.html`（`415 Filetype not allowed`）；`temp.sh` 收文件但返回的链接
  是它自己的壳页（Content-Length 与本地差得离谱），**不能当直链**；
  `catbox.moe` / `tmpfiles.org` / `pixeldrain` / `gofile` 从本机连不上（`Connection was reset`）；
  `0x0.st` 已停用上传；`x0.at` 封本机 IP。
- **本机下载大文件常被中途掐断**（`curl: (56) schannel: server closed abruptly`），
  每次取回字节数还不一样——这是本机链路问题，**不是托管截断**。判定完整性用：
  `curl -r 0-1999` 和 `curl -r $((LEN-2000))-$((LEN-1))` 取头尾各 2000 字节与本地 `cmp`，
  再对照 `curl -sI` 的 `Content-Length` 是否等于本地字节数；三者都对就是完整。
- **后台标签页会冻结 CSS 过渡与 `setTimeout`**：在浏览器工具里读 `transform`、等防抖搜索
  会拿到**假阴性**（表现为"点了没反应"）。判定方法：先 `style.transition='none'` 再切 class
  读几何值；或直接调页面函数。
- **别在页面里跑 `var DATA=...` 这类测试表达式**：会覆盖页面全局变量，之后所有依赖它的
  功能（搜索）都报错，看起来像产品 bug。测试取数一律写 `Array.isArray(DATA)` 这类只读表达式。

## 长期托管（永久链接 + 自动同步）

用户说"长期有效""以后更新会同步""别 72 小时就失效"时，第 5 步的临时托管不达标，
必须换带账号的静态托管。本机可行的一条是 GitHub Pages，全程不需要 git：

1. **申请设备码**（不碰密码，用户在自己设备上点确认）：
   `curl -sS -X POST https://github.com/login/device/code -H "Accept: application/json" -d "client_id=178c6fc778ccc68e1d6a&scope=repo"`
   → 返回 `device_code` / `user_code` / `expires_in`（约 900 秒）。
   把 `user_code` 和 `https://github.com/login/device` 发给用户。
   **`user_code` 约 15 分钟就过期**：过期就重新申请一条再发，不要让用户对着失效的码反复试。
2. **轮询换 token**：POST `https://github.com/login/oauth/access_token`，body 带 `device_code`
   + `grant_type=urn:ietf:params:oauth:grant-type:device_code`。
   返回 `authorization_pending` = 用户还没点，继续等；拿到 `access_token` 才算成功。
   **把轮询放进后台进程**（`background=true`），用户一点确认就自动接着建仓库、上传、开 Pages，
   不用等他回来喊一声。
3. **建仓库 + 上传走 `api.github.com` Contents API，不要用 `git push`**：
   `PUT /repos/{login}/{repo}/contents/{path}`，body `{message, content: <base64>, branch: "main"}`；
   **覆盖已存在的文件必须先 `GET` 同路径取 `sha` 再带上**，否则 422。
   单文件单请求，正好绕开 github.com 那条本机常超时/被重置的通道。
4. **开 Pages**：`POST /repos/{login}/{repo}/pages`，body `{"source":{"branch":"main","path":"/"}}`；
   已存在则改用 `PUT`。免费账号的 Pages 要求**仓库 public**——公开前先确认内容能不能公开：
   个人剧本、聊天记录、破甲/越狱笔记这类先问用户，或只上技能那部分。
5. **回读验证后才算完成**：轮询 `GET /repos/{login}/{repo}/pages` 到 `status == "built"`，
   再 `curl -sI https://{login}.github.io/{repo}/` 确认 200，然后才把链接发给用户。
   没读到 `built` 之前不要说"已上线"。
6. **更新 = 重跑同一个脚本**：Contents API 覆盖同名文件即可同步，不需要 git 历史、不需要用户再授权。

- **多文件站点直接上 Pages，别再考虑单文件托管**：知识库这类产物是
  `index.html + downloads/*.zip + 媒体目录`，litterbox 之类只能塞单个 html。
  页面自带的下载按钮用 JS 现场打包（store 模式 zip）即可，
  **只有"永久直链"才需要把 zip 预上传到 `downloads/`**。

可直接复用的脚本：`scripts/github_pages_deploy.py`（纯标准库，参数在文件顶部）。

- **用户说"你直接自己操作帮我登录就行"也要停手**：agent 不代输账号密码。能做的是把 `user_code`
  发到他微信、把登录页在浏览器里打开，他点完确认后剩下的全自动——把这句话讲清楚，别让他以为
  你在推诿。
- **上传到托管上的文件名必须纯 ASCII**：`downloads/pack-fenjing-dashi.zip` 这种，
  中文名在 URL 里会被编码成一长串乱码。页面里用一张 JS 映射表把中文分类名 → ASCII 键。
- **先确认 api.github.com 通不通**：`curl -sS -o /dev/null -w '%{http_code}' https://api.github.com`。
  本机对 `api.github.com` 正常、对 `github.com` 常超时；两边都不通时开 FlClash 代理
  （见 `flclash-proxy`），用完关掉。

## 相关技能

- 发到微信/QQ、以及 iLink 会话过期（`ret=-2`，需用户先发一条消息）的处置：
  `hermes-messaging-gateway`。

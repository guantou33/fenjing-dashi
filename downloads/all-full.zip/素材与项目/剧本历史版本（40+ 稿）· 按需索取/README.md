# 剧本历史版本（40+ 稿）· 按需索取

青苹果项目全部中间稿都在本机：creative-brief v1.0–v1.13、visual-style v1.1–v1.9、ep01-outline v1–v15、ep01-历史v2 等，共 792KB。要哪一版跟我说。

（该条目正文未内嵌，需要时向 Hermes 索取）

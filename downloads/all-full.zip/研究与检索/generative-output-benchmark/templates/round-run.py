# -*- coding: utf-8 -*-
"""多模型迭代 —— 端到端跑一轮：出词 -> 出片 -> 评测 -> 合辑 -> 报告。

用法: python round_run.py <轮次数字>

复制到工作目录后，按你的环境改【本机配置】段。设计要点：
  1) 每个参赛模型读「它自己上一轮的词 + 上一轮成片的客观诊断」重写，而不是重新自由发挥；
  2) 出词、出片严格串行；出片前主动卸载本地 LLM 释放显存；
  3) 一轮的产物：第N轮词/ + 成片 + 指标 json + 合辑 mp4 + 报告 md。
"""
import json
import os
import re
import subprocess
import sys
import time
import urllib.request

# ─── 本机配置（按环境改）────────────────────────────
ROOT = r"<工程目录>"                       # 各轮产物都放这里
SCRATCH = os.path.dirname(os.path.abspath(__file__))
COMFY = "http://127.0.0.1:8188"
OLLAMA_URL = "http://localhost:11434/v1/chat/completions"
CLOUD_URL = "<云端 base_url>/chat/completions"
CLOUD_MODEL = "<云端模型名>"
CLOUD_KEY_ENV = "<.env 里存放 key 的变量名>"
ENV_FILE = r"<hermes .env 路径>"
PY = r"<生成器所在 python>"
H3_GEN = os.path.join(SCRATCH, "h3_gen.py")        # 提交出片并拷回成片
REVIEW = os.path.join(SCRATCH, "review_any.py")    # 评测器: <jobs.json> <out.json>
# ─────────────────────────────────────────────────

# 参赛模型：A 官方节点 / B/C/D 本地 ollama / E 云端
MODELS = [
    ("A", "官方节点", "official", None),
    ("B", "本地-9B", "ollama", "<ollama 模型 tag>"),
    ("C", "本地-12B", "ollama", "<ollama 模型 tag>"),
    ("D", "本地-14B", "ollama", "<ollama 模型 tag>"),
    ("E", "云端", "cloud", CLOUD_MODEL),
]

# 统一水平线剧本（第 4/5 轮范式）：一份剧本喂给所有模型，只比描写能力
SRC = "<统一剧本：时长/视角/人物/环境/唯一光源>"

# 六维拷问模板：把用户关心的维度直接写成写作要求
BRIEF = """你在为视频生成模型写一份中文提示词。

【固定设定】{src}

【上一版成片实测到的问题，这一版必须修正】
{diag}

【必须逐条落实，缺一不可】
一、面部统一：从第一帧起始终正对镜头、头部转动不超过 5 度、绝不侧脸背对；五官比例全程不变。
二、说话语气：写出 4 句各不相同的中文台词，格式 <d>(S1) 台词</d>，语气要有层次，绝不重复。
三、情绪控制：写明情绪递进路径，以及每种情绪在脸上如何体现。
四、微表情：写明眨眼频率、嘴角弧度、呼吸起伏、眼神焦点、下颌开合。
五、动作自然：只允许缓慢小幅动作；禁止跳切/硬切/旋转/瞬移。
六、画面美感：写明光比、色温、景深、质感与构图；光量与色温全程恒定、结尾不得变暗。

【格式硬要求】全文中文；[Shot 1]–[Shot 4] 共 4 段；只输出提示词正文。"""


def log(*a):
    print(*a, flush=True)


def http_json(url, payload, headers=None, timeout=1200):
    req = urllib.request.Request(url, data=json.dumps(payload).encode("utf-8"),
                                 headers={"Content-Type": "application/json", **(headers or {})})
    return json.loads(urllib.request.urlopen(req, timeout=timeout).read().decode("utf-8"))


def cloud_key():
    env = open(ENV_FILE, encoding="utf-8", errors="replace").read()
    m = re.search(r"^" + CLOUD_KEY_ENV + r"\s*=\s*[\"']?([^\"'\r\n]+)", env, re.M)
    return m.group(1).strip() if m else ""


def unload_ollama():
    """出片前把本地模型从显存卸载，给出片腾地方。"""
    for _, _, kind, mid in MODELS:
        if kind == "ollama":
            try:
                http_json("http://localhost:11434/api/generate", {"model": mid, "keep_alive": 0}, timeout=60)
            except Exception:
                pass


def ask_ollama(model, sysmsg, usermsg):
    r = http_json(OLLAMA_URL, {"model": model, "messages": [
        {"role": "system", "content": sysmsg}, {"role": "user", "content": usermsg}],
        "temperature": 0.75, "top_p": 0.9, "max_tokens": 2200, "think": False, "keep_alive": "2m"})
    return r["choices"][0]["message"]["content"].strip()


def ask_cloud(sysmsg, usermsg):
    r = http_json(CLOUD_URL, {"model": CLOUD_MODEL, "messages": [
        {"role": "system", "content": sysmsg}, {"role": "user", "content": usermsg}],
        "temperature": 0.75, "top_p": 0.9, "max_tokens": 2200},
        {"Authorization": "Bearer " + cloud_key()})
    return r["choices"][0]["message"]["content"].strip()


def clamp(x, lo=0.0, hi=10.0):
    return max(lo, min(hi, x))


def diag_of(m):
    """上一轮指标 -> 中文问题清单（回炉输入）。"""
    if not m:
        return "（这是第一版，暂无上一轮数据，直接按六个维度写出最好的一版。）"
    d = []
    fs = m.get("face_sim", {})
    d.append("① 人脸一致性：均值 %.3f、最低 %.3f。" % (fs.get("mean", 0), fs.get("min", 0))
             + ("最低过低＝有崩脸帧，需强化「五官比例全程不变」。" if fs.get("min", 1) < 0.7 else "保持，并写明五官恒定。"))
    ar = m.get("audio", {}).get("active_ratio", 0)
    d.append("② 人声活跃度 %.2f。" % ar + ("几乎没出声，台词必须写足 4 句各不相同。" if ar < 0.5 else "保持，台词仍需 4 句不重复。"))
    if m.get("cuts", 0) or m.get("hist_change_max", 0) > 0.35 or m.get("motion_max", 0) > 20:
        d.append("③ 出现跳切 %d 次、画面突变 %.3f、运动峰值 %.2f，违反「只允许缓慢小幅动作」。"
                 % (m.get("cuts", 0), m.get("hist_change_max", 0), m.get("motion_max", 0)))
    else:
        d.append("③ 无跳切，运动平稳（均值 %.2f），保持。" % m.get("motion_mean", 0))
    d.append("④ 亮度极差 %.1f" % m.get("lum_range", 0)
             + ("，存在忽明忽暗，必须写明唯一光源恒定、结尾不变暗。" if m.get("lum_range", 0) > 25 else "，光照稳定，保持。"))
    return "\n".join(d)


def word_stats(t):
    lines = re.findall(r"<d>\s*\(?S\d\)?\s*([^<]+?)\s*</d>", t)
    return {"n_line": len(lines), "n_uniq": len(set(x.strip() for x in lines)),
            "cjk": len(re.findall(r"[\u4e00-\u9fff]", t)),
            "shots": len(re.findall(r"\[Shot\s*\d+\]", t)),
            "emo": len(re.findall(r"情绪|神情|表情", t)),
            "micro": len(re.findall(r"眨眼|嘴角|呼吸|眼神|下颌", t))}


def score6(m, ws):
    fs, au, ff = m.get("face_sim", {}), m.get("audio", {}), m.get("face_f2f", {})
    s = {}
    s["面部统一"] = clamp(fs.get("mean", 0) * 5 + fs.get("min", 0) * 5)
    s["说话语气"] = clamp(au.get("active_ratio", 0) * 5 + min(ws["n_uniq"], 4) / 4 * 3 + min(au.get("env_std", 0) * 8, 2))
    s["动作自然"] = clamp(10 - abs(m.get("motion_mean", 0) - 3.2) * 2.2 - m.get("cuts", 0) * 2.5
                          - max(0, m.get("motion_max", 0) - 12) * 0.15 - m.get("hist_change_max", 0) * 8)
    s["微表情"] = clamp(ff.get("mean", 0) * 6 + min(ws["micro"], 6) / 6 * 3 + min(m.get("motion_std", 0), 1.6) / 1.6)
    s["情绪控制"] = clamp(min(ws["emo"], 8) / 8 * 4 + min(m.get("motion_std", 0), 1.6) / 1.6 * 2 + ff.get("mean", 0) * 4)
    s["画面美感"] = clamp(10 - abs(m.get("sat_mean", 0) - 118) * 0.25 - m.get("lum_range", 0) * 0.12
                          - max(0, m.get("hist_change_mean", 0) - 0.01) * 100)
    s["_总分"] = round(sum(s.values()) / 6, 2)
    return {k: round(v, 2) for k, v in s.items()}


def main(n):
    wdir, vdir = os.path.join(ROOT, "第%d轮提示词" % n), os.path.join(ROOT, "ITER_第%d轮" % n)
    edir = os.path.join(ROOT, "_评测")
    for d in (wdir, vdir, edir):
        os.makedirs(d, exist_ok=True)

    # 上一轮的指标与词（迭代输入）
    pm, pw = {}, {}
    mp = os.path.join(edir, "metrics_r%d.json" % (n - 1))
    if os.path.exists(mp):
        pm = {x["label"].split("_")[-1]: x for x in json.load(open(mp, encoding="utf-8"))}
    for tag, *_ in MODELS:
        p = os.path.join(ROOT, "第%d轮提示词" % (n - 1), "%s_r%d.txt" % (tag, n - 1))
        if os.path.exists(p):
            pw[tag] = open(p, encoding="utf-8").read().strip()
    log("第 %d 轮开始 | 上一轮指标 %d 条 | 上一轮词 %d 份" % (n, len(pm), len(pw)))

    # 1) 出词
    words = {}
    for tag, name, kind, mid in MODELS:
        body = BRIEF.format(src=SRC, diag=diag_of(pm.get(tag)))
        user = ("【你上一版写的提示词如下】\n" + pw[tag] +
                "\n\n请针对上面列出的问题重写一版明显更好的提示词，不要照抄。只输出提示词正文。") if pw.get(tag) \
            else "请直接写出提示词正文。"
        log("── 出词 %s (%s) …" % (tag, name))
        try:
            if kind == "official":
                txt = ask_official(body, user)          # 见 SKILL.md：官方优化器节点
            elif kind == "ollama":
                txt = ask_ollama(mid, body, user)
            else:
                txt = ask_cloud(body, user)
        except Exception as e:
            log("   x %s 出词失败: %s" % (tag, e))
            txt = pw.get(tag, SRC)
        txt = txt.strip()
        open(os.path.join(wdir, "%s_r%d.txt" % (tag, n)), "w", encoding="utf-8").write(txt)
        words[tag] = txt
        st = word_stats(txt)
        log("   ok 汉字 %d / Shot %d / 台词 %d 句(去重 %d)" % (st["cjk"], st["shots"], st["n_line"], st["n_uniq"]))

    # 2) 出片（串行；先卸载本地 LLM）
    unload_ollama()
    env = {**os.environ, "H3_DEST": vdir}
    for tag, _, _, _ in MODELS:
        label = "R%d_%s" % (n, tag)
        log("── 出片 %s" % label)
        subprocess.run([PY, H3_GEN, label, os.path.join(wdir, "%s_r%d.txt" % (tag, n)), "42"],
                       capture_output=True, text=True, encoding="utf-8", errors="replace", env=env, timeout=3600)

    # 3) 评测
    jobs = [{"label": "R%d_%s" % (n, tag), "name": "第%d轮 %s" % (n, name),
             "path": os.path.join(vdir, "ITER_R%d_%s_00001_.mp4" % (n, tag))} for tag, name, _, _ in MODELS]
    jf, mf = os.path.join(SCRATCH, "jobs_r%d.json" % n), os.path.join(edir, "metrics_r%d.json" % n)
    json.dump(jobs, open(jf, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    r = subprocess.run([PY, REVIEW, jf, mf], capture_output=True, text=True,
                       encoding="utf-8", errors="replace", timeout=3600)
    log(r.stdout or r.stderr)

    # 4) 合辑（每轮必须给用户一条看完全部）
    reel_dir = os.path.join(SCRATCH, "cmp%d" % n)
    os.makedirs(reel_dir, exist_ok=True)
    reel, lst = os.path.join(reel_dir, "R%d_all5.mp4" % n), os.path.join(reel_dir, "list.txt")
    with open(lst, "w", encoding="utf-8") as f:
        for j in jobs:
            f.write("file '%s'\n" % j["path"].replace("\\", "/"))
    subprocess.run(["ffmpeg", "-y", "-f", "concat", "-safe", "0", "-i", lst, "-c", "copy", reel],
                   capture_output=True, timeout=900)

    # 5) 报告（评分表 + 名次 + 原始指标 + 词面特征 + 成片路径）
    met = {x["label"].split("_")[-1]: x for x in json.load(open(mf, encoding="utf-8"))} if os.path.exists(mf) else {}
    lines = ["# 第 %d 轮迭代报告" % n, "", "## 一、六维评分", "",
             "| 模型 | 面部统一 | 说话语气 | 情绪控制 | 微表情 | 动作自然 | 画面美感 | 总分 |",
             "|---|---|---|---|---|---|---|---|"]
    rows = []
    for tag, name, _, _ in MODELS:
        m = met.get(tag)
        if not m:
            continue
        s = score6(m, word_stats(words.get(tag, "")))
        rows.append((s["_总分"], tag, name))
        lines.append("| %s %s | %.2f | %.2f | %.2f | %.2f | %.2f | %.2f | **%.2f** |" % (
            tag, name, s["面部统一"], s["说话语气"], s["情绪控制"], s["微表情"],
            s["动作自然"], s["画面美感"], s["_总分"]))
    rows.sort(reverse=True)
    lines += ["", "## 二、名次", ""] + ["%d. **%s** %s（%.2f）" % (i, t, nm, tot) for i, (tot, t, nm) in enumerate(rows, 1)]
    lines += ["", "## 三、成片", ""] + ["- %s" % j["path"] for j in jobs]
    rp = os.path.join(ROOT, "0%d_第%d轮报告.md" % (n, n))
    open(rp, "w", encoding="utf-8").write("\n".join(lines))
    log("第 %d 轮完成 | 报告 %s | 合辑 %s" % (n, rp, reel))


if __name__ == "__main__":
    main(int(sys.argv[1]))

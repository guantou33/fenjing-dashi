# 本地 ollama 模型

视觉/压缩/标题走 qwen3vl8b-q6（Qwen3-VL-8B abliterated）：:latest 是 8k…

（该条目正文未内嵌，需要时向 Hermes 索取）

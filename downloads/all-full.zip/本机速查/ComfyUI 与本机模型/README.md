# ComfyUI 与本机模型

Flux 四模型已下载（flux1-dev-fp8 等），PuLID-FLUX 已装（models/pulid/puli…

（该条目正文未内嵌，需要时向 Hermes 索取）

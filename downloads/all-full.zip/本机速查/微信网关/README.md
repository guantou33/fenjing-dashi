# 微信网关

微信已接入 Hermes gateway（iLink Bot）。启动：$HERMES_HOME/hermes-agent…

（该条目正文未内嵌，需要时向 Hermes 索取）

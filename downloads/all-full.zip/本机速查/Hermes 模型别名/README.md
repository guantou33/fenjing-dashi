# Hermes 模型别名

model.aliases：kid（deepseek-v4.1-flash-hc 主模型）、vl（qwen3vl8b-q…

（该条目正文未内嵌，需要时向 Hermes 索取）

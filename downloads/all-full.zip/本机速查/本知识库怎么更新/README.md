# 本知识库怎么更新

这个页面由 C:\Users\111\Desktop\AI\知识库\kb_collect.py 采集、kb_build.…

（该条目正文未内嵌，需要时向 Hermes 索取）

# 会话检索

问「你刚刚/上次做了什么」时用 hermes-session-history 技能的方法查 state.db；不要凭空回…

（该条目正文未内嵌，需要时向 Hermes 索取）

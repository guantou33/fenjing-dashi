# Hermes 安装与配置路径

配置与数据都在 C:\Users\111\AppData\Local\hermes：config.yaml 是配置、st…

（该条目正文未内嵌，需要时向 Hermes 索取）

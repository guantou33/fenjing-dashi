---
name: emotion-shorts-h3
description: 当要生成单条单镜情绪短片（15 秒长镜头、无对白、固定机位、单人）时翻它。H3 分段生成参数、全局硬边界句、六条情绪 beat 模板、核验口径与踩坑。
---

[定位]
    本卡是 emotion-performance 的实战落地篇：把「情绪时间线 + AU 校准」变成一条真能生成出来的 15 秒单镜情绪片。
    适用：情绪练习组、情绪素材片，或正片里需要一个 15 秒单镜情绪特写（无对白、机位锁死、画内只有一个人）。
    不适用：多镜叙事场（走 shot-design / motion-compile）、有对白的重场戏（走 performance 的任务阶梯 + sound-writing）、多人群像。

[硬参数（实测跑通，别自己改）]
    画幅/帧率：864x480 @ 24fps，参考图 864，16:9。
    时间轴：338 帧 = 124 + 107 + 107 —— 三段长度全部落在 MiniMax 17k+5 网格上，别自己乱切。
    导出：每道接缝多导 12 帧（keep tail）→ 成品 362 帧 = 15.083s。
    采样：steps 25 / res_multistep / simple / cfg 1.0 / shift_video 12.0 / shift_audio 3.0。
    段间引导：continuityEnabled = true，continuityOverlapFrames = 22（上一段末尾 22 帧做运动上下文）。
    参考图：只挂 1 张人物正面图（woman_front.png）—— 多挂一张（男人/房间图）就是「凭空多人」的根因。
    时长上限：单段直接采样 362 帧会在第 22 步 Fatal Python error: Aborted（16G 卡扛不住），15 秒必须走三段；单段安全上限约 12.7s。
    跑前：停掉 ollama 等占显存的服务；单条约 25 分钟；已存在成品（>100KB）直接跳过，别重复烧卡。

[全局层三条硬边界句（可直接复用，一条都别省）]
    1) one person only —— 长句逐项否掉：no other person / no second woman / no second copy or duplicate / no blurred figure in the background / no face, head, shoulder, arm, hand, leg or shadow of any other person / no reflection or photo of any other person / nothing and no one enters or leaves the frame。背景也要点名只留什么（one plain dark apartment wall + 左后方暖色落地灯晕）。
    2) 机位锁死 —— locked off and completely static on one fixed framing / no cut anywhere / no second angle / no wider view / no push-in / no zoom / no reframing / no camera shake / the background never changes。
    3) 幅度夹钳 + 无对白 —— no dialogue, her lips never form words, no sound comes out of her mouth / no shouting / no sudden head turn / no exaggerated expression / no tears streaming。夹钳属技术性设定（约束表演幅度，不是清画面杂质），贴着它压的动作内联即可，不占第 7 段负向名额。
    三段正文分工：第 1 段写「首帧即特写」头部（单人、坐姿、头肩全程不挪位、手在画外）；第 2、3 段开头必须加续接句 The take continues without any cut: she is still in exactly the same place, in the same framing, in the same moment as before, and the action picks up from exactly where it left off. —— 缺这句，模型把该段当成新镜头，接缝必跳。

[六条 beat 模板（本组六条实测全过，可直接套）]
    统一四拍骨架（对应 124/107/107 帧，≈3s 一拍）：
        拍1 基线 0–3s：脸平静、唇闭、下颌松、呼吸慢而匀、自然眨眼 2 次 —— 这一拍不演，只立常态。
        拍2 外部触发 3–5.2s：一个具体声源 + 第一反应（眼先动、头不转）。
        拍3 主动作 5.2–10.1s：三个可见动作 + 生理件（喉/鼻/肩/呼吸）。
        拍4 落幅 10.1–15.1s：明确收（长呼气 + 肩落 + 视线抬回 + 面部归静），或僵住不回收。

    悲伤_隐忍落泪：触发=画外椅脚刮地 + 脚步远去；动作=喉头一次可见吞咽 / 视线滑落到左下 / 眨眼变慢；落幅=眼眶积湿、单滴泪滑下（不接第二滴）、下唇颤一次、末了一记长呼气。
    喜悦_笑意到眼睛：触发=画外熟人一句轻话；动作=嘴角先起、笑意随后才到眼（下眼睑抬、外眼角起细纹）/ 颊抬眼湿 / 耸肩闷笑一次；落幅=笑破一次再收成温笑，眼底仍亮而微湿。
    愤怒_压抑不发：触发=画外一句把她噎住；动作=视线钉死不动 / 眉下压内聚成一条低线 / 咬肌皮下跳一下 / 鼻翼随一次深吸张开；落幅=下巴抬一分要说话又咽回去、一记短促鼻息、眼神仍冷、不松口。
    惊讶_不敢置信：触发=画外一句短话落地；动作=眉直上抬 + 眼圆睁（虹膜四周见白）/ 下巴抬、头微后仰 / 唇分开成小口不出声；落幅=眉回落后在眉心拧出竖纹、轻摇头一次、唇再动一次仍不出声。
    心动_羞赧：触发=对视多停了半拍；动作=视线掉向左下同时嘴角不听使唤上翘 / 隔睫毛飞快瞟回再躲开 / 颊抬泛红；落幅=红不退、偷看一次再垂下、下巴微收、把笑压住。
    恐惧_屏息：触发=右后方门把手转动 + 门闩咔哒（唯一一条 gaze_left=False）；动作=瞳孔收紧 / 眼珠向右缘急扫（头不转）/ 肩向耳根抬起；生理停顿=喉底与胸口停止起伏、吞咽一次、鼻翼保持张开；落幅=僵住不回收 —— 恐惧全程不释放、不恢复，画面结束时她仍在短促小口屏息。

[微表情写法五条硬规则（本组验证出来的）]
    1. 触发必须是具体声源：门把手 + 门闩、椅脚刮地、脚步远去、画外一句听不清的话。「她突然害怕」= 表情凭空出现，必假。
    2. 一镜只给三个可见动作，且每个都写得出物理通道（瞳孔、眼珠、肩、喉、下颌、呼吸、眼睑、颊）。第四个动作只会稀释信号。
    3. 生理停顿写成可见件：喉底/胸口停止起伏、一次可见吞咽、鼻翼保持张开、一次不均匀呼气。停顿不是「不动」，是「呼吸停住但眼球在动」。
    4. 结尾二选一，写死：明确落幅，或僵住不回收（恐惧_屏息 走这条）。禁「渐渐平复」这类含糊收尾。
    5. 升级靠便宜件：下巴、眼睑、喉头、呼吸、肩线、手。不靠脸部大变形 —— 大变形 = 崩脸风险。
    台词：本组全程无对白，soundscape 只写环境声 + 她的呼吸/吞咽。要台词的情绪片走 performance 的 ACTING TASK + sound-writing。

[成片核验口径]
    规格：362 帧 / 15.083s / 24fps / 音轨 32kHz 立体声与画面齐平。
    五步取证法（逐帧差分排名、接缝倍数、冻结检测、内容单调性、目视窗口）见 continuity 的 references/longtake-seam-verify.md，本卡不重写。
    本组实测验收基线：逐帧差分峰值全部落在有意动作拍上（最大 1.34–1.55，出现在触发拍或主动作拍）；12 道接缝单步差分 0.56–1.12 = 中位的 2–3 倍、排名 5–49/361，全部小于本片自然动作峰值；无连续 ≥4 帧冻结段；接缝锚帧距离单调递增。
    核验脚本可复用：作品目录下 核验_情绪15s_终版.py（对 成片/情绪15s/*.mp4 逐条出报告，写 检查/情绪15s/核验报告_终版.txt）。

[踩坑]
    - 单段 362 帧直接采样 → 第 22 步 OOM 崩掉。必须 124+107+107 三段 + 段间引导。
    - 多挂参考图 → 画面凭空多人。只挂 1 张人物正面图，且全局层写全 one person only 长句。
    - 状态接口假死：导出慢时 HTTP 查询会误判进程死亡，白扔 25 分钟。用进程存活判定（proc_alive）+ 兜底找回（recover_output：扫 ComfyUI/output/H3/ 里时间戳在提交之后、时长 15.08±0.1s、362 帧的成品）。
    - 覆盖式更新后新旧模块混用会 ImportError → 重启 ComfyUI 再提交。
    - ffmpeg 的 metadata=print:file= 只传纯文件名（Windows 盘符冒号会被当成选项分隔符、静默失败），并把 cwd 设到 scratch；详见 continuity 的 longtake-seam-verify.md。
    - 中文日志/报告一律写 utf-8，否则核验报告在 Windows 上打开是乱码。

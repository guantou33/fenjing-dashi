---
name: h3-prompt-writing
description: Use when 用户要出 MiniMax H3 视频提示词、做视频。
---

# MiniMax H3 视频提示词编写

官方来源：github.com/MiniMax-AI/MiniMax-H3 内置 skills/h3-prompt-writing。参考原文见 references/base-en.txt（文本/关键帧模式）与 references/ref-en.txt（全参考模式）。

## 先判输入模式

- T2VA：纯文字 → 从零生成完整音画时间线
- I2VA：首帧图 → 从首帧向前发展
- FL2VA：首帧+尾帧图 → 描述两帧之间的连续路径
- L2VA：尾帧图 → 推断开头、收敛到尾帧
- Ref2VA：全参考（图/视频/音频多参考）→ 六段结构

## Base 模式（T2VA/I2VA/FL2VA/L2VA）最终结构

关键帧模式第一行必须先写对齐指令（T2VA 无此句，直接从三字段开始）：

- I2VA：`For the target video, at 0.00 seconds into the target video, <Picture 1> (from [Shot 1]) is fully referenced.`
- FL2VA：`How the reference pictures align with the target video — Picture 1 (from Shot 1) aligns with the 0.00-second mark of the target video; Picture 2 (from Shot N) aligns with the S.SS-second mark of the target video.`
- L2VA：`How the reference pictures align with the target video — <Picture 1> (from [Shot N]) aligns with the S.SS-second mark of the target video.`

（S.SS 是实际时长，保留两位小数；该句后空一行再接三字段）

三核心字段（顺序固定）：

```text
integrated_multimodal_description: [Shot 1] ...

overall_soundscape: ...

non_diegetic_music: ...
```

- integrated_multimodal_description：沿时间线描述画面、动作、镜头、说话人、对白、歌唱、叙事内声音
- overall_soundscape：全片环境声+动作声+非语言人声（1-4 句英文一段）。此字段**也必须英文且声明不含对白**（中文写环境声同样会被并入语音流）
- non_diegetic_music：只有观众能听到的背景配乐（1-3 句英文）

## 关键帧融入写法

- I2VA：先锚定图内风格/主体/构图/场景，再写后续动作。结构：首帧锚定 → 动作起 → 连续发展 → 结果/反应
- FL2VA：写主体如何动、姿态如何变、物体如何被操作、构图如何演进、光如何转。偏向单镜头连续插值。结构：首帧态 → 中间可观察变化 → 差异逐步收窄 → 尾帧态
- L2VA：推断合理前态，写人物/物体/镜头/场景如何逐步逼近参考图。结构：合理前态 → 明确动作与过渡路径 → 末镜逐步收敛 → 落在尾帧

## 风格开篇

在 `[Shot 1]` 开头先声明整体风格与初始构图：`[Shot 1] Live-action, cinematic, a medium-wide shot frames...`。常见风格：Cinematic / live-action / 2D-animated / 3D CG / claymation / watercolor / vintage film。关键帧任务（I2VA/FL2VA/L2VA）从参考图推导风格；T2VA 从用户文字选。

## 镜头与切镜

- 第一镜 `[Shot 1]` 无时间戳；后续 `[Shot 2] At 00:03.500, the camera cuts to...`（切镜时间严格递增且在时长内）
- 普通切镜用 `the camera cuts to` / `the shot cuts to` / `the shot transitions to` / `the shot changes to` / `the shot switches to`；用户明确要求才用叠化/淡入淡出/划像
- 只是距离或角度微调时优先用运镜而非切镜；切镜应引入新的主体/空间/状态/视角/时间信息

## 运镜：类型 + 幅度 + 速度

写进镜头动作的自然英文里，不要堆在句尾标签。三要素：

- 类型：Zoom In/Out、Push In/Pull Out、Pan Left/Right、Truck Left/Right、Tilt Up/Down、Pedestal Up/Down、Arc Shot、Tracking Shot、Static Shot、Shake Slightly/Strongly、POV、Roll Clockwise/Counterclockwise
- 幅度：with small amplitude / with large amplitude
- 速度：at slow speed / at fast speed（中等幅度、常速通常省略）

例：`The camera pushes in with small amplitude at slow speed toward the folded letter in her hands.`

## 说话人 / 对白 / 歌唱

- 说话人用稳定 ID `(S1)` `(S2)`；多人同声 `(S1,S2)`；同一人跨镜不变；不发声的角色不给 ID
- 首次出现时给出足以建立身份的信息（类型/年龄/性别/是否入画/音高/音色/语速/口音），放在 `<d>` 外
- 对白原文放 `<d>` 内：`<d>[English] I get off at the next station.</d>`，逐字保留、不翻译不改写
- 画外音用 `says in an off-screen voiceover`，且紧接着声明对应入画角色嘴唇不动
- 跨切镜的对白两端用 `<scenetrans>` 并声明音频连续（措辞如 `continues seamlessly across the cut` / `carries over from the previous shot`）；结尾被截断用 `<cutoff>`

## 情绪 / 微表情 / 语气（H3 最吃提示词的地方）

H3 用同一段文字同时驱动画面、口型、音色与环境声，所以表演不能写感受词（"她很难过"），只能写可观察的时间线。完整手册与可粘模板见 `references/performance-cn.md`，要点：

- 四段式节拍：基线（中性静止）→ 触发（明确诱因）→ 反应（2–3 个协调信号）→ 平复（受控回到新静止态）
- 一镜只演一次过渡；不要给眉/眼/鼻/下颌/唇分别下指令（互相矛盾）
- 用否定边界替代强度堆叠：`no frown, no widened eyes, no sudden head turns`
- 眨眼写成偶发标点；保留自然呼吸、小幅视线调整、左右不对称
- 声线身份写在 `<d>` 外，首次出现给足 pitch / timbre / speaking rate / accent / delivery；同一角色跨镜逐字复用同一串声线描述，否则音色漂移
- 混合情绪写顺序不写并列（眼神先亮 → 肩放松 → 几不可察的微笑 → 重归沉着）
- 台词写在同一镜内说完、不跨切镜；听者反应放在对方台词进行中，停顿半拍再回应

## 导演台（多段长片）与人物动作、场景锁定

多段长片（漫剧）不要一条一条手搓，用导演台：加载技能 `h3-director-playbook`（01 讲导演台操作、03 讲动作与台词、04 是提交前检查清单）。三条最容易翻车的口径：

- **参考图锁人，不锁场景**。r2v 参考图只携带主体外观（脸/服装/道具/画风/姿态），模型每段会重新想象空间。要锁场景就把房间也做成参考图，并在 `subject_definitions` 里声明 `<Subject N>`（`<Picture N>` 锁的是具体机位构图，别混用）。
- **「引用上段」= 场景继承开关**。只在同镜头、同画布、连续动作时才勾；换场景 / 换机位必须关掉，否则新场景被上一镜串味。
- **动作写动词链，不写状态词**。一镜一个主动作 + 一个次动作（她抬手 → 指尖捏住 → 抽出一张 → 停住）；只写起止姿势 + 1–2 个中间态；手没有任务就写 `hands stay below the frame`，否则模型自作主张加动作，脸崩多半来自这里。

## 屏幕可见文字

用英文双引号包裹，保留原文不翻译：`A red neon sign reading "营业中" glows above the doorway.`

## 音景 / 配乐规则

- overall_soundscape：环境声+动作声+非语言人声（风、雨、车流、脚步、布料、撞击、呼吸、笑、喘气）；对白/歌唱/叙事音乐不重复；全静音才用 N/A
- non_diegetic_music：只写乐器/速度/节奏/动态变化，不用情绪抽象词、不解释情绪功能；角色能听到的唱歌/乐器/收音机/电视/手机音乐属叙事内，写进主描述；无配乐用 N/A

## 全参考模式（Ref2VA）六段结构（顺序固定）

```text
subject_definitions: ...
summary: ...
retention_analysis: ...
detailed_description: ...
overall_soundscape: ...
non_diegetic_music: ...
```

- subject_definitions：定义每个被引用内容及其标签（每个一行）
- summary：一段英文，以任务类型前缀开头（见下）
- retention_analysis：逐标签写保留/转移/复用关系
- detailed_description：按播放顺序逐镜写（生成任务通常 350-500 英文词），主字段（区别于 base 的 integrated_multimodal_description）

四种标签（跨所有段含义不变）：
- `<Subject N>`：从参考素材抽象出的可复用可见内容（人/物/场景/服饰/道具/风格/动作/表情/姿势）
- `<Picture N>`：作为具体目标帧或构图锚点的参考图
- `<Video N>`：提供剪辑源/续写起点/整体时间结构的参考视频
- `<Audio N>`：被复制或引用的音频信号

retention_analysis 关系标记（视觉）固定英文值：
- fully_preserved / partially_preserved / attribute_transfer / weak_reference
- 例：`<Subject 1> (appears in [Shot 1], [Shot 3]): fully_preserved - ...`
- 例：`<Picture 2> ([Shot 1] first frame): fully_preserved - ...`

retention_analysis 关系标记（音频）：
- fully_copy / partially_copy / reference / weak_reference
- 例：`<Audio 1>: fully_copy - <Audio 1> is reused 1:1 as the target video's complete final audio track.`

summary 任务类型前缀（可 ` + ` 组合）：
- keyframe completion（图作首帧/关键帧/尾帧/编辑关键帧/具体帧锚点）
- reference generation（素材提供角色/场景/风格/动作/运镜/分镜指导，非具体帧或源视频）
- video editing（直接修改源视频）
- video continuation（从源视频续写/延伸）
- audio reuse（同音频信号整体或部分复用）
- audio reference（只引用音乐风格/音色/对白内容/音效质感/节拍）
- 视频编辑任务摘要开头：`The target video is an edited version of <Video 1>.`

detailed_description 与 base 差异：
- 主字段名 detailed_description（非 integrated_multimodal_description）
- 风格开篇写在 [Shot 1] 之前的一两句话（base 是写在 [Shot 1] 之后）
- 首次出现的重要 `<Subject N>` 要描述其被引用特征、画面位置、当前动作；后续复用标签不再重定义
- 引用帧锚点自然措辞：`the shot begins from <Picture 1>` / `the shot's keyframe corresponds to <Picture 2>` / `the shot ends on <Picture 3>`
- 被引用主体发声写 `<Subject 2> (S1)`（Subject 标识被引用主体，(Sx) 标识实际说话人）
- 引用音频的对白/歌词逐字保留，听不清写 `[unclear]` 不猜

## 输出规则（两种模式通用）

- 改写段落用英文；对白、歌词、屏幕可见文字保留原语言
- 每镜按 构图/主体/环境/动作/镜头/声音/引用内容出现点 描述
- 不用剧情摘要、不留未解析的引用标签、时间戳必须匹配请求时长
- 描述总时长严格匹配请求视频长度（4-15 秒）
- 引用标签跨段落一致（如 `<Picture 1>` `<Video 1>` `<Audio 1>`）
- 用具体视听细节，避免 "cinematic""beautiful" 等抽象词
- 用关键帧时明确写出首/尾帧如何接入时间线

## 完整示例

原文见 references/base-en.txt 第 5 节（四个 case）与 references/ref-en.txt 第 7 节（完整六段示例）。

## 本地 ComfyUI 出片（实操）

本地跑 MiniMax H3 走 ComfyUI HTTP API，不要开网页界面：

- 启动：秋叶式整合包必须用自带的 python（`<整合包>/python/python.exe main.py --port 8188`）；系统 python 缺 sqlalchemy 会直接崩。
- 提交：POST `/prompt`（body `{"prompt": graph, "client_id": ...}`），轮询 `/history/<prompt_id>` 取 outputs。HTTP 400 要读响应体，ComfyUI 会把哪个节点哪个参数错写得非常清楚。
- 400 高频坑：`LoraLoaderModelOnly` 的 `lora_name` 必须用反斜杠分隔（`"MiniMax-H3\\xxx.safetensors"`），写成正斜杠必报 value_not_in_list。
- `length` 是帧数且必须落在 17k+5 网格：`frames = max(5, round(sec*24)) + ((5 - frames % 17) % 17)`。7 秒 → 175 帧 = 7.2917s。
- 两个主节点：`MiniMaxH3ImageToVideo`（I2VA，写三字段 + 首行对齐句）、`MiniMaxH3ReferenceToVideo`（Ref2VA，写六段）。
- 模型链固定：UNETLoader → MiniMaxH3MemoryEfficientSageAttentionPatch → LoraLoaderModelOnly(turbo 4step, 0.75) → MiniMaxH3SigmaShift(shift_video 12 / shift_audio 3) → BasicGuider + BasicScheduler(simple, 8 步) → SamplerCustomAdvanced(res_multistep) → VAEDecode + VAEDecodeAudio → CreateVideo(24fps) → SaveVideo。
- 实测吞吐：544x960 / 175 帧，RTX 5060 Ti 16GB 约 190-220 秒一段，首段因加载 32B 文本编码器更久。
- 中文对白写在同一镜内说完、不跨切镜，口型与音色成功率明显更高。
- H3 会给夜景自作主张生成乱码招牌文字；要干净画面必须在提示词里写明 no signage, no readable text。
- **连跑多条会累积显存爆掉（OOM 后后端假死）**：ref2va 权重 + 32B 文本编码器 + VAE 在 16GB 卡上连跑 3 条后余量耗尽，第 4 条会在权重量化阶段抛 `torch.AcceleratorError: CUDA error: out of memory`（栈底是 `comfy_kitchen/backends/cuda` 的 `rotate_int8_convrot_weight` → `HostBuffer.truncate failed`），接着 ComfyUI 的 prompt_worker 线程整条崩掉。**假死特征**：`GET /system_stats` 返 500、队列里那条仍显示 running（永远等不到产物）、新提交的任务也不会被执行。对策：
  - 启动加 `--disable-smart-memory`（每段用完即卸模型）。实测加完后同样一条从 15 分钟降到 9.6 分钟且不再 OOM。
  - 出片前先卸载本地 LLM（`POST /api/generate {"model": "...", "keep_alive": 0}`）；它和出片抢显存是爆显存的帮凶。
  - **Ollama 治本：禁常驻**。`llama-server.exe` 会长期霸占 10GB+ 显存，即使 `/api/ps` 返回 `{"models":[]}` 也不放手。根治：`setx OLLAMA_KEEP_ALIVE 0` + `setx OLLAMA_MAX_LOADED_MODELS 1`，**然后必须重启 Ollama 才生效**（只 setx 不重启无效）——`Get-Process | Where-Object {$_.ProcessName -like '*ollama*'} | Stop-Process -Force`，再用 `Start-Process` 带 `$env:OLLAMA_KEEP_ALIVE='0'` 拉起 `ollama app.exe`（新进程要继承新环境变量，不能只依赖注册表）。若 nvidia-smi 显示显存被占但进程列表里没有对应进程，重启 Ollama 后即释放。
  - **崩溃后的完整恢复顺序**：① 查 `nvidia-smi --query-compute-apps=pid,process_name,used_memory --format=csv` 找出真正的显存占用者（往往不是 ComfyUI）；② 释放它；③ 确认无进程监听 8188；④ 用整合包 python 带 `--disable-smart-memory` 重启；⑤ 轮询 `/system_stats` 返回 200 才算就绪（启动约 1 分钟），再重新提交任务。
  - **判断「在跑」必须看产物文件的时间戳，不要信队列的 running** —— 假死时队列状态是骗人的，会白等半小时。
  - 恢复只能重启后端：杀 python 主进程后用 `<整合包>/python/python.exe -s ComfyUI/main.py --windows-standalone-build --disable-auto-launch --disable-smart-memory --port 8188` 拉起，约 1 分钟就绪；已落盘的分段成片不受影响，重跑脚本按「成片存在且 > 200KB 则跳过」续跑即可。
  - MSYS 下杀进程用 `powershell -NoProfile -Command "Stop-Process -Id <pid1>,<pid2> -Force"`；`taskkill //PID` 会被 MSYS 拒绝（报「无效参数」）。

## 参考图生视频（r2v）四个实测坑（务必牢记）

1. **参考图输入名是带点号的顶层名**。`MiniMaxH3ReferenceToVideo` 的参考图槽在 POST /prompt 的 `inputs` 里要**平铺**写成 `"ref_images.ref_image_0": ["30", 0]`、`"ref_images.ref_image_1": ["31", 0]`。写成扁平的 `ref_image_0` 会报 `execute() got an unexpected keyword argument 'ref_image_0'`；写成嵌套 `{"ref_images": {...}}` 也不对。参考图先复制进 ComfyUI 的 `input/` 目录，再用 `LoadImage` 节点引用文件名。
2. **`<d>` 内的台词必须锁成中文，但正文仍须英文**。给本地模型（qwen3.5-9B 之类）下出词指令时，system 里要写明「三个核心字段的描述用英文书写；仅 `<d>` 标签内的对白保留简体中文原文」。（旧版此处误写为「正文必须用中文书写」，直接导致第 3–5 轮提示词全变中文、台词乱码，已修正。）注意：模型「整篇飘成英文」是指**连 `<d>` 里的台词也被译成英文**，此时 H3 会照英文念、成片一句中文都没有；要修的是 `<d>` 的内容，不是把正文改成中文。
3. **禁止在提示词里写脸颊红晕**。写「脸颊微红」「脸颊泛起淡淡的红晕」→ H3 会渲染出很重的腮红妆，观感廉价刺眼。想让脸色好只能写光：「脸颊被窗光照出温暖的光泽」。要压制则在开场描述里补「禁止腮红、潮红、浓重血色」。
4. **光照必须写足正面补光**。只写「唯一光源为左侧窗光 5600K」这类单侧光，成片会正脸发黑、画面又脏又暗（用户原话：最黑最脏、人物面光都没有）。正解模板：「以左侧窗光 5600K 为主光，正面辅以柔和补光，确保正脸始终明亮通透、五官清晰、暗部不透死黑；画面明亮干净、曝光充足」。

## 台词乱码（最高频、最致命）

症状：成片台词「一会儿像中文、一会儿是乱语」，whisper 转录出来是一串音近乱码。

根因两条，**必须同时满足才能根治**：

1. **`</d>` 后面绝不能紧跟中文说明文字**。写 `</d> 语气：压着的埋怨，语速偏慢…` 时，模型会把这段说明**当成台词继续念**。实测 whisper 把「语气：压着的埋怨」转成「與其壓的滿緣色」（音近可完全对上），是铁证。语气/表演说明一律**移到 `<d>` 之前并用英文写**，`</d>` 后直接接下一段英文镜头描述。
2. **三个核心字段的描述必须用英文**（官方输出规则）。整篇中文会让 TTS 分不清哪是台词、哪是说明——只有 `<d>[Chinese]` 标了语言的短句能念对，其余中文被硬读成乱语。只有 `<d>` 内对白、屏幕可见文字保留原语言。

实证对照（同 seed 42 / 864x480 / 481 帧，唯一变量是提示词语言）：

- 第 1 轮：英文描述 + `<d>[Chinese] 你回来啦。</d>` → 转录「你回来了我等你好久了」✅
- 第 5 轮：全中文描述 + `</d>` 后接中文语气说明 → 转录「周同學，你已經遲到第三次了，與其壓的滿緣色…」❌

**提交前自查**：`<d>` 与 `</d>` 之外不得出现任何中文字符（`<Picture N>` 标签、屏幕可见文字除外）。

**另一条自查：台词数必须等于“描写了说话”的镜头数**。若某镜写了 `as she speaks` / `Line delivery: ...` 却没给 `<d>` 台词，模型会即兴发音（乱语风险）或整镜变哑。第 5 轮实测漏写第 4 镜台词（只写了举杯动作却写了 "as she speaks"），成片 15–20 秒完全无声。写完逐镜数一遍 `<d>` 块。

语音标签写法对照（同一段台词）：✅ `<d>[Chinese] 周同学，你已经迟到第三次了。</d>` ／ ❌ `<d>(S1) 周同学…`（缺语言标签，说话人 ID 应按规范放在 `<d>` 外）。

## 本地 fl2va 首尾帧（长片不漂移的正解）

单首帧 I2VA 只钉住起点，动作由模型自由发挥，5 秒版尚可，拉到 15 秒末帧明显漂移（实测场景+服装漂移 68.6）。要长且稳就用 FL2VA 把首尾都钉死：

- 模型必须换成 fl2va 专用：`minimax_h3_fl2va_pruned_w4a8_mixed`（沿用 i2va 的模型会拒绝或退化）。
- 节点仍是 `MiniMaxH3ImageToVideo`，多接一个 `last_frame` 图像输入即成 fl2va；其余模型链（sage attention patch → turbo 4step LoRA 0.75 → SigmaShift(12,3) → BasicScheduler simple 8 步 → SamplerCustomAdvanced res_multistep）完全复用。
- 首帧按 **stretch 拉伸**、尾帧按 **cover-crop 裁切**（节点内部行为）。首尾两张图的长宽比要接近目标尺寸，否则尾帧会被裁掉主体。
- 提示词只描述**两帧之间的路径**：转体方向、水袖/衣摆怎么飘、运镜、必须保住什么（脸/服装/头饰/背景）、最终落到哪个姿态。**不要重复描述静态画面细节**，会和参考图打架。
- 尾帧可以用 Flux img2img 从首帧造，拿首帧当底图跑低 denoise 即可继承脸与服装（不必开 PuLID）。denoise 拐点实测：0.55 动作太小等于没变（弃）、0.65 侧身扬袖可用、0.75 抬臂舒展动作最大。底图先缩到与目标同比例（1344x768）再喂。
- 实测耗时：1536x864 / 124 帧（5.167s）/ 8 步 ≈ 460-500 秒一段（RTX 5060 Ti 16GB）。首段另加载 32B 文本编码器更久。
- 验收：`ffmpeg -i out.mp4 -vf "select='eq(n,0)+eq(n,61)+eq(n,123)',scale=960:-1" -fps_mode passthrough f%02d.jpg` 抽首/中/末三帧，逐帧看朝向是否连贯、面部是否崩坏、背景是否跳变。
- 陷阱：ffmpeg 是原生 Windows 程序，MSYS 路径 `/c/...` 不认，必须传 `C:/...` 正斜杠原生路径；否则 exit 127/文件找不到。
- 陷阱：Ollama 视觉模型（qwen2.5vl:7b）遇长提问会陷入重复循环刷屏；验收抽帧提问要压到 3-4 个短问句、每问一句话。

## 台词格式（提交前逐条自查，细节见 references/dialogue-and-ref-image-cn.md）

台词错一次整条废，格式只有一种正确写法：

- 台词只写在 `<d>[Chinese] 原文。</d>` 里，**语言标签必写**；说话人 ID `(S1)` 写在 `<d>` 外，被引用主体写 `<Subject 2> (S1)`。
- **`</d>` 后紧接中文说明会被当台词念出来**（实测 whisper 把「语气：压着的埋怨」转成「與其壓的滿緣色」）。语气/表演说明一律用英文写在 `<d>` 之前。
- **`<d>`/`</d>` 之外不得出现任何中文字符**（`<Picture N>` 标签、屏幕可见文字除外），三个核心字段的描述必须英文。
- 台词数 = 写了「她说话」的镜头数；漏给 `<d>` 会即兴乱语或整镜变哑。
- 每镜台词在同一镜内说完、不跨切镜；跨切镜两端用 `<scenetrans>`，被截断用 `<cutoff>`。
- 声线（pitch/timbre/rate/accent）写在 `<d>` 外，同一角色跨镜逐字复用同一串，否则音色漂移。
- 验收以**亲耳听**为准：技术指标/抽帧通过不等于台词合格。

## 产物消失与回收站恢复（工程目录常被用户自行清理）

用户会主动清空 `ComfyUI/output` 并删掉整个工程目录（含 `第N轮提示词/`），**不要以为是丢了**，也不要把成品硬塞回桌面（实测刚放上去 1 分钟就被再删）。正确做法：

- **先查回收站**，资源管理器删除的文件都在。用 Shell.Application 枚举（快）；**直接递归 `C:\$Recycle.Bin` 会超时**：

```powershell
$sh = New-Object -ComObject Shell.Application
$bin = $sh.Namespace(10)
foreach ($i in $bin.Items()) {
  # $i.Name 文件名；GetDetailsOf($i,1) 原位置；GetDetailsOf($i,2) 删除时间；$i.Path 回收站内真实路径
  $i.Name + ' || ' + $bin.GetDetailsOf($i,1) + ' || ' + $bin.GetDetailsOf($i,2) + ' || ' + $i.Path
}
```

- 回收站里的真实文件名是乱码（`$RVM4YOH.mp4`），**必须靠 `$i.Path` 定位**，再 `cp` 出来改回原名。
- 恢复后若要重跑出片：**提示词文件已随之消失**，ComfyUI 的 `/history` 只保留最后约 2 条（用户自己的运行会把你的挤掉），所以重跑前先确认 `第N轮提示词/*.txt` 是否还在；`h3_gen.py` 的 `DEST` 用 `H3_DEST` 环境变量覆盖，失败时会因目录不存在直接报 `WinError 10061`（连不上 8188）或路径找不到。
- 提交前必查 8188 真的在监听：ComfyUI 重启空档提交必报 `WinError 10061 目标计算机积极拒绝`，队列里不会留下任何痕迹（看起来像"白跑"，其实是没提交上）。

## 参考图：白底单图是身份锚，提示词必须与图一致（2026-09 实测）

- **参考图用「纯白底 + 单人 + 上半身（脸占比大）」**；三视图/九宫格拼图/多人合照是反面用法（导演台自写明会串脸）。多要素就拆成多张单图分别挂（身份/服装/环境各一张，槽位 1–9）。
- **文字压过参考图**。实测：白底图是浅棕发空气刘海 + 星星发夹 + 露肩白上衣，提示词写 `long black hair, navy sailor suit` → 成片出来是深色长发 + 水手服（用户问「头发变了是为啥」的根因）。参考图只定脸型/五官/气质，**发色、发长、刘海、配饰、服装这类显性属性听文字的**。
- 所以挂参考图时提示词开头固定写 `<Picture 1> The same girl/guy as <Picture 1>: ...`，后面**逐项照图写**发色/刘海/发夹/服装；想改外观就改参考图，不要只改文字。
- 参考图长边会被节点压到 864（`ref_image_size=match/max`），竖构图大图会被削细节、脸占比变小 → 身份更像「参考」而非「锁定」。
- r2v 参考图**锁人不锁场景**；要锁空间得把场景也做参考图。
- 验证法：同参考图 + 同 seed，只改提示词做 A/B，每条 5 秒 124 帧约 4 分钟，对比发色/发长是否对上参考图。


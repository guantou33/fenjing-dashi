---
name: fov-optics
description: 当你给一个镜头填光学槽、选镜头性格、写多镜头条的镜头一致性锁时翻它。给视场角六锚点的中英完整语言块、镜头决策树、Content-FOV 对齐律、长焦/广角结果栈、镜头锁与防漂移锁、毫米对照表与反模式清单。
---

[定位]
    这是光学槽的单一真相源，核心洞见已经长片实战验证：
    "Seedance responds better to observable lens results than to camera metadata."（Seedance 对可观测镜头结果的响应远好于相机元数据。）
    用法：先按内容类型走 [镜头决策树] 选档，再抄对应锚点语言块、整块或取半，长焦/广角另叠结果栈，多镜头条加镜头锁，成句前扫反模式清单。

[判据卡 · 结果语言 vs 相机元数据]
    怎么认：
        写的是"画面里能看到什么"——背景压成柔色浆、直线保持笔直、前景虚影占画面下部三成、机位距主体 4–6 米。模型能把这些直接渲染成像素。
    认错长什么样：
        拿"85mm、f/1.4、ISO 800、Cooke S4、复古镜头型号"当主控指令——模型从画面内容反推镜头，不服从数字；镜头品牌与光圈值几乎是噪声。写了度数却不给任何可见结果，同样落空——度数是锚，结果语言才是肉。
    典型例子：
        反例：元数据主控——85mm f/1.4 人像镜头拍她。
        正例：结果语言主控——29° 视场角短长焦人像性格，机位距她 4–6 米，靠镜头拉近而非身体贴近取得紧凑取景；她锐利如刻，背景压近身后化成奶油般柔化的焦外，人从环境中干净跃出。
    辅助锚词纪律：中文散文里"85mm 长焦、浅景深"这类专业中文术语可作辅助锚词与结果语言并写——中文术语实测响应好，在 2.5 的响应强度待实测校准；冲突时结果语言胜；镜头品牌、光圈、ISO 任何情况下不写。

[视场角六锚点语言块]
    每档四件：情绪用途一行、辅助换算用的毫米近似、中文可抄块、留档比对用的英文原句——正文用中文块。

    47° 标准（≈50mm）——人眼中性，对话戏与客观叙事默认档。
        中文块，可整块抄：47° 对角线视场角，标准镜头性格，机位距主体 3–5 米，自然人眼透视。无可见畸变，脸与身体比例自然，景深舒适，背景可读但不夸张，经典沉稳的电影取景。
        英文原句：47° diagonal field of view, standard normal lens character, camera 3 to 5 meters from subject, natural human-eye perspective. Zero obvious distortion, natural face and body proportions, comfortable depth of field, background readable but not exaggerated, classic grounded cinema framing.

    84° 经典广角（≈24mm）——环境与主体并重、临场沉浸、贴身动作。
        中文块，可整块抄：84° 对角线视场角，经典广角性格，机位距主体 1–1.5 米，按需微仰。强烈而自然的透视扩张，前景身体显得更大更近，环境一直延伸到画框边缘可见，纵深空间层层可读，建筑直线保持笔直不弯曲，无鱼眼弧。
        英文原句：84° diagonal field of view, classic wide-angle lens character, camera 1 to 1.5 meters from subject, slight low angle if needed. Wide-angle lens with strong but natural perspective expansion, foreground body presence feels larger and closer, environment remains visible to the frame edges, deep readable spatial context, straight architectural lines stay rectilinear, no fisheye curve.

    107° 广角直线型（≈16mm）——大尺度环境地理、极致空间沉浸。
        中文块，可整块抄：107° 对角线视场角，广角直线型性格，机位距前景主体 0.5–0.8 米。近前景逼人放大，四周环境向画框每一条边铺开，边到边全实深焦，直线保持笔直，画框边缘轻微色散，无圆形暗角，无鱼眼球面弯曲。
        英文原句：107° diagonal field of view, wide rectilinear lens character, camera 0.5 to 0.8 meters from foreground subject. Immediate foreground looms large, surrounding environment spreads wide to all frame edges, deep edge-to-edge focus, straight lines remain straight, subtle chromatic aberration near frame edges, no circular vignette, no fisheye bubble.

    29° 短长焦人像（≈85mm）——情绪特写与人像的主力档。
        中文块，可整块抄：29° 对角线视场角，短长焦人像性格，机位距主体 4–6 米。紧凑取景靠镜头拉近而非身体贴近；主体锐利如刻，背景开始向其身后压近，脸部比例饱满讨喜且稳定，背景化成奶油般柔化的焦外，主体从环境中干净跃出。
        英文原句：29° diagonal field of view, short telephoto portrait lens character, camera 4 to 6 meters from subject. Close framing achieved through lens reach, not physical proximity. Subject is razor-sharp, background begins to compress closer behind them, face proportions are flattering and stable, background dissolves into creamy soft bokeh, subject pops clearly from the environment.

    18° 经典长焦（≈135mm）——强压缩情绪特写、被观察感。
        中文块，可整块抄：18° 对角线视场角，经典长焦性格，机位距主体 6–8 米。强背景压缩，远处元素被压叠到主体身后，刀锋般薄的焦平面只留眼睛与关键五官锐利，前景与背景一并融成柔软焦外，画面带着"从远处观察"的距离感。
        英文原句：18° diagonal field of view, classic telephoto lens character, camera 6 to 8 meters from subject. Strong background compression, distant elements appear stacked closer behind the subject, razor-thin focus isolates the eyes and key facial features, foreground and background melt into soft bokeh, the image feels observed from a distance.

    8° 超长焦观察（≈300mm+）——狗仔/野生动物纪录/赛事转播式远距窥视。
        中文块，可整块抄：8° 对角线视场角，超长焦观察性格，机位距主体 20–25 米。极强背景压缩，背景被压平成一片柔色浆，只有主体锐利，其余尽数融成奶油焦外。画面像远距离狗仔偷拍、野生动物纪录或赛事转播。前景遮挡为强制项：虚化的前景物体以超大深色虚影占据画面下部 30–45%，把主体从远处框住。
        英文原句：8° diagonal field of view, super-telephoto observation lens character, camera 20 to 25 meters from subject. Extreme background compression, background flattened into a soft color wash, only the subject is sharp, everything else dissolves into creamy bokeh. The image feels like distant paparazzi, wildlife documentary, or sports-broadcast observation. Foreground occlusion is mandatory: blurred foreground objects occupy the lower 30 to 45 percent of frame as oversized dark bokeh shapes, framing the subject from far away.

    扩展档——实战十档的中间位，按需用：63°（≈35mm）纪实街拍、主体嵌在环境里；12°（≈200mm）介于 18° 与 8° 之间的窥视压缩。实战经验：29°–84° 是稳定区，两端档位对结果语言的依赖更重。

[镜头决策树]
    写句前按内容类型静默选档。
    人像/脸：
        亲密近脸且环境要在场 → 84°（Cuarón 式亲密广角）
        中景人像 → 29°
        紧的情绪特写 → 18°
        远距隐蔽观察 → 8°，强制前景遮挡
    环境动作：
        自然纪实动作 → 47°
        宽环境动作 → 84°
        大尺度环境地理 → 107°
    细节/微距：
        标准细节 → 29° 或 18°
        宽环境里的细节 → 单独拆一镜作插入，别混进宽镜头
    远距观察：
        转播/狗仔/野生动物 → 8°
        压缩感监视人像 → 18° 或 8° + 前景遮挡 + 空气霾

[判据卡 · Content-FOV 对齐律]
    怎么认：
        镜头选择与镜头内容同类。广角配环境、空间、身体贴近镜头、沉浸；长焦配人像、观察、孤立、压缩、远距注视；微距/细节自成插入拍。一个动作节拍一只镜头性格。
    认错长什么样：
        一个节拍里既要人脸情绪特写、又要交代环境地理、还要看清手上的细节——三个内容类挤在一只镜头里，模型无所适从，镜头滑向舒适中焦、哪个都不到位，这就是镜头漂移。
    典型例子：
        反例：全景交代仓库全貌的同时给他脸部特写级的情绪，顺便看清他指间的子弹刻痕。
        正例：拆三镜——镜头1〔全景，84° 广角，环境延展到画框边缘〕交代仓库；镜头2〔特写，29° 人像性格，背景压成焦外〕接他的脸；镜头3〔大特写插入，18° 细节档〕指间子弹的刻痕。
    执行：需要不同内容类就切镜，每镜各配镜头性格；切镜归 B 轨镜头行，逐镜声明光学。

[长焦结果栈]
    29°、18°、8° 任一长焦档成句至少含 4 条可观测短语，从下表取：
        背景完全虚化成一片柔暖色浆 · 焦点如刀锋钉在主体上 · 只有主体锐利，其余皆柔 · 主体身后一片奶油般焦外 · 背景被压平贴在主体身后 · 主体从融化的背景前锐利跃出 · 紧凑取景靠镜头拉近而非身体贴近 · 机位远在物理空间之外 · 空气霾悬浮在镜头与主体之间 · 前景遮挡以柔软深色虚影框住主体。

[广角结果栈]
    84°、107° 任一广角档成句至少含 3 条可观测短语，从下表取：
        前景身体比自然更逼人放大 · 环境在主体四周保持可见 · 边到边全实深焦 · 直线保持笔直 · 空间纵深一直可见到画框边缘 · 机位物理上贴近主体 · 沉浸式的贴近透视 · 无长焦压缩 · 无奶油人像焦外，除非明确要。

[多镜头镜头一致性锁]
    B 轨多镜头条必须钉死光学，否则镜间滑档。两种钉法：

    同镜头多镜，全条一只镜头性格——恒定层或首镜声明：
        "LENS IS X° ACROSS ALL SHOTS. NOT NEGOTIABLE."（全部镜头锁定 X° 视场角，不容更改。）
        每镜开头："LENS LOCK SHOT A = X°."（镜头A光学锁 = X°。）
        每镜结尾："LENS CHECK SHOT A: X° maintained, no drift."（镜头A光学核查：X° 保持，无漂移。）
        中文条内可简写为：全条锁定 X° 视场角，逐镜保持，无滑档。三行全套用于正反打、跨镜匹配这类光学纪律要求高的条。

    混镜头多镜，内容类变了才换档：
        只在内容类型改变时给新镜头性格；不同镜头性格之间只用硬切；无平滑视场角过渡；镜头性格不得在一镜之内改变——变化只许发生在切镜处。
        每镜镜头行内各自声明光学，如"镜头2〔特写，29° 人像性格背景压成焦外……〕"。

    跨镜恒定项——每次切镜都保持：在场人物表、地理关系、银幕方向、视线方向、身体朝向、光向、道具与伤口状态、血雪土水火烟的连续性、世界物理。完整清单归 blocking 的跨镜连续锁，见 blocking 的 axis-and-coverage.md；光学锁只管镜头性格这一项。

[防漂移锁]
    仅在长镜、大幅机位移动、有前科症状这类确有漂移风险的镜头用，别默认全挂。

    长焦防漂移：
        中文块，可整块抄：本镜任何一帧都不变成广角或标准视角覆盖。更宽的取景靠机位后撤同时保持长焦拉近，不靠换镜头。背景在每一帧都保持压缩与融化。
        英文原句：No part of this shot becomes wide-angle or normal-lens coverage. Wider framing is achieved by the camera being farther away with the same long-lens reach, not by switching lenses. The background remains compressed and dissolved in every frame.

    广角防漂移：
        中文块，可整块抄：本镜任何一帧都不变成长焦人像覆盖。环境始终在主体四周可见，机位保持物理贴近，画面保持广角空间扩张与层层可读的纵深。
        英文原句：No part of this shot becomes telephoto portrait coverage. The environment stays visible around the subject, the camera remains physically close, and the image keeps wide-angle spatial expansion with deep readable context.

    标准防漂移：
        中文块，可整块抄：无极端广角畸变，无长焦压缩。画面保持自然、沉稳、人眼中性。
        英文原句：No extreme wide distortion, no telephoto compression. The image stays natural, grounded, and human-eye neutral.

[毫米↔视场角对照表 · 辅助换算]
| 视场角锚点 | 毫米近似（全画幅） | 光学性格 | 情绪叙事用途 |
|---|---|---|---|
| 107° | ≈16mm 超广角 | 夸张纵深、近大远小、边缘紧张 | 开阔、宏大、压迫、混乱、动作临场 |
| 84° | ≈24mm 广角 | 透视扩张但直线笔直、深焦 | 空间沉浸、临场、亲密广角——人嵌在世界里 |
| 63° | ≈35mm | 自然偏开阔、主体与环境并重 | 纪实感、街拍、空间关系交代 |
| 47° | ≈50mm 标准 | 人眼透视、畸变最小、最中性 | 对话、平视叙事、客观呈现、让表演说话 |
| 29° | ≈85mm 短长焦 | 压缩初显、脸饱满、浅景深 | 情绪特写、人像、把人从环境摘出来 |
| 18° | ≈135mm 长焦 | 强压缩、空间压扁、很浅景深 | 悬疑窥视、心理张力、被观察感 |
| 12° | ≈200mm | 更强压缩 | 监视距离感、压紧的紧张 |
| 8° | ≈300mm+ 超长焦 | 极致压缩、主体压贴背景、极浅 | 疏离、宿命、远距偷看、人被压成平面 |

    一条规则贯穿全表：背景压缩不是焦段本身造成的，是机位距离造成的——长焦站得远、把前后景压扁；广角贴得近、把纵深拉开。这就是为什么每个锚点块都写机位距离：距离是结果语言的一半。

[特殊光学性格 · 可叠在锚点上或独立用]
    微距：极近距离拍微小物，纹理充满画框、焦平面薄如刀刃。用于极致细节插入拍。
    变形宽银幕：水平压缩宽画幅、椭圆焦外、桶形畸变、水平眩光。注意：视频端保不住这套性格——按"把风格烤进资产"规则前移进场景资产图提示词、归 scene-design；视频提示词里连禁令形式都不出现，只写干净玻璃与收敛光斑类正向语言。
    鱼眼：边缘强烈弯曲、扭曲主观；移轴：微缩模型玩具感。都是重口味，风格允许才用。

[景深词对照]
    浅景深：主体实背景虚，与 29°/18°/8° 天然配套；深焦：前后皆实，与 84°/107° 天然配套；
    柔焦：整体朦胧，梦境/回忆；焦外虚化：光斑美学本身，可指定形状；
    移焦：焦点在景深内转移——这是运动，归运动槽，浅景深是它的前提。

[反模式清单 · 成句前扫一遍，命中即改]
    反例：写"极端广角镜头/超广角镜头"当指令而不给结果语言——空喊无效。
    反例：把"wide shot（大远景）"当镜头指令——景别不是光学，大远景可以用长焦拍成压缩式远景。
    反例：把"establishing shot（建立镜头）"当镜头指令——同上，建立镜头是叙事功能。
    反例：变焦拉远 + 广角同写——指令冲突。
    反例："紧的广角取景"这类内容与光学互斥的写法。
    反例：毫米/光圈/ISO/镜头品牌作主控。
    反例：同一镜内复合运镜——合法判据见 SKILL.md [第一性原则]。
    反例：一个节拍混多内容类，违 Content-FOV 对齐律。
    反例：只用"不要广角"式负向句控光学——先写正向结果语言，防漂移锁只作补充且贴着正向规则放。
